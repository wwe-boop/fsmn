#!/usr/bin/env python3
"""
独立音频特征提取工具 - 集成FunASR前端特征提取方法
不依赖funasr库，保持提取结果一致
"""

import os
import numpy as np
import argparse
import soundfile as sf
import torch
import torch.nn as nn
import torchaudio.compliance.kaldi as kaldi
from torch.nn.utils.rnn import pad_sequence
from pathlib import Path
from typing import Optional, Tuple, Union
import copy


def load_cmvn(cmvn_file):
    """加载CMVN文件"""
    with open(cmvn_file, "r", encoding="utf-8") as f:
        lines = f.readlines()
    means_list = []
    vars_list = []
    for i in range(len(lines)):
        line_item = lines[i].split()
        if line_item[0] == "<AddShift>":
            line_item = lines[i + 1].split()
            if line_item[0] == "<LearnRateCoef>":
                add_shift_line = line_item[3 : (len(line_item) - 1)]
                means_list = list(add_shift_line)
                continue
        elif line_item[0] == "<Rescale>":
            line_item = lines[i + 1].split()
            if line_item[0] == "<LearnRateCoef>":
                rescale_line = line_item[3 : (len(line_item) - 1)]
                vars_list = list(rescale_line)
                continue
    means = np.array(means_list).astype(np.float32)
    vars = np.array(vars_list).astype(np.float32)
    cmvn = np.array([means, vars])
    cmvn = torch.as_tensor(cmvn, dtype=torch.float32)
    return cmvn


class StandaloneFrontend(nn.Module):
    """独立的前端特征提取器 - 基于FunASR WavFrontendOnline"""
    
    def __init__(
        self,
        cmvn_file: str = None,
        fs: int = 16000,
        window: str = "hamming",
        n_mels: int = 80,
        frame_length: int = 25,
        frame_shift: int = 10,
        lfr_m: int = 5,
        lfr_n: int = 1,
        dither: float = 0.0,
        snip_edges: bool = True,
        upsacle_samples: bool = True,
    ):
        super().__init__()
        self.fs = fs
        self.window = window
        self.n_mels = n_mels
        self.frame_length = frame_length
        self.frame_shift = frame_shift
        self.frame_sample_length = int(self.frame_length * self.fs / 1000)
        self.frame_shift_sample_length = int(self.frame_shift * self.fs / 1000)
        self.lfr_m = lfr_m
        self.lfr_n = lfr_n
        self.cmvn_file = cmvn_file
        self.dither = dither
        self.snip_edges = snip_edges
        self.upsacle_samples = upsacle_samples
        self.cmvn = None if self.cmvn_file is None else load_cmvn(self.cmvn_file)

    def output_size(self) -> int:
        return self.n_mels * self.lfr_m

    @staticmethod
    def apply_cmvn(inputs: torch.Tensor, cmvn: torch.Tensor) -> torch.Tensor:
        """应用CMVN归一化"""
        device = inputs.device
        dtype = inputs.dtype
        frame, dim = inputs.shape

        means = np.tile(cmvn[0:1, :dim], (frame, 1))
        vars = np.tile(cmvn[1:2, :dim], (frame, 1))
        inputs += torch.from_numpy(means).type(dtype).to(device)
        inputs *= torch.from_numpy(vars).type(dtype).to(device)

        return inputs.type(torch.float32)

    @staticmethod
    def apply_lfr(
        inputs: torch.Tensor, lfr_m: int, lfr_n: int, is_final: bool = False
    ) -> Tuple[torch.Tensor, torch.Tensor, int]:
        """应用LFR (Low Frame Rate) 处理 - 精确复制FunASR实现"""
        # 完全按照FunASR的实现
        T = inputs.shape[0]  # include the right context
        T_lfr = int(
            np.ceil((T - (lfr_m - 1) // 2) / lfr_n)
        )  # minus the right context: (lfr_m - 1) // 2
        splice_idx = T_lfr
        feat_dim = inputs.shape[-1]
        ori_inputs = inputs
        strides = (lfr_n * feat_dim, 1)
        sizes = (T_lfr, lfr_m * feat_dim)
        last_idx = (T - lfr_m) // lfr_n + 1
        num_padding = lfr_m - (T - last_idx * lfr_n)

        if is_final:
            if num_padding > 0:
                num_padding = (2 * lfr_m - 2 * T + (T_lfr - 1 + last_idx) * lfr_n) / 2 * (T_lfr - last_idx)
                inputs = torch.vstack([inputs] + [inputs[-1:]] * int(num_padding))
        else:
            if num_padding > 0:
                sizes = (last_idx, lfr_m * feat_dim)
                splice_idx = last_idx

        splice_idx = min(T - 1, splice_idx * lfr_n)
        LFR_outputs = inputs[:splice_idx].as_strided(sizes, strides)
        lfr_splice_cache = ori_inputs[splice_idx:, :]
        return LFR_outputs.clone().type(torch.float32), lfr_splice_cache, splice_idx

    def extract_fbank(self, waveform: torch.Tensor) -> torch.Tensor:
        """提取Fbank特征"""
        if self.upsacle_samples:
            waveform = waveform * (1 << 15)
        
        waveform = waveform.unsqueeze(0)
        mat = kaldi.fbank(
            waveform,
            num_mel_bins=self.n_mels,
            frame_length=self.frame_length,
            frame_shift=self.frame_shift,
            dither=self.dither,
            energy_floor=0.0,
            window_type=self.window,
            sample_frequency=self.fs,
            snip_edges=self.snip_edges,
        )
        return mat

    def forward(
        self,
        input: torch.Tensor,
        input_lengths: torch.Tensor,
        cache: dict = {},
        is_final: bool = True
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """前向传播 - 提取特征 (批处理模式)"""
        batch_size = input.size(0)
        feats = []
        feats_lens = []

        for i in range(batch_size):
            waveform_length = input_lengths[i]
            waveform = input[i][:waveform_length]

            # 提取Fbank特征
            mat = self.extract_fbank(waveform)

            # 应用LFR - 使用简化的批处理版本
            if self.lfr_m != 1 or self.lfr_n != 1:
                mat = self.apply_lfr_batch(mat, self.lfr_m, self.lfr_n)

            # 应用CMVN
            if self.cmvn is not None:
                mat = self.apply_cmvn(mat, self.cmvn)

            feat_length = mat.size(0)
            feats.append(mat)
            feats_lens.append(feat_length)

        feats_lens = torch.as_tensor(feats_lens)
        feats_pad = pad_sequence(feats, batch_first=True, padding_value=0.0)
        return feats_pad, feats_lens

    @staticmethod
    def apply_lfr_batch(inputs: torch.Tensor, lfr_m: int, lfr_n: int) -> torch.Tensor:
        """应用LFR处理 - 精确复制FunASR非流式版本"""
        # 完全按照FunASR WavFrontend的apply_lfr函数实现
        T = inputs.shape[0]
        T_lfr = int(np.ceil(T / lfr_n))
        left_padding = inputs[0].repeat((lfr_m - 1) // 2, 1)
        inputs = torch.vstack((left_padding, inputs))
        T = T + (lfr_m - 1) // 2
        feat_dim = inputs.shape[-1]
        strides = (lfr_n * feat_dim, 1)
        sizes = (T_lfr, lfr_m * feat_dim)
        last_idx = (T - lfr_m) // lfr_n + 1
        num_padding = lfr_m - (T - last_idx * lfr_n)
        if num_padding > 0:
            num_padding = (2 * lfr_m - 2 * T + (T_lfr - 1 + last_idx) * lfr_n) / 2 * (T_lfr - last_idx)
            inputs = torch.vstack([inputs] + [inputs[-1:]] * int(num_padding))
        LFR_outputs = inputs.as_strided(sizes, strides)
        return LFR_outputs.clone().type(torch.float32)


class AudioFeatureExtractor:
    """音频特征提取器 - 独立版本"""
    
    def __init__(self, model_dir: str = "fsmn_model"):
        """
        初始化特征提取器
        
        Args:
            model_dir: 模型目录路径
        """
        self.model_dir = Path(model_dir)
        self.frontend = None
        self._load_frontend()
    
    def _load_frontend(self):
        """加载前端处理器"""
        try:
            # 读取配置文件
            config_file = self.model_dir / "config.yaml"
            if not config_file.exists():
                raise FileNotFoundError(f"配置文件不存在: {config_file}")
            
            # 解析配置 (简化版本，只提取必要参数)
            config = self._parse_config(config_file)
            
            # 检查CMVN文件
            cmvn_file = self.model_dir / "am.mvn"
            cmvn_file_str = str(cmvn_file) if cmvn_file.exists() else None
            
            print(f" 加载独立前端特征提取器")
            print(f"   - 配置文件: {config_file}")
            print(f"   - CMVN文件: {cmvn_file_str}")
            print(f"   - 采样率: {config['fs']} Hz")
            print(f"   - Mel滤波器组数: {config['n_mels']}")
            print(f"   - 帧长: {config['frame_length']} ms")
            print(f"   - 帧移: {config['frame_shift']} ms")
            print(f"   - LFR参数: m={config['lfr_m']}, n={config['lfr_n']}")
            
            self.frontend = StandaloneFrontend(
                cmvn_file=cmvn_file_str,
                fs=config['fs'],
                window=config['window'],
                n_mels=config['n_mels'],
                frame_length=config['frame_length'],
                frame_shift=config['frame_shift'],
                lfr_m=config['lfr_m'],
                lfr_n=config['lfr_n'],
                dither=config['dither'],
            )
            
            print(f" 前端加载成功")
            
        except Exception as e:
            print(f" 前端加载失败: {e}")
            raise
    
    def _parse_config(self, config_file: Path) -> dict:
        """解析配置文件 (简化版本)"""
        config = {
            'fs': 16000,
            'window': 'hamming',
            'n_mels': 80,
            'frame_length': 25,
            'frame_shift': 10,
            'lfr_m': 5,
            'lfr_n': 1,
            'dither': 0.0,
        }
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            in_frontend_conf = False
            for line in lines:
                line = line.strip()
                if line.startswith('frontend_conf:'):
                    in_frontend_conf = True
                    continue
                elif in_frontend_conf and line and not line.startswith(' '):
                    in_frontend_conf = False
                
                if in_frontend_conf and ':' in line:
                    key, value = line.split(':', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    if key in config:
                        if key in ['fs', 'n_mels', 'frame_length', 'frame_shift', 'lfr_m', 'lfr_n']:
                            config[key] = int(value)
                        elif key in ['dither']:
                            config[key] = float(value)
                        else:
                            config[key] = value
                            
        except Exception as e:
            print(f"️ 配置文件解析失败，使用默认配置: {e}")
        
        return config

    def load_audio(self, audio_path: str) -> Tuple[np.ndarray, int]:
        """
        加载音频文件

        Args:
            audio_path: 音频文件路径

        Returns:
            (waveform, sample_rate): 音频波形和采样率
        """
        if not os.path.exists(audio_path):
            raise FileNotFoundError(f"音频文件不存在: {audio_path}")

        try:
            waveform, sample_rate = sf.read(audio_path)

            print(f" 音频文件: {audio_path}")
            print(f"   - 采样率: {sample_rate} Hz")
            print(f"   - 音频长度: {len(waveform)} 样本")
            print(f"   - 时长: {len(waveform)/sample_rate:.2f} 秒")
            print(f"   - 数据类型: {waveform.dtype}")

            return waveform, sample_rate

        except Exception as e:
            raise RuntimeError(f"音频加载失败: {e}")

    def extract_features(self, waveform: np.ndarray, sample_rate: int) -> np.ndarray:
        """
        从音频波形提取特征

        Args:
            waveform: 音频波形
            sample_rate: 采样率

        Returns:
            features: 提取的特征 [frames, feature_dim]
        """
        try:
            print(f" 开始特征提取...")

            # 转换为torch tensor
            if isinstance(waveform, np.ndarray):
                data_tensor = torch.from_numpy(waveform).float()
            else:
                data_tensor = torch.tensor(waveform).float()

            # 添加batch维度
            data_tensor = data_tensor.unsqueeze(0)  # [1, T]
            data_len = torch.tensor([data_tensor.shape[1]])

            # 特征提取
            with torch.no_grad():
                features, _ = self.frontend.forward(
                    data_tensor, data_len,
                    cache={},
                    is_final=True
                )

            # 转换为numpy并移除batch维度
            if len(features.shape) == 3:
                features_np = features.squeeze(0).numpy()  # [frames, feature_dim]
            else:
                features_np = features.numpy()

            print(f" 特征提取完成")
            print(f"   - 特征形状: {features_np.shape}")
            print(f"   - 特征维度: {features_np.shape[-1]}")
            print(f"   - 帧数: {features_np.shape[0]}")
            print(f"   - 数据类型: {features_np.dtype}")
            print(f"   - 数值范围: [{features_np.min():.6f}, {features_np.max():.6f}]")

            return features_np

        except Exception as e:
            raise RuntimeError(f"特征提取失败: {e}")

    def extract_from_file(self, audio_path: str) -> np.ndarray:
        """
        从音频文件直接提取特征

        Args:
            audio_path: 音频文件路径

        Returns:
            features: 提取的特征 [frames, feature_dim]
        """
        # 加载音频
        waveform, sample_rate = self.load_audio(audio_path)

        # 提取特征
        features = self.extract_features(waveform, sample_rate)

        return features

    def save_features(self, features: np.ndarray, output_path: str, format: str = "npy"):
        """
        保存特征到文件

        Args:
            features: 特征数组
            output_path: 输出文件路径
            format: 保存格式 ("npy", "txt", "csv")
        """
        try:
            output_path = Path(output_path)
            output_dir = output_path.parent
            output_dir.mkdir(parents=True, exist_ok=True)

            if format.lower() == "npy":
                np.save(output_path, features)
                print(f" 特征已保存为numpy格式: {output_path}")

            elif format.lower() == "txt":
                np.savetxt(output_path, features, fmt='%.6f')
                print(f" 特征已保存为文本格式: {output_path}")

            elif format.lower() == "csv":
                np.savetxt(output_path, features, fmt='%.6f', delimiter=',')
                print(f" 特征已保存为CSV格式: {output_path}")

            else:
                raise ValueError(f"不支持的保存格式: {format}")

            # 保存元信息
            info_path = output_path.with_suffix('.info.txt')
            with open(info_path, 'w') as f:
                f.write(f"特征信息 (独立版本)\n")
                f.write(f"=" * 40 + "\n")
                f.write(f"特征形状: {features.shape}\n")
                f.write(f"特征维度: {features.shape[-1]}\n")
                f.write(f"帧数: {features.shape[0]}\n")
                f.write(f"数据类型: {features.dtype}\n")
                f.write(f"数值范围: [{features.min():.6f}, {features.max():.6f}]\n")
                f.write(f"均值: {features.mean():.6f}\n")
                f.write(f"标准差: {features.std():.6f}\n")
                f.write(f"保存格式: {format}\n")
                f.write(f"提取方法: 独立前端 (基于FunASR WavFrontendOnline)\n")

            print(f" 元信息已保存: {info_path}")

        except Exception as e:
            raise RuntimeError(f"特征保存失败: {e}")


def main():
    parser = argparse.ArgumentParser(description="独立音频特征提取工具")
    parser.add_argument("--input", "-i", required=True, help="输入音频文件路径")
    parser.add_argument("--output", "-o", help="输出特征文件路径 (默认: input_features.npy)")
    parser.add_argument("--format", "-f", choices=["npy", "txt", "csv"], default="npy",
                       help="输出格式 (默认: npy)")
    parser.add_argument("--model", "-m", default="fsmn_model", help="模型目录 (默认: fsmn_model)")

    args = parser.parse_args()

    print(" 独立音频特征提取工具")
    print("=" * 60)
    print(" 基于FunASR WavFrontendOnline，无需funasr库依赖")
    print("=" * 60)

    try:
        # 检查输入文件
        if not os.path.exists(args.input):
            print(f" 输入音频文件不存在: {args.input}")
            return

        # 确定输出路径
        if args.output is None:
            input_path = Path(args.input)
            args.output = input_path.with_name(f"{input_path.stem}_features_standalone.{args.format}")

        # 创建特征提取器
        extractor = AudioFeatureExtractor(model_dir=args.model)

        # 提取特征
        print(f"\n1️⃣ 提取特征")
        features = extractor.extract_from_file(args.input)

        # 保存特征
        print(f"\n2️⃣ 保存特征")
        extractor.save_features(features, args.output, args.format)

        print(f"\n 特征提取完成！")
        print(f"   - 输入音频: {args.input}")
        print(f"   - 输出特征: {args.output}")
        print(f"   - 特征形状: {features.shape}")
        print(f"   - 保存格式: {args.format}")
        print(f"   - 提取方法: 独立前端 (无funasr依赖)")

    except Exception as e:
        print(f"\n 特征提取失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
