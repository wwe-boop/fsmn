#!/usr/bin/env python3
"""
三种特征提取方法比较脚本

比较内容:
1. 三种特征提取实现的一致性验证:
   - C++ test版本 (test_feature_extraction.cpp)
   - Python版本 (extract_python_features.py)
   - C source版本 (src/imedia_fbank_extractor.c)
2. 输入: AsrValidation6.wav (相同音频文件)
3. 特征提取比较:
   - C++输出: test_feature_extraction 生成的特征文件
   - Python输出: extract_python_features.py 生成的特征文件
   - C源码输出: c_result/c_input_features_block_*.bin
4. 比较指标: 余弦相似度、绝对误差、相对误差
5. 验证不同特征提取实现的一致性

注意: 运行前需要先编译并运行各个特征提取程序
"""

import numpy as np
import os
import struct
import torch
from sklearn.metrics.pairwise import cosine_similarity

def load_features_txt(filepath):
    """从文本文件加载特征"""
    if not os.path.exists(filepath):
        return None, None
    
    with open(filepath, 'r') as f:
        first_line = f.readline().strip().split()
        num_frames, feature_dim = int(first_line[0]), int(first_line[1])
        
        features = []
        for line in f:
            frame = [float(x) for x in line.strip().split()]
            features.append(frame)
    
    return np.array(features), (num_frames, feature_dim)

def load_features_bin(filepath):
    """从二进制文件加载特征"""
    if not os.path.exists(filepath):
        return None, None
    
    with open(filepath, 'rb') as f:
        num_frames = struct.unpack('i', f.read(4))[0]
        feature_dim = struct.unpack('i', f.read(4))[0]
        
        features = np.frombuffer(f.read(), dtype=np.float32)
        features = features.reshape(num_frames, feature_dim)
    
    return features, (num_frames, feature_dim)

def compare_features(features1, features2, name1, name2):
    """对比两个特征矩阵"""
    if features1 is None or features2 is None:
        print(f"[ERROR] Cannot compare {name1} vs {name2}: One or both feature sets are missing")
        return

    print(f"\n[DEBUG] Comparing {name1} vs {name2}")
    print(f"Shape: {name1} {features1.shape} vs {name2} {features2.shape}")

    if features1.shape != features2.shape:
        print(f"[ERROR] Shape mismatch!")
        return

    # 计算差异
    diff = np.abs(features1 - features2)
    max_diff = np.max(diff)
    mean_diff = np.mean(diff)

    # 计算相对差异
    rel_diff = np.mean(diff / (np.abs(features1) + 1e-8)) * 100

    # 统计大差异的元素
    large_diff_threshold = 0.01
    large_diff_count = np.sum(diff > large_diff_threshold)
    total_elements = features1.size
    large_diff_percentage = (large_diff_count / total_elements) * 100

    print(f"[STATS] Basic Statistics:")
    print(f"  Max absolute difference: {max_diff:.6f}")
    print(f"  Mean absolute difference: {mean_diff:.6f}")
    print(f"  Relative difference: {rel_diff:.6f}%")
    print(f"  Large differences (>{large_diff_threshold}): {large_diff_count}/{total_elements} ({large_diff_percentage:.2f}%)")

    # 计算余弦相似度
    print(f" Cosine Similarity Analysis:")

    # 整体余弦相似度
    features1_flat = features1.flatten().reshape(1, -1)
    features2_flat = features2.flatten().reshape(1, -1)
    overall_cosine_sim = cosine_similarity(features1_flat, features2_flat)[0, 0]
    print(f"  Overall cosine similarity: {overall_cosine_sim:.8f}")

    # 逐帧余弦相似度
    frame_cosine_sims = []
    for i in range(features1.shape[0]):
        frame1 = features1[i, :].reshape(1, -1)
        frame2 = features2[i, :].reshape(1, -1)
        frame_cosine_sim = cosine_similarity(frame1, frame2)[0, 0]
        frame_cosine_sims.append(frame_cosine_sim)

    frame_cosine_sims = np.array(frame_cosine_sims)
    min_cosine_sim = np.min(frame_cosine_sims)
    mean_cosine_sim = np.mean(frame_cosine_sims)

    print(f"  Per-frame cosine similarity: min={min_cosine_sim:.8f}, mean={mean_cosine_sim:.8f}")

    # 找出余弦相似度最低的帧
    worst_frame_idx = np.argmin(frame_cosine_sims)
    print(f"  Worst frame: {worst_frame_idx} (cosine_sim={frame_cosine_sims[worst_frame_idx]:.8f})")

    # torch.allclose 测试
    print(f"[INFO] Torch.allclose Analysis:")

    # 转换为torch tensor
    tensor1 = torch.from_numpy(features1.astype(np.float32))
    tensor2 = torch.from_numpy(features2.astype(np.float32))

    # 测试不同的容差设置
    tolerance_configs = [
        {"rtol": 1e-5, "atol": 1e-8, "name": "default"},
        {"rtol": 1e-4, "atol": 1e-7, "name": "relaxed"},
        {"rtol": 1e-3, "atol": 1e-6, "name": "loose"},
        {"rtol": 1e-2, "atol": 1e-5, "name": "very_loose"},
        {"rtol": 1.0, "atol": 0.0, "name": "rtol=1.0, atol=0.0"},
        {"rtol": 0.0, "atol": 1.0, "name": "rtol=0.0, atol=1.0"}
    ]

    for config in tolerance_configs:
        is_close = torch.allclose(tensor1, tensor2, rtol=config["rtol"], atol=config["atol"])
        print(f"  {config['name']} (rtol={config['rtol']}, atol={config['atol']}): {'[SUCCESS] PASS' if is_close else '[ERROR] FAIL'}")

    # 判断一致性
    print(f"[TARGET] Overall Assessment:")
    if max_diff < 0.01:
        print(f"[SUCCESS] Features are very similar (max diff < 0.01)")
    elif max_diff < 0.1:
        print(f"[WARNING]  Features are mostly similar (max diff < 0.1)")
    else:
        print(f"[ERROR] Features have significant differences (max diff >= 0.1)")

    if overall_cosine_sim > 0.9999:
        print(f"[SUCCESS] Excellent cosine similarity (> 0.9999)")
    elif overall_cosine_sim > 0.999:
        print(f"[SUCCESS] Very good cosine similarity (> 0.999)")
    elif overall_cosine_sim > 0.99:
        print(f"[WARNING]  Good cosine similarity (> 0.99)")
    else:
        print(f"[ERROR] Poor cosine similarity (< 0.99)")

    # 显示前几个差异较大的位置
    if max_diff > 0.001:
        flat_diff = diff.flatten()
        max_indices = np.argsort(flat_diff)[-5:]  # 前5个最大差异
        print(f" Top 5 largest differences:")
        for i, idx in enumerate(max_indices[::-1]):
            frame_idx = idx // features1.shape[1]
            feat_idx = idx % features1.shape[1]
            val1 = features1.flat[idx]
            val2 = features2.flat[idx]
            diff_val = flat_diff[idx]
            print(f"  {i+1}. Frame {frame_idx}, Feature {feat_idx}: {val1:.6f} vs {val2:.6f} (diff: {diff_val:.6f})")

def main():
    print("[ANALYSIS] Three-Version Feature Extraction Comparison")
    print("=" * 60)
    
    # 定义路径
    paths = {
        'c_test': '../result/c_test/features.txt',
        'python': '../result/python/features.txt',
        'c_src': '../result/c_src/features.txt'
    }
    
    # 加载所有特征
    features = {}
    for name, path in paths.items():
        feat, shape = load_features_txt(path)
        if feat is not None:
            features[name] = feat
            print(f"[SUCCESS] Loaded {name}: {shape[0]} frames × {shape[1]} features")
        else:
            print(f"[ERROR] Failed to load {name} from {path}")
    
    print(f"\n[LIST] Summary: Loaded {len(features)} feature sets")
    
    # 进行两两对比
    comparisons = [
        ('c_test', 'python', 'C++ Test', 'Python'),
        ('c_test', 'c_src', 'C++ Test', 'C Source'),
        ('python', 'c_src', 'Python', 'C Source')
    ]
    
    for key1, key2, name1, name2 in comparisons:
        feat1 = features.get(key1)
        feat2 = features.get(key2)
        compare_features(feat1, feat2, name1, name2)
    
    # 如果所有三个版本都存在，显示总体统计
    if len(features) == 3:
        print(f"\n[TARGET] Overall Assessment:")
        c_test = features['c_test']
        python = features['python']
        c_src = features['c_src']
        
        # 计算三者的平均差异
        diff_ct_py = np.mean(np.abs(c_test - python))
        diff_ct_cs = np.mean(np.abs(c_test - c_src))
        diff_py_cs = np.mean(np.abs(python - c_src))
        
        print(f"  C++ Test vs Python: {diff_ct_py:.6f}")
        print(f"  C++ Test vs C Source: {diff_ct_cs:.6f}")
        print(f"  Python vs C Source: {diff_py_cs:.6f}")
        
        avg_diff = (diff_ct_py + diff_ct_cs + diff_py_cs) / 3
        print(f"  Average difference: {avg_diff:.6f}")
        
        if avg_diff < 0.01:
            print(f"[EXCELLENT] All three implementations are highly consistent!")
        elif avg_diff < 0.1:
            print(f"[SUCCESS] All three implementations are reasonably consistent")
        else:
            print(f"[WARNING]  Implementations have noticeable differences")
    
    print(f"\n[FOLDER] Feature files saved in:")
    print(f"  - ../result/c_test/ (C++ test version)")
    print(f"  - ../result/python/ (Python version)")
    print(f"  - ../result/c_src/ (C source version)")

if __name__ == "__main__":
    main()
