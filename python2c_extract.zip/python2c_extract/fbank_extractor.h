#ifndef FBANK_EXTRACTOR_H
#define FBANK_EXTRACTOR_H

#include <vector>
#include <cmath>
#include <algorithm>
#include <complex>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// 简化的Fbank特征提取器
class FbankExtractor {
public:
    struct Options {
        float sample_rate = 16000.0f;
        float frame_length_ms = 25.0f;
        float frame_shift_ms = 10.0f;
        int num_mel_bins = 80;
        float dither = 0.0f;
        float energy_floor = 0.0f;
        std::string window_type = "hamming";
        bool use_log_fbank = true;
        bool use_power = true;
        float low_freq = 20.0f;
        float high_freq = 0.0f;  // 0 means nyquist/2
        bool snip_edges = true;
        // 添加缺失的关键参数
        float preemph_coeff = 0.97f;    // 预加重系数
        bool remove_dc_offset = true;   // 去除DC偏移
    };

private:
    Options opts_;
    int frame_length_samples_;
    int frame_shift_samples_;
    std::vector<float> window_;
    std::vector<std::vector<float>> mel_banks_;
    
    // FFT相关
    void fft(std::vector<std::complex<float>>& data);
    void compute_mel_banks();
    void apply_window(std::vector<float>& frame);
    std::vector<float> compute_power_spectrum(const std::vector<float>& frame);
    
public:
    explicit FbankExtractor(const Options& opts);
    
    // 计算帧数
    int compute_num_frames(int num_samples) const;
    
    // 提取单帧特征
    std::vector<float> extract_frame(const std::vector<float>& waveform, int frame_idx);

    // 提取单帧特征（带调试信息）
    std::vector<float> extract_frame_debug(const std::vector<float>& waveform, int frame_idx,
                                          std::ofstream& debug_file);

    // 提取所有特征
    std::vector<std::vector<float>> extract_features(const std::vector<float>& waveform);

    // 提取所有特征（带调试信息）
    std::vector<std::vector<float>> extract_features_debug(const std::vector<float>& waveform,
                                                          const std::string& debug_filename);

    int get_feature_dim() const { return opts_.num_mel_bins; }
};

// 实现部分
inline FbankExtractor::FbankExtractor(const Options& opts) : opts_(opts) {
    frame_length_samples_ = static_cast<int>(opts_.sample_rate * opts_.frame_length_ms / 1000.0f);
    frame_shift_samples_ = static_cast<int>(opts_.sample_rate * opts_.frame_shift_ms / 1000.0f);
    
    // 创建窗函数
    window_.resize(frame_length_samples_);
    for (int i = 0; i < frame_length_samples_; ++i) {
        if (opts_.window_type == "hamming") {
            window_[i] = 0.54f - 0.46f * std::cos(2.0f * M_PI * i / (frame_length_samples_ - 1));
        } else if (opts_.window_type == "hanning") {
            window_[i] = 0.5f - 0.5f * std::cos(2.0f * M_PI * i / (frame_length_samples_ - 1));
        } else if (opts_.window_type == "povey") {
            // Povey窗: pow((0.5 - 0.5*cos(n/N*2*pi)), 0.85)
            float base = 0.5f - 0.5f * std::cos(2.0f * M_PI * i / (frame_length_samples_ - 1));
            window_[i] = std::pow(base, 0.85f);
        } else {  // rectangular
            window_[i] = 1.0f;
        }
    }
    
    compute_mel_banks();
}

inline void FbankExtractor::compute_mel_banks() {
    float nyquist = opts_.sample_rate / 2.0f;
    float high_freq = (opts_.high_freq <= 0.0f) ? nyquist : opts_.high_freq;

    // Mel scale conversion (与Python完全一致)
    auto hz_to_mel = [](float hz) { return 1127.0f * std::log(1.0f + hz / 700.0f); };
    auto mel_to_hz = [](float mel) { return 700.0f * (std::exp(mel / 1127.0f) - 1.0f); };

    // 计算FFT bins - 使用与Python一致的padded window size
    int fft_size = 1;
    while (fft_size < frame_length_samples_) {
        fft_size <<= 1;
    }
    if (fft_size < 512) {
        fft_size = 512;
    }
    int num_fft_bins = fft_size / 2;  // Python使用window_length_padded / 2

    // 调试信息
    std::cout << "=== Mel Filter Bank Construction Debug (Python-style) ===" << std::endl;
    std::cout << "Sample rate: " << opts_.sample_rate << std::endl;
    std::cout << "Nyquist freq: " << nyquist << std::endl;
    std::cout << "Low freq: " << opts_.low_freq << " Hz" << std::endl;
    std::cout << "High freq: " << high_freq << " Hz" << std::endl;
    std::cout << "FFT size: " << fft_size << std::endl;
    std::cout << "Num FFT bins: " << num_fft_bins << std::endl;
    std::cout << "Mel bins: " << opts_.num_mel_bins << std::endl;

    // 与Python完全一致的实现
    float mel_low_freq = hz_to_mel(opts_.low_freq);
    float mel_high_freq = hz_to_mel(high_freq);
    float mel_freq_delta = (mel_high_freq - mel_low_freq) / (opts_.num_mel_bins + 1);

    // fft-bin width
    float fft_bin_width = opts_.sample_rate / fft_size;

    mel_banks_.resize(opts_.num_mel_bins);

    for (int m = 0; m < opts_.num_mel_bins; ++m) {
        mel_banks_[m].resize(num_fft_bins + 1, 0.0f);  // +1 for padding

        // 计算left, center, right mel频率
        float left_mel = mel_low_freq + m * mel_freq_delta;
        float center_mel = mel_low_freq + (m + 1) * mel_freq_delta;
        float right_mel = mel_low_freq + (m + 2) * mel_freq_delta;

        if (m < 5) {
            std::cout << "Mel filter " << m << ": left_mel=" << left_mel << ", center_mel=" << center_mel << ", right_mel=" << right_mel << std::endl;
        }

        // 对每个FFT bin计算滤波器响应
        for (int k = 0; k < num_fft_bins; ++k) {
            float mel_k = hz_to_mel(fft_bin_width * k);

            // 计算上升斜坡和下降斜坡
            float up_slope = (mel_k - left_mel) / (center_mel - left_mel);
            float down_slope = (right_mel - mel_k) / (right_mel - center_mel);

            // 取最小值并限制为非负 (与Python一致)
            float response = std::max(0.0f, std::min(up_slope, down_slope));
            mel_banks_[m][k] = response;
        }

        // 显示前几个mel滤波器的非零系数
        if (m < 5) {
            std::cout << "  Non-zero coeffs: ";
            int count = 0;
            for (int k = 0; k < num_fft_bins + 1 && count < 5; ++k) {
                if (mel_banks_[m][k] > 0.0f) {
                    std::cout << "k" << k << "=" << mel_banks_[m][k] << " ";
                    count++;
                }
            }
            std::cout << std::endl;
        }
    }
}

inline void FbankExtractor::fft(std::vector<std::complex<float>>& data) {
    int n = data.size();
    if (n <= 1) return;
    
    // 简化的基2 FFT实现
    // 位反转
    for (int i = 1, j = 0; i < n; ++i) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) {
            j ^= bit;
        }
        j ^= bit;
        if (i < j) {
            std::swap(data[i], data[j]);
        }
    }
    
    // FFT计算
    for (int len = 2; len <= n; len <<= 1) {
        float ang = 2 * M_PI / len;
        std::complex<float> wlen(std::cos(ang), std::sin(ang));
        
        for (int i = 0; i < n; i += len) {
            std::complex<float> w(1);
            for (int j = 0; j < len / 2; ++j) {
                std::complex<float> u = data[i + j];
                std::complex<float> v = data[i + j + len / 2] * w;
                data[i + j] = u + v;
                data[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
}

inline int FbankExtractor::compute_num_frames(int num_samples) const {
    if (opts_.snip_edges) {
        if (num_samples < frame_length_samples_) {
            return 0;
        }
        return 1 + (num_samples - frame_length_samples_) / frame_shift_samples_;
    } else {
        return (num_samples + frame_shift_samples_ / 2) / frame_shift_samples_;
    }
}

inline std::vector<float> FbankExtractor::compute_power_spectrum(const std::vector<float>& frame) {
    // 准备FFT输入 - 与Python的round_to_power_of_two=True保持一致
    int fft_size = 1;
    while (fft_size < frame_length_samples_) {
        fft_size <<= 1;
    }
    // 确保至少是512（与Python的padded_window_size一致）
    if (fft_size < 512) {
        fft_size = 512;
    }

    std::vector<std::complex<float>> fft_data(fft_size, std::complex<float>(0, 0));
    for (int i = 0; i < frame_length_samples_; ++i) {
        fft_data[i] = std::complex<float>(frame[i], 0);
    }

    fft(fft_data);

    // 计算功率谱
    std::vector<float> power_spectrum(fft_size / 2 + 1);
    for (int i = 0; i < fft_size / 2 + 1; ++i) {
        float magnitude = std::abs(fft_data[i]);
        power_spectrum[i] = opts_.use_power ? magnitude * magnitude : magnitude;
    }

    return power_spectrum;
}

inline std::vector<float> FbankExtractor::extract_frame(const std::vector<float>& waveform, int frame_idx) {
    std::vector<float> frame(frame_length_samples_, 0.0f);
    
    int start_sample = frame_idx * frame_shift_samples_;
    
    // 提取帧数据
    for (int i = 0; i < frame_length_samples_; ++i) {
        int sample_idx = start_sample + i;
        if (sample_idx >= 0 && sample_idx < static_cast<int>(waveform.size())) {
            frame[i] = waveform[sample_idx];
        }
    }
    
    // 添加抖动
    if (opts_.dither > 0.0f) {
        for (int i = 0; i < frame_length_samples_; ++i) {
            frame[i] += opts_.dither * (static_cast<float>(rand()) / RAND_MAX - 0.5f);
        }
    }

    // 去除DC偏移
    if (opts_.remove_dc_offset) {
        float mean = 0.0f;
        for (float sample : frame) {
            mean += sample;
        }
        mean /= frame_length_samples_;
        for (float& sample : frame) {
            sample -= mean;
        }
    }

    // 预加重处理 (与Python torchaudio完全一致的实现)
    if (opts_.preemph_coeff > 0.0f) {
        // Python实现：strided_input = strided_input - preemphasis_coefficient * offset_strided_input[:, :-1]
        // 其中offset_strided_input使用replicate模式padding

        // 创建offset版本：第一个元素重复，然后是原始数据
        std::vector<float> offset_frame(frame_length_samples_);
        offset_frame[0] = frame[0];  // replicate第一个样本
        for (int i = 1; i < frame_length_samples_; ++i) {
            offset_frame[i] = frame[i-1];
        }

        // 应用预加重：frame[i] -= coeff * offset_frame[i]
        for (int i = 0; i < frame_length_samples_; ++i) {
            frame[i] -= opts_.preemph_coeff * offset_frame[i];
        }
    }

    // 应用窗函数
    apply_window(frame);
    
    // 计算功率谱
    std::vector<float> power_spectrum = compute_power_spectrum(frame);
    
    // 应用Mel滤波器组
    std::vector<float> mel_energies(opts_.num_mel_bins, 0.0f);
    for (int m = 0; m < opts_.num_mel_bins; ++m) {
        for (size_t k = 0; k < power_spectrum.size() && k < mel_banks_[m].size(); ++k) {
            mel_energies[m] += power_spectrum[k] * mel_banks_[m][k];
        }

        // 防止log(0)
        mel_energies[m] = std::max(mel_energies[m], std::numeric_limits<float>::epsilon());

        if (opts_.use_log_fbank) {
            mel_energies[m] = std::log(mel_energies[m]);
        }
    }
    
    return mel_energies;
}

inline void FbankExtractor::apply_window(std::vector<float>& frame) {
    for (int i = 0; i < frame_length_samples_; ++i) {
        frame[i] *= window_[i];
    }
}

inline std::vector<std::vector<float>> FbankExtractor::extract_features(const std::vector<float>& waveform) {
    int num_frames = compute_num_frames(waveform.size());
    std::vector<std::vector<float>> features;
    features.reserve(num_frames);
    
    for (int i = 0; i < num_frames; ++i) {
        features.push_back(extract_frame(waveform, i));
    }
    
    return features;
}

inline std::vector<float> FbankExtractor::extract_frame_debug(const std::vector<float>& waveform,
                                                             int frame_idx,
                                                             std::ofstream& debug_file) {
    debug_file << "\n=== Frame " << frame_idx << " Processing ===\n";

    std::vector<float> frame(frame_length_samples_, 0.0f);
    int start_sample = frame_idx * frame_shift_samples_;

    debug_file << "Frame start sample: " << start_sample << "\n";
    debug_file << "Frame length: " << frame_length_samples_ << " samples\n";

    // 提取帧数据
    for (int i = 0; i < frame_length_samples_; ++i) {
        int sample_idx = start_sample + i;
        if (sample_idx >= 0 && sample_idx < static_cast<int>(waveform.size())) {
            frame[i] = waveform[sample_idx];
        }
    }

    // 保存原始帧数据（前10个样本）
    debug_file << "Raw frame samples (first 10): ";
    for (int i = 0; i < std::min(10, frame_length_samples_); ++i) {
        debug_file << frame[i] << " ";
    }
    debug_file << "\n";

    // 添加抖动
    if (opts_.dither > 0.0f) {
        debug_file << "Applying dither: " << opts_.dither << "\n";
        for (int i = 0; i < frame_length_samples_; ++i) {
            frame[i] += opts_.dither * (static_cast<float>(rand()) / RAND_MAX - 0.5f);
        }
    } else {
        debug_file << "No dither applied\n";
    }

    // 去除DC偏移
    if (opts_.remove_dc_offset) {
        float mean = 0.0f;
        for (float sample : frame) {
            mean += sample;
        }
        mean /= frame_length_samples_;
        debug_file << "DC offset (mean): " << mean << "\n";
        for (float& sample : frame) {
            sample -= mean;
        }
        debug_file << "DC offset removed\n";
    } else {
        debug_file << "No DC offset removal\n";
    }

    // 预加重处理 (与Python torchaudio完全一致的实现)
    if (opts_.preemph_coeff > 0.0f) {
        debug_file << "Applying preemphasis with replicate padding (Python-style): " << opts_.preemph_coeff << "\n";

        // 保存预加重前的数据
        debug_file << "Before preemphasis (first 10): ";
        for (int i = 0; i < std::min(10, frame_length_samples_); ++i) {
            debug_file << frame[i] << " ";
        }
        debug_file << "\n";

        // Python实现：strided_input = strided_input - preemphasis_coefficient * offset_strided_input[:, :-1]
        // 其中offset_strided_input使用replicate模式padding

        // 创建offset版本：第一个元素重复，然后是原始数据
        std::vector<float> offset_frame(frame_length_samples_);
        offset_frame[0] = frame[0];  // replicate第一个样本
        for (int i = 1; i < frame_length_samples_; ++i) {
            offset_frame[i] = frame[i-1];
        }

        debug_file << "Offset frame (first 10): ";
        for (int i = 0; i < std::min(10, frame_length_samples_); ++i) {
            debug_file << offset_frame[i] << " ";
        }
        debug_file << "\n";

        // 应用预加重：frame[i] -= coeff * offset_frame[i]
        for (int i = 0; i < frame_length_samples_; ++i) {
            frame[i] -= opts_.preemph_coeff * offset_frame[i];
        }

        debug_file << "After preemphasis (first 10): ";
        for (int i = 0; i < std::min(10, frame_length_samples_); ++i) {
            debug_file << frame[i] << " ";
        }
        debug_file << "\n";
    } else {
        debug_file << "No preemphasis applied\n";
    }

    // 保存预处理后的帧数据（前10个样本）
    debug_file << "After preprocessing (first 10): ";
    for (int i = 0; i < std::min(10, frame_length_samples_); ++i) {
        debug_file << frame[i] << " ";
    }
    debug_file << "\n";

    // 应用窗函数
    debug_file << "Applying window: " << opts_.window_type << "\n";
    apply_window(frame);

    // 保存加窗后的帧数据（前10个样本）
    debug_file << "After windowing (first 10): ";
    for (int i = 0; i < std::min(10, frame_length_samples_); ++i) {
        debug_file << frame[i] << " ";
    }
    debug_file << "\n";

    // 计算功率谱
    debug_file << "Computing power spectrum...\n";
    std::vector<float> power_spectrum = compute_power_spectrum(frame);
    debug_file << "Power spectrum size: " << power_spectrum.size() << "\n";
    debug_file << "Power spectrum (first 10): ";
    for (int i = 0; i < std::min(10, static_cast<int>(power_spectrum.size())); ++i) {
        debug_file << power_spectrum[i] << " ";
    }
    debug_file << "\n";

    // 应用Mel滤波器组
    debug_file << "Applying Mel filterbanks...\n";
    debug_file << "Power spectrum size: " << power_spectrum.size() << "\n";
    debug_file << "Mel banks size: " << mel_banks_.size() << "\n";
    if (!mel_banks_.empty()) {
        debug_file << "First mel bank size: " << mel_banks_[0].size() << "\n";
    }

    std::vector<float> mel_energies(opts_.num_mel_bins, 0.0f);
    for (int m = 0; m < opts_.num_mel_bins; ++m) {
        float energy = 0.0f;
        for (size_t k = 0; k < power_spectrum.size() && k < mel_banks_[m].size(); ++k) {
            energy += power_spectrum[k] * mel_banks_[m][k];
        }
        mel_energies[m] = energy;

        // 调试前几个mel bin的计算
        if (m < 5) {
            debug_file << "Mel bin " << m << " raw energy: " << energy;
            // 显示前几个非零的滤波器系数
            debug_file << " (filter coeffs: ";
            int count = 0;
            for (size_t k = 0; k < mel_banks_[m].size() && count < 5; ++k) {
                if (mel_banks_[m][k] > 0.0f) {
                    debug_file << "k" << k << "=" << mel_banks_[m][k] << " ";
                    count++;
                }
            }
            debug_file << ")\n";
        }

        // 防止log(0)
        float epsilon = std::numeric_limits<float>::epsilon();
        mel_energies[m] = std::max(mel_energies[m], epsilon);

        if (opts_.use_log_fbank) {
            float log_energy = std::log(mel_energies[m]);
            if (m < 5) {
                debug_file << "Mel bin " << m << " before log: " << mel_energies[m] << ", after log: " << log_energy << "\n";
            }
            mel_energies[m] = log_energy;
        }
    }

    // 保存最终特征（前10个）
    debug_file << "Final Mel features (first 10): ";
    for (int i = 0; i < std::min(10, opts_.num_mel_bins); ++i) {
        debug_file << mel_energies[i] << " ";
    }
    debug_file << "\n";

    return mel_energies;
}

inline std::vector<std::vector<float>> FbankExtractor::extract_features_debug(
    const std::vector<float>& waveform,
    const std::string& debug_filename) {

    std::ofstream debug_file(debug_filename);
    debug_file << "=== C++ Fbank Feature Extraction Debug ===\n";
    debug_file << "Audio samples: " << waveform.size() << "\n";
    debug_file << "Sample rate: " << opts_.sample_rate << "\n";
    debug_file << "Frame length: " << opts_.frame_length_ms << " ms (" << frame_length_samples_ << " samples)\n";
    debug_file << "Frame shift: " << opts_.frame_shift_ms << " ms (" << frame_shift_samples_ << " samples)\n";
    debug_file << "Window type: " << opts_.window_type << "\n";
    debug_file << "Mel bins: " << opts_.num_mel_bins << "\n";
    debug_file << "Dither: " << opts_.dither << "\n";
    debug_file << "Preemph coeff: " << opts_.preemph_coeff << "\n";
    debug_file << "Remove DC offset: " << (opts_.remove_dc_offset ? "true" : "false") << "\n";

    int num_frames = compute_num_frames(waveform.size());
    debug_file << "Total frames: " << num_frames << "\n";

    std::vector<std::vector<float>> features;
    features.reserve(num_frames);

    // 只处理前2帧进行详细调试
    int debug_frames = std::min(2, num_frames);
    for (int i = 0; i < debug_frames; ++i) {
        features.push_back(extract_frame_debug(waveform, i, debug_file));
    }

    // 处理剩余帧（不输出调试信息）
    for (int i = debug_frames; i < num_frames; ++i) {
        features.push_back(extract_frame(waveform, i));
    }

    debug_file.close();
    return features;
}

#endif // FBANK_EXTRACTOR_H
