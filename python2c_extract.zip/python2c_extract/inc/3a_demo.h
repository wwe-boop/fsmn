
#ifndef IMEDIA_3A_DEMO_H
#define IMEDIA_3A_DEMO_H

#ifdef __cplusplus
extern "C" {
#endif

#include "wav.h"

#define iMedia_SCHEDULE_MAX_STR_LEN         (512)     //   文件名长度

//测试通道变量大小
#define CHANNEL_SIZE_TEST
#define TEST_DENOISE

//24Bit临时验证，读取16bits文件，左移16位变成24bits格式，送给3A仿真，仅在配置了
//   stPara_imedia_voice.uwResolution=24时有效，如果配置为24时未开此宏，将直接读取int数据
//  #define TEST_24BIT

//  ==============================================================================
//通道保存相关通道变量结构体定义
typedef struct tag_chan_save_struct
{
    int frame;
    char name[100];
} STRU_CHAN_SAVER;
extern STRU_CHAN_SAVER chan_save[];
extern int g_CHAN_SAVE_NUM;
extern int g_load_index;
//  ==============================================================================

//  ==============================================================================
//模式切换测试宏定义
//  #define MODE_SWITCH_TEST
//模式切换模拟相关结构体定义
typedef struct tag_switch_struct
{
    int  switchFrame;       //切换问题发生帧: 每1帧10ms, 只支持偶数(2|4...)
    int  switchMode;        //切换后的模式: 如1(免提)
    char switchModStr[8];   //切换后的辅助模式字符串(如GS，GSM+LVM), 可切任何模式:
    //如D-hfnr, S-LVM, W-wnr, B-bwe
    char reserved[8];       //保留位
} STRU_SWITCH_DATA;
extern STRU_SWITCH_DATA g_switch_data[];
extern int g_switch_num;


#include "imedia_denoise_api.h"
int TestCommand(char *testfilePath, char *waveFolderPath, char *waveOutFolder);

#ifdef __cplusplus
}
#endif
 
#endif // IMEDIA_3A_DEMO_H
