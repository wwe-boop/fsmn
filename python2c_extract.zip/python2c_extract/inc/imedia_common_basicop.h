/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 * Description: imedia_common_basicop_vec.h  common模块api接口定义
 *****************************************************************************/
#ifndef IMEDIA_COMMON_BASICOP_H
#define IMEDIA_COMMON_BASICOP_H

#define MAX_16 ((short)0x7fff)
#define MIN_16 ((short)0x8000)

#define MAX_32 ((int)0x7fffffffL)
#define MIN_32 ((int)0x80000000L)

#define MAX_48 ((long long)0x00007fffffffffff)
#define MIN_48 ((long long)0xffff800000000000)

#define MAX_56 ((long long)0x007fffffffffffff)
#define MIN_56 ((long long)0xff80000000000000)

#define MAX_64 ((long long)0x7fffffffffffffff)
#define MIN_64 ((long long)0x8000000000000000)
#define LW_SIGN   ((int)0x80000000)     /* sign bit */

static inline void AudioCommonVecSetInt8(signed char *vec, int num, signed char val)
{
    int i = 0;
    for (i = 0; i < num; i++)  {
        *vec = val;
        vec++;
    }
}

static inline void AudioCommonVecSetInt16(short *vec, int num, short val)
{
    int i = 0;
    for (i = 0; i < num; i++)  {
        *vec = val;
        vec++;
    }
}

static inline void AudioCommonVecSetInt32(int *vec, int num, int val)
{
    int i = 0;
    for (i = 0; i < num; i++)  {
        *vec = val;
        vec++;
    }
}

static inline void AudioCommonVecCopyInt8(const signed char *vecSrc, int num, signed char *vecDst)
{
    int i = 0;
    for (i = 0; i < num; i++)  {
        *vecDst = *vecSrc;
        vecSrc++;
        vecDst++;
    }
}
static inline void AudioCommonVecCopyUInt8(const unsigned char* vecSrc, int num, unsigned char* vecDst)
{
    int i = 0;
    for (i = 0; i < num; i++) {
        *vecDst = *vecSrc;
        vecSrc++;
        vecDst++;
    }
}

static inline void AudioCommonVecCopyInt16(const short *vecSrc, int num, short *vecDst)
{
    int i;
    for (i = 0; i < num; i++)  {
        vecDst[i] = vecSrc[i];
    }
}

static inline void AudioCommonVecCopyInt32(const int *vecSrc, int num, int *vecDst)
{
    int i = 0;
    for (i = 0; i < num; i++)  { // 2n 2n+1
        vecDst[i] = vecSrc[i];
    }
}

// 宏展开
#ifdef Q2_DIVIDE
#define AudioCommonLdivideQ(iNum, iDenom, sQ)   (((iDenom) != 0) ? Q6_R_sat_P(((float)(iNum) / (iDenom)) * ((unsigned long long)0x1 << (sQ))) : 0)
#endif

#ifdef Q_CODE_NNSE_MACRO
// 加减法
#define add Q6_R_add_RlRl_sat // 16bit
#define L_add Q6_R_add_RR_sat // 32bit
#define L_add64 Q6_P_add_PP_sat // 64bit
#define sub Q6_R_sub_RlRl_sat // 16bit
#define L_sub Q6_R_sub_RR_sat // 32bit
// 绝对值
#define abs_s(var1) Q6_R_sath_R(Q6_R_abs_R(var1)) // 16bit
#define L_abs Q6_R_abs_R_sat // 32bit

// 左右移
#define shl_nnse(var1, var2) Q6_R_sath_R(Q6_R_asl_RR_sat(Q6_R_sxth_R(var1), var2)) // 16bit
#define shr_nnse(var1, var2) Q6_R_sath_R(Q6_R_asr_RR_sat(Q6_R_sxth_R(var1), var2)) // 16bit
#define L_shl_nnse Q6_R_asl_RR_sat // 32bit
#define L_shr_nnse Q6_R_asr_RR_sat // 32bit


// 取值
#define negate(var1) Q6_R_sath_R(-Q6_R_sxth_R(var1))
#define L_negate_nnse Q6_R_neg_R_sat
#define extract_h(L_var1) HEXAGON_V64_GET_H1(L_var1)

// 饱和
#define saturate Q6_R_sath_R
#define AudioCommonLongLongToInt Q6_R_sat_P

#define norm_l Q6_R_normamt_R
#define norm_ll(var)  Q6_R_mux_pRR((var) == 0, 63, Q6_R_normamt_P(var))
// 四舍五入
#define round32_nnse(L_var1)  Q6_R_round_RI_sat((L_var1),16)
#define AE_ROUND32X2F64SASYMCC Q6_R_round_P_sat
// 乘法
#define mult(var1, var2) Q6_R_asrh_R(Q6_R_mpy_RlRl_s1_sat(var1, var2))
#define L_mult Q6_R_mpy_RlRl_s1_sat
// 自定义
#define AudioCommonMulAddSTA(a, b, c)  Q6_R_add_RR_sat(a, AE_MULFP32X2RASCC(b, c))



#else
// 加减法
short Add(short in1, short in2);
int LAdd(int L_var1, int L_var2);
long long LAdd64(long long L_var1, long long L_var2);

short Sub(short var1, short var2);
int LSub(int L_var1, int L_var2);

// 绝对值
short AbsS(short var1);
int LAbs(int L_var1);

// 左右移
short ShlNnse(short var1, short var2);
short ShrNnse(short var1, short var2);
int LShlNnse(int L_var1, short var2);
int LShrNnse(int L_var1, short var2);

// 取值
short Negate(short var1);
int LNegateNnse(int L_var1);
short ExtractH(int L_var1);

// 饱和
short SaturateCommand(int L_var1);
int AudioCommonLongLongToInt(long long temp);

// normliztion
short NormL(int L_var1);
static inline short norm_ll(long long var)
{
    const long long OVER64 = 0xffffffffffffffffLL; // 2**64
    const long long OVER64_A = 0x4000000000000000LL; // 2**60
    int bit_64 = 64; // 64bits
    int var_out = 0;
    if (var == 0) {
        var_out = bit_64 - 1;
    }
    else {
        if (var == (long long) OVER64) {
            var_out = bit_64 - 1;
        }
        else {
            if (var < 0) {
                var = var ^ ((int) OVER64);
            }
            for (var_out = 0; var_out < bit_64; var_out++) {
                if (var >= (long long) OVER64_A) {
                    break;
                }
                var <<= 1;
            }
        }
    }
    return (var_out);
}
// 四舍五入
short Round32Nnse(int L_var1);
int AE_ROUND32X2F64SASYMCC(long long val1);

// 乘法
short Mult(short var1, short var2);
int LMult(short var1, short var2);
#endif

static inline long long shl_nnse_long(long long in1, short norm)  /* 64bit left shift saturate */
{
#ifndef Q_CODE_NNSE_STATIC_INLINE
    const long long OVER64 = 0xffffffffffffffff; // 2**64
    const int bit_64 = 64; // 64bits
    long long out1 = 0;
    if ((0 == in1) || (0 == norm)) {
        out1 = in1;
    } else if (norm < 0) {
        if (norm <= -(bit_64 - 1)) {
            if (in1 < 0) {
                out1 = (long long) OVER64;
            } else {
                out1 = 0;
            }
        } else {
            out1 = in1 >> -norm;
        }
    } else {
        if ((norm) > norm_ll(in1)) {
            if (in1 > 0) {
                out1 = MAX_64;
            } else {
                out1 = MIN_64;
            }
            return out1;
        } else {
            out1 = in1 << norm;
        }
    }
    return out1;
#else
    const long long OVER64 = 0xffffffffffffffff; // 2**64
    const int negBit64 = -63; // 64bits
    long long  swOut = 0;
    if (norm > negBit64 && (norm <= Q6_R_normamt_P(in1))) {
        swOut = Q6_P_asl_PR(in1, norm);
    } else if (in1 == 0) {
        swOut = 0;
    } else if (norm <= negBit64 && in1 < 0) {
        swOut = (long long) OVER64;
    } else if (norm <= negBit64 && in1 > 0) {
        swOut = 0;
    } else if (in1 < 0 && (norm > Q6_R_normamt_P(in1))) {
        swOut = MIN_64;
    } else if (in1 > 0 && (norm > Q6_R_normamt_P(in1))) {
        swOut = MAX_64;
    }
    return swOut;
#endif
}

static inline long long AE_MULFP32X2RASCC(int val1, int val2)
{
#ifndef Q_CODE_3A_STATIC_INLINE
    const long long OVER32 = 0x7fffffff00000000; // 2**31
    const long long OVER32A = 0x7fffffff; // 2**31
    long long valmul = 0;
    valmul = (long long)val1 * val2 * 2; // 2 tiwce
    if (valmul > OVER32) {
        valmul = OVER32A;
    } else {
        valmul = ((valmul >> 31) + 1) >> 1;
    }
    return valmul;
#else
    long long valmul = 0;
    const signed int UNDER32 = 0x80000000; // -2**31
    if ((val1 != (signed int) UNDER32) || (val2 != (signed int) UNDER32)) {
        valmul = Q6_R_round_P_sat(Q6_P_asl_PR(Q6_P_mpy_RR(val1, val2), 1));
        return valmul;
    } else {
        return  MAX_32;
    }
#endif
}
static inline int saturate_int(long long L_var1)     /* 32bit saturate */
{
    long long swOut = 0;

    if (L_var1 > MAX_32) {
        swOut = MAX_32;
    } else if (L_var1 < MIN_32) {
        swOut = MIN_32;
    } else {
        swOut = L_var1;        /* automatic type conversion */
    }

    return (swOut);
}


static inline void AE_MULAFP32X2RASCC(int *val1, int val2, int val3)
{
#ifndef Q_CODE_NNSE_STATIC_INLINE
    const long long OVER32 = 0x7fffffff00000000; // 2**31
    const long long OVER32A = 0x7fffffff; // 2**31
    const long long UNDER32 = 0x80000000; // -2**31
    int bit32 = 32 - 1; // bit 32
    long long sum = 0;
    if (val2 == UNDER32 && val3 == UNDER32) {
        *val1 = MAX_32;
    } else {
        sum = (long long)val2 * val3 * 2;
        if (sum > OVER32) {
            sum = OVER32A;
        } else {
            sum = ((sum >> bit32) + 1) >> 1;
        }
        sum = sum + *val1;
        *val1 = saturate_int(sum);
    }
#else
    *val1 = Q6_R_add_RR_sat(*val1, AE_MULFP32X2RASCC(val2, val3));
#endif
}

static inline short shr_nnse_r(short var1, short var2)
{
#ifndef Q_CODE_NNSE_STATIC_INLINE
    short var_out = 0;

    if (var2 > 15) { // 15 =16-1 is 16bit
        var_out = 0;
    } else {
        var_out = ShrNnse(var1, var2);
        if (var2 > 0) {
            if ((var1 & ((short)1 << (var2 - 1))) != 0) {
                var_out++;
            }
        }
    }
    return (var_out);
#else
    short var_out = 0;
    var_out = shr_nnse(var1, var2);
    if (var2 > 0) {
        if ((var1 & ((short)1 << (var2 - 1))) != 0) {
            var_out++;
        }
    }
    return (var_out);
#endif
}

#endif
