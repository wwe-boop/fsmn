/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 * Description: imedia_common_biquadeq.h  eq模块api接口定义
 *****************************************************************************/
#ifndef IMEDIA_COMMON_DEFINE_H
#define IMEDIA_COMMON_DEFINE_H

#ifndef NULL
#define NULL 0
#endif

// 采样率定义
#define IMEDIA_COMMON_TEXT_SECTION
#define IMEDIA_COMMON_TABLE_SECTION

// 帧移10ms
#define IMEDIA_FRAME_LAP_16K  (160)
#define IMEDIA_FRAME_LAP_MAX  (IMEDIA_FRAME_LAP_16K)

// 帧长25ms
#define IMEDIA_FRAME_LEN_16K_25MS (400)
#define IMEDIA_FRAME_LEN_MAX_25MS (IMEDIA_FRAME_LEN_16K_30MS)

// 帧长30ms
#define IMEDIA_FRAME_LEN_16K_30MS (480)
#define IMEDIA_FRAME_LEN_MAX_30MS (IMEDIA_FRAME_LEN_16K_30MS)

// FFT点数定义

#define IMEDIA_FFT_LEN_16K     (512)
#define IMEDIA_FFT_LEN_MAX     (IMEDIA_FFT_LEN_16K)
#define IMEDIA_FFT_OUT         ((IMEDIA_FFT_LEN_16K * 0.5) + 1)            // FFT输出长度

#define IMEDIA_EMPHASIS        31785 // Q15 预加重系数

#define IMEDIA_EPSILON         0.0000001192
#define IMEDIA_MEL_LOW_FREQ    20.0
#define IMEDIA_MEL_HIGH_FREQ    7600.0

#endif
