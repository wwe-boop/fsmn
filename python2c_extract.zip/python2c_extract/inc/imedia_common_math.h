#ifndef IMEDIA_COMMON_MATH_H
#define IMEDIA_COMMON_MATH_H
#include "imedia_kwsnnse_struct.h"
/*****************************************************************************
 功能描述  : IFFT处理函数
 输入参数  : short sFftOrder     -- IFFT点数, 256/512/1024
             int *ifftInBuf    -- IFFT输入数据，sFftOrder+2
             IMEDIA_VOID *pScratchBuf   -- ScratchBuf空间，用于存放fftInBuf的norm后数据，
                                           若不在乎fftInBuf被改写，可直接传入fftInBuf或NULL
 输出参数  : int *ifftOutBuf   -- IFFT输出数据，sFftOrder
             IMEDIA_VOID *pScratchBuf
 返 回 值  : short               -- norm
*****************************************************************************/
short KwsNnseCommonIfft(short sFftOrder, int *ifftInBuf, int *ifftOutBuf, signed char *pScratchBuf, CommonFftTableStruct *pCommonFftTableSt);
/*****************************************************************************
 功能描述  : FFT处理函数
 输入参数  : short sFftOrder     -- FFT点数, 256/512/1024
             int *fftInBuf    -- FFT输入数据，sFftOrder+2
              IMEDIA_VOID *pScratchBuf
 输出参数  : fftOutBuf   -- FFT输出数据
 返 回 值  : short               -- norm
*****************************************************************************/
short KwsNnseCommonFft(short sFftOrder, int *fftInBuf, int *fftOutBuf, signed char *pScratchBuf, CommonFftTableStruct *pCommonFftTableSt);
/*****************************************************************************
 函 数 名  : iMedia_anr_fft_norm
 功能描述  : FFT与IFFT前数据归整操作
 输入参数  : int *buf      : 输入缓冲区 (8字节对齐)
             int iLoop     : buf长度
 输出参数  : int *buf      : 输出缓冲区 (8字节对齐)
 返 回 值  : short
*****************************************************************************/
short KwsNnseCommonFftNorm(
    int *buf,        // 输入缓冲区(8字节对齐)
    int iBufLen);      // FFT样点数
//   ==============================================================================
//    功能描述: FFT/IFFT后Norm结果向量移位
//    输入参数: x            -- 要Norm的数据向量
//        Norm         -- 需要移位的量，正数表示左移，负数表示右移
//        Len          -- 数据长度
//    输出参数:pstTrace     -- y移位后的向量结果
//    返回参数:无
//   ==============================================================================
void KwsNnseFftVecShift32x32(int *__restrict y,
    const int *__restrict x,
    int norm,
    int len);

short AudioCommonFftKws1(short sFftOrder, int* fftInBuf, int* fftOutBuf, signed char* pScratchBuf, const short* sFFT512Coef);
#endif
