#ifndef IMEDIA_COMMON_PROCESS_H
#define IMEDIA_COMMON_PROCESS_H
#include "imedia_kwsnnse_struct.h"
#include "imedia_command_define.h"

int AudioCommonPreProcFftKws1(STRU_KDNR_CHAN* pChnal, short* x, short dnFlg, int* piScratchBuf);
void AudioCommonCreateMelFilters(int num_filters, int fft_size, int sample_rate, float** filters);
void AudioCommonEnergyComp(STRU_KDNR_CHAN* pChnal, int* fftOut, float* power);
void AudioCommonComputeFbank(float** filters, float* spectrum, int num_filters, float* fbank);
void AudioCommonPreEmphasis(short* input, short* output, int size);
void AudioCommonWindowPreKws1(short* spBuf, const short* psWin, short frameLen, short fftBufLen, int* fftInBuf);
#endif
