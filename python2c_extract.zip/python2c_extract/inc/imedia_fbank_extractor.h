/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2024-2024. All rights reserved.
 * Description: imedia_fbank_extractor.h - 新的Fbank特征提取头文件
 *****************************************************************************/
#ifndef IMEDIA_FBANK_EXTRACTOR_H
#define IMEDIA_FBANK_EXTRACTOR_H

#include "imedia_command_define.h"

#ifdef __cplusplus
extern "C" {
#endif

// 初始化Fbank提取器
void IMediaFbankExtractorInit(void);

// 提取单帧特征
int IMediaFbankExtractFrame(STRU_KDNR_CHAN* pChnal, short* audio_frame);

#ifdef __cplusplus
}
#endif

#endif // IMEDIA_FBANK_EXTRACTOR_H
