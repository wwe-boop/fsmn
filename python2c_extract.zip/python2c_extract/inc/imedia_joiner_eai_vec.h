/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2021-2024. All rights reserved.
 * Description: imedia_aec_table.h
 * Author: jin
 * Create: 2024-06-27 19:35:11
 * 函数列表:
 *
 *****************************************************************************/

#ifndef _IMEDIA_JOINER_EAI_VEC_H_
#define _IMEDIA_JOINER_EAI_VEC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "eai.h"
#include "imedia_joiner_eai_define.h"
#include "stdlib.h"
#include "imedia_command_define.h"

// Deinit eai
int IMediaJoinerEaiDeInit(STRU_KDNR_CHAN* pstKdnrChanl);

// Set eNPU core selection/affinity (optional)
EAI_RESULT ImediaJoinerSetMlaAffinity(STRU_JOINER_EAI_CONTEXT *context);

// Perform EAI-INIT, EAI-APPLY
int IMediaJoinerEaiInit(STRU_KDNR_CHAN* pstKdnrChanl, unsigned char* baseAddr, eaiModel* pEaiModel);

// Perform EAI-EXECUTE.
int IMediaJoinerEaiExec(STRU_KDNR_CHAN* pstKdnrChanl, int16_t* pEncoderOut, int16_t* pDecoderOut, int16_t** pJoinerOut);

#ifdef __cplusplus
}
#endif

#endif