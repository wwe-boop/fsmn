#ifndef _IMEDIA_KWSNNSE_STRUCT_PARAM_
#define _IMEDIA_KWSNNSE_STRUCT_PARAM_

#include "imedia_hypothesis.h"

#define MAX_WORD_LEN 10
// FFT描述符结构体
typedef struct TagAudioStruFftDescr {
    int m;
    short *inc;
    int *twd;
} iMedia_STRU_FFTDescr;

// FFT parameters
typedef struct _tagCommonFftTabletSt {
    short *g_G_NNSE_COMMON_TWIDDLESPLIT;
    short *g_G_NNSE_COMMON_FFT_TWD_R8;
    short *g_G_NNSE_COMMON_IFFT_TWD_R8;
    iMedia_STRU_FFTDescr *g_G_NNSE_COMMON_RFFT16_128;
    iMedia_STRU_FFTDescr *g_G_NNSE_COMMON_RFFT16_256;
    iMedia_STRU_FFTDescr *g_G_NNSE_COMMON_RFFT16_512;
    iMedia_STRU_FFTDescr *g_G_NNSE_COMMON_RFFT16_1024;
    iMedia_STRU_FFTDescr *g_G_NNSE_COMMON_RIFFT16_128;
    iMedia_STRU_FFTDescr *g_G_NNSE_COMMON_RIFFT16_256;
    iMedia_STRU_FFTDescr *g_G_NNSE_COMMON_RIFFT16_512;
    iMedia_STRU_FFTDescr *g_G_NNSE_COMMON_RIFFT16_1024;
    iMedia_STRU_FFTDescr *g_G_NNSE_sFFT512Coef;
} CommonFftTableStruct;

// for sigmoid and addwin delwin in fft
typedef struct _tagCommonTabletSt {
    int *g_G_KWSNNSE_COMMON_LOG2TAB;
    int *g_G_KWSNNSE_COMMON_TAB_INVQ30;
    short *g_G_KWSNNSE_COMMON_ADDWINTAB25MS_16K;
    short *g_G_KWSNNSE_COMMON_DELWINTAB30MS_16K;
} CommonTableStruct;

// parameters for dct feature
typedef struct _tagDenoiseVecSt {
    short *g_imedia_kdnr_dct_16k;
} DenoiseVecStruct;

typedef struct StringIntPair {
    char *key;
    int val;
} StringIntPair;
// 集成传入的全局变量
typedef struct _tagKwsDenoiseSt {
    CommonFftTableStruct pCommonFftTableSt;
    CommonTableStruct pCommonTableSt;
    DenoiseVecStruct pDenoiseVecSt;
} KwsDenoiseStruct;

#endif
