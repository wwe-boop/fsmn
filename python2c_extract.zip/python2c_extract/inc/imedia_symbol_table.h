/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2021-2024. All rights reserved.
 * Description: imedia_aec_table.h
 * Author: jin
 * Create: 2024-06-27 19:35:11
 * 函数列表:
 *
 *****************************************************************************/

#ifndef _IMEDIA_SYMBOL_TABLE_H_
#define _IMEDIA_SYMBOL_TABLE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "eai.h"
#include "imedia_decoder_eai_define.h"
#include "stdlib.h"
#include "imedia_command_define.h"
#include "imedia_kwsnnse_struct.h"

void ImediaSymbolTableInit(char* tokenfile, STRU_KDNR_CHAN* pstKdnrChanl);

#ifdef __cplusplus
}
#endif

#endif // _IMEDIA_AES_EAI_DEFINE_H_