/*========================================================================*/
/**
\file imedia_aes_eai_vec.cpp

    Copyright (c) Honor Device Co., Ltd. 2021-2024.
    All rights reserved.
\author honor
\date 2024-06-28 11:16:16
*/
/*========================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "imedia_beam_search.h"

#define DOWNSAMPLING_RATE 4
#define ENCODER_PAD  7

#define IMEDIA_MIN_LOG_DIFF_FLOAT  -15.9423847198486328125f
#define IMEDIA_MIN_LOG_DIFF_DOUBLE -36.0436533891171535515240975655615329742431640625

void IMediaLogSoftmax(float* input, int w)
{
    float sum = 0;
    float max = input[0];
    for (int j = 0; j < w; j++) {
        if (input[j] < max) {
            max = input[j];
        }
    }
    for (int j = 0; j < w; j++) {
        sum += exp(input[j] - max);
    }
    float offset = max + log(sum);
    for (int j = 0; j < w; j++) {
        input[j] -= offset;
    }
}

// 比较函数
void swap(float* a, float* b) {
    float temp = *a;
    *a = *b;
    *b = temp;
}

void swapInt(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int partitionIndex(float* arr, int* indices, int low, int high) {
    float pivot = arr[high];
    int i = (low - 1);
    for (int j = low; j <= high - 1; j++) {
        if (arr[j] > pivot) { // 注意这里是 '>' 以获取降序排列
            i++;
            swap(&arr[i], &arr[j]);
            swapInt(&indices[i], &indices[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    swapInt(&indices[i + 1], &indices[high]);
    return (i + 1);
}
void quickSelectIndex(float* arr, int* indices, int low, int high, int k) {
    if (low < high) {
        int pi = partitionIndex(arr, indices, low, high);
        if (pi == k) {
            // 对前k个元素进行冒泡排序
            for (int i = 0; i < k - 1; i++) {
                for (int j = 0; j < k - i - 1; j++) {
                    if (arr[j] < arr[j + 1]) {
                        swap(&arr[j], &arr[j + 1]);
                        swapInt(&indices[j], &indices[j + 1]);
                    }
                }
            }
            return;
        } else if (pi < k) {
            quickSelectIndex(arr, indices, pi + 1, high, k);
        } else {
            quickSelectIndex(arr, indices, low, pi - 1, k);
        }
    }
}

void IMediaTopkIndex(float* vec, int size, int topk, int* result, int* indices) {
    // 调用 qsort 进行排序
    quickSelectIndex(vec, indices, 0, size - 1, topk - 1);
    for (int i = 0; i < topk; i++) {
        result[i] = indices[i];
    }
}

float ImdediaLogAdd(float x, float y) {
    float diff;
    if (x < y) {
        diff = x - y;
        x = y;
    } else {
        diff = y - x;
    }
    // diff is negative.  x is now the larger one.
    if (diff >= IMEDIA_MIN_LOG_DIFF_DOUBLE) {
        float res;
        res = x + log1pf(expf(diff));
        return res;
    } else {
        return x;  // return the larger one.
    }
}

void IMediaAddHypothesis(STRU_KDNR_CHAN* pstKdnrChanl, STRU_HYPS_DICT* hyps_dict, STRU_HYPS_DICT hyp_dic) {
    int label = 0;
    int i = 0;
    for (i = 0; i < IMEDIA_MAX_ACTIVE_PATH; i++) {
        if (strcmp((hyps_dict + i)->key, hyp_dic.key) == 0) {
            if (pstKdnrChanl->hypSize == 0) {
                (hyps_dict + i)->hyp.ysSize = 2;
            } else {
                label = 1;
                (hyps_dict + i)->hyp.logProb = ImdediaLogAdd((hyps_dict + i)->hyp.logProb, hyp_dic.hyp.logProb);
            }
            break;
        }
    }
    if (label == 0) {
        AudioCommonVecCopyInt8((const signed char*)&hyp_dic, sizeof(hyp_dic), (signed char*)(hyps_dict + pstKdnrChanl->hypSize));
        pstKdnrChanl->hypSize++;
        // if(pstKdnrChanl->hypSize > IMEDIA_MAX_ACTIVE_PATH) {
        //     printf("pstKdnrChanl->hypSize greater than IMEDIA_MAX_ACTIVE_PATH");
        // }
    }
}

void IMediaGetMostProbable(STRU_HYPS_DICT* hyps_dict, int length_norm, int size, int* res_index) {
    int i = 0;
    float max_log = 0;
    *res_index = 0;
    if (length_norm == 1) {
        max_log = hyps_dict->hyp.logProb / hyps_dict->hyp.ysSize;
        for (i = 0; i < size; i++) {
            if ((hyps_dict + i)->key[0] == '\0') {
                if ((hyps_dict + i)->hyp.logProb > max_log) {
                    max_log = (hyps_dict + i)->hyp.logProb;
                    *res_index = i;
                }
            }
        }
    }
    else {
        max_log = hyps_dict->hyp.logProb;
        for (i = 0; i < size; i++) {
            if ((hyps_dict + i)->key[0] == '\0') {
                if ((hyps_dict + i)->hyp.logProb > max_log) {
                    max_log = (hyps_dict + i)->hyp.logProb;
                    *res_index = i;
                }
            }
        }
    }
}

int IMediaBeamSearch(STRU_KDNR_CHAN* pstKdnrChanl, int* pScratchBuf, int16_t* encoderOut)
{
    ContextGraph* contextGraph = &pstKdnrChanl->contextGraph;
    int unkId = 0;
    int i = 0;
    int16_t* pDecoderOut;
    int16_t* pJoinerOut;
    float joinerScale = pstKdnrChanl->modelParam.joinerScale;

    int32_t* decoderInput = (int32_t*)pstKdnrChanl->decoderInBuf;
    QNNSE_INTPTR address = (QNNSE_INTPTR)pScratchBuf;
    Q_ALIGN_ADDR(address, 128);  // 128字节对齐

    float* joinerOut = (float*)address;
    pScratchBuf = (int*)(joinerOut + JOINER_OUTPUT_SIZE + 2);
    float* logprobs = (float*)pScratchBuf;
    pScratchBuf = (int*)(logprobs + IMEDIA_MAX_ACTIVE_PATH * IMEDIA_MAX_ACTIVE_PATH + 2);
    float* pLogit = (float*)pScratchBuf;
    pScratchBuf = (int*)(pLogit + IMEDIA_MAX_ACTIVE_PATH * IMEDIA_MAX_ACTIVE_PATH + 2);
    int* logitIndicesRes = (int*)pScratchBuf;
    pScratchBuf = logitIndicesRes + IMEDIA_MAX_ACTIVE_PATH * IMEDIA_MAX_ACTIVE_PATH + 2;
    int* topk = (int*)pScratchBuf;
    pScratchBuf = topk + IMEDIA_MAX_ACTIVE_PATH + 2;
    int* indices = (int*)pScratchBuf;
    pScratchBuf = indices + pstKdnrChanl->modelParam.vocabSize + 2;
    int t = 0;
    STRU_HYPS_DICT* prev;
    STRU_HYPS_DICT* cur;
    Hypothesis* newHyp;
    ContextState* newContextState;
    ContextState* matchState;
    Hypothesis hyp;
    STRU_HYPS_DICT newHypDict;
    float contexScore = 0;

    while (t < pstKdnrChanl->modelParam.encoderOutT) {
        int numHyps = pstKdnrChanl->hypSize;
        prev = pstKdnrChanl->prev;
        cur = pstKdnrChanl->cur;

        AudioCommonVecCopyInt8((const signed char *)cur, sizeof(pstKdnrChanl->prev), (signed char *)prev);
        AudioCommonVecSetInt8((signed char*)&pstKdnrChanl->cur, sizeof(pstKdnrChanl->cur), 0);
        pstKdnrChanl->hypSize = 0;
        if (numHyps == 0) { //初始第一次解码
            numHyps = 1;
            if (contextGraph != NULL && pstKdnrChanl->hypSize == 0) {
                prev->hyp.contextState = contextGraph->root;
            }
        }
        for (int hypIdx = 0; hypIdx < numHyps; hypIdx++) {
            hyp = (prev + hypIdx)->hyp;
            decoderInput[0] = hyp.ys[hyp.ysSize - 2];
            decoderInput[1] = hyp.ys[hyp.ysSize - 1];
            IMediaDecoderEaiExec(pstKdnrChanl, (int32_t*)decoderInput, &pDecoderOut);
            IMediaJoinerEaiExec(pstKdnrChanl, encoderOut + t * pstKdnrChanl->modelParam.joinerInDim, pDecoderOut, &pJoinerOut);
            for (i = 0; i < JOINER_OUTPUT_SIZE; i++) {
                joinerOut[i] = pJoinerOut[i] * joinerScale;
            }
            IMediaLogSoftmax(joinerOut, pstKdnrChanl->modelParam.vocabSize);
            float logProb = hyp.logProb;
            for (int i = 0; i < pstKdnrChanl->modelParam.vocabSize; i++) {
                indices[i] = i;
            }
            IMediaTopkIndex(joinerOut, pstKdnrChanl->modelParam.vocabSize, IMEDIA_MAX_ACTIVE_PATH, logitIndicesRes + IMEDIA_MAX_ACTIVE_PATH * hypIdx, indices);
            for (int i = 0; i < IMEDIA_MAX_ACTIVE_PATH; i++) {
                *(logitIndicesRes + IMEDIA_MAX_ACTIVE_PATH * hypIdx + i) += pstKdnrChanl->modelParam.vocabSize * hypIdx;
            }
            for (int i = 0; i < IMEDIA_MAX_ACTIVE_PATH; i++) {
                pLogit[hypIdx * IMEDIA_MAX_ACTIVE_PATH + i] = joinerOut[i] + logProb;
                logprobs[hypIdx * IMEDIA_MAX_ACTIVE_PATH + i] = joinerOut[i];
            }
        }
        IMediaTopkIndex(pLogit, IMEDIA_MAX_ACTIVE_PATH * numHyps, IMEDIA_MAX_ACTIVE_PATH, topk, logitIndicesRes);
        for (int i = 0; i < IMEDIA_MAX_ACTIVE_PATH; i++) {
            int hypIndex = topk[i] / pstKdnrChanl->modelParam.vocabSize;
            int newToken = topk[i] % pstKdnrChanl->modelParam.vocabSize;
            newHypDict = *(prev + hypIndex);
            newHyp = &newHypDict.hyp;
            newContextState = newHyp->contextState;
            if (newToken != 0 && newToken != unkId) {
                newHyp->ys[newHyp->ysSize] = newToken;
                newHyp->timestamps[newHyp->ysSize] = pstKdnrChanl->time * DOWNSAMPLING_RATE + ENCODER_PAD;
                newHyp->numTailingBlanks = 0;
                newHypDict.key[newHyp->ysSize - 2] = newToken;
                if (contextGraph != NULL) {
                    IMediaForwardOneStep(contextGraph->root, newHyp->contextState, newToken, 1, &contexScore, &newContextState, &matchState);
                    if (matchState != NULL) {
                        newHyp->phraseId = matchState->phrase;
                    }
                    newHyp->contextState = newContextState;
                    newHyp->contextScore += contexScore;
                }
                newHyp->ysSize++;
            } else {
                newHyp->numTailingBlanks++;
            }
            newHyp->logProb = pLogit[i] + contexScore;
            IMediaAddHypothesis(pstKdnrChanl, cur, newHypDict);
        }
        t++;
        pstKdnrChanl->time++;
    }
    return 0;
}

int IMediaBeamSearchFinalized(STRU_KDNR_CHAN* pstKdnrChanl)
{
    ContextGraph* contextGraph = &pstKdnrChanl->contextGraph;
    if (contextGraph == NULL) {
        return 0;
    }
    STRU_HYPS_DICT* cur;
    cur = pstKdnrChanl->cur;
    Hypothesis* newHyp;
    STRU_HYPS_DICT* newHypDict;
    int numHyps = pstKdnrChanl->hypSize;
    float finalScore = 0;
    short phraseId = -1;
    ContextState* contextState;
    ContextState* nextState = NULL;

    for (int hypIdx = 0; hypIdx < numHyps; hypIdx++) {
        newHypDict = (cur + hypIdx);
        newHyp = &newHypDict->hyp;
        contextState = newHyp->contextState;
        if (contextState != NULL) {
            IMediaFinalize(contextState, &phraseId, &finalScore, &nextState);
            // if (finalScore != 0) {
            //     printf("finalScore:%f\n", finalScore);
            // }
            //newHyp->logProb += finalScore; // gaoh ÔÝÊ±È¥µô todo
            newHyp->contextState = nextState;
            //newHyp->contextScore += finalScore;
            newHyp->phraseId = phraseId;
        }
    }
    return 0;
}