/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 * Description: imedia_common_basicop_vec.c  common模块api接口定义
 *****************************************************************************/

#include "imedia_common_define.h"
#include "imedia_common_basicop.h"

#ifndef Q_CODE_NNSE_MACRO
int giOverflow_nnse = 0;

// 加减法
short Add(short var1, short var2)
{
    int L_sum = 0;
    short swOut = 0;
    L_sum = (int)var1 + var2;
    swOut = SaturateCommand(L_sum);
    return (swOut);
}

int LAdd(int L_var1, int L_var2)
{
    int lVarout = 0;
    lVarout = L_var1 + L_var2;
    if (((L_var1 ^ L_var2) & MIN_32) == 0) {
        if ((lVarout ^ L_var1) & MIN_32) {
            lVarout = (L_var1 < 0) ? MIN_32 : MAX_32;
            giOverflow_nnse = 1;
        }
    }
    return (lVarout);
}

long long LAdd64(long long L_var1, long long L_var2)
{
    long long lVarOut = 0;
    lVarOut = L_var1 + L_var2;
    if (((L_var1 ^ L_var2) & MIN_64) == 0) {
        if ((lVarOut ^ L_var1) & MIN_64) {
            lVarOut = (L_var1 < 0) ? MIN_64 : MAX_64;
            giOverflow_nnse = 1;
        }
    }
    return (lVarOut);
}

short Sub(short var1, short var2)
{
    int lDiff = 0;
    short swOut = 0;

    lDiff = (int)var1 - var2;
    swOut = SaturateCommand(lDiff);

    return (swOut);
}

int LSub(int L_var1, int L_var2)
{
    int lVarOut = 0;

    lVarOut = L_var1 - L_var2;

    if (((L_var1 ^ L_var2) & MIN_32) != 0) {
        if ((lVarOut ^ L_var1) & MIN_32) {
            lVarOut = (L_var1 < 0L) ? MIN_32 : MAX_32;
            giOverflow_nnse = 1;
        }
    }
    return (lVarOut);
}

// 绝对值
short AbsS(short var1)
{
    short varOut = 0;
    if (var1 == (short)MAX_16) {
        varOut = MAX_16;
    } else {
        if (var1 < 0) {
            varOut = -var1;
        } else {
            varOut = var1;
        }
    }
    return (varOut);
}

int LAbs(int lVar1)
{
    int lOut = 0;
    if (MIN_32 == lVar1) {
        lOut = MAX_32;
        giOverflow_nnse = 1;
    } else {
        if (lVar1 < 0) {
            lOut = -lVar1;
        } else {
            lOut = lVar1;
        }
    }
    return (lOut);
}

// 左右移
short ShlNnse(short var1, short var2)
{
    short swOut = 0;
    int lOut = 0;
    const short max16 = 0xffff; // 2**16
    int bit16 = 16 - 1; // 16 bit
    if ((0 == var2) || (0 == var1))
    {
        swOut = var1;
    } else if (var2 < 0) {
        /* perform a right shift */
        /*-----------------------*/
        if (var2 <= - bit16) {
            if (var1 < 0) {
                swOut = (short) max16;
            } else {
                swOut = 0x0;
            }
        } else {
            swOut = ShrNnse(var1, (short)(-var2));
        }
    } else {
        /* var2 > 0 */
        if (var2 >= bit16) {
            /* anr_saturate */
            if (var1 > 0) {
                swOut = MAX_16;
            } else {
                swOut = MIN_16;
            }
            giOverflow_nnse = 1;
        } else {
            lOut = (int)var1 * (1 << var2);
            /* copy low portion to swOut, overflow could have hpnd */
            swOut = (short)lOut;
            if (swOut != lOut) {
                /* overflow  */
                if (var1 > 0) {
                    swOut = MAX_16;     /* anr_saturate */
                } else {
                    swOut = MIN_16;     /* anr_saturate */
                }
                giOverflow_nnse = 1;
            }
        }
    }
    return (swOut);
}

short ShrNnse(short var1, short var2)
{
    short swMask = 0;
    short swOut = 0;
    int bit16 = 16 - 1; // 16bit
    const short max16 = 0xffff; // 2**16

    if ((0 == var2) || (0 == var1)) {
        swOut = var1;
    } else if (var2 < 0) {
        /* perform an arithmetic left shift */
        /*----------------------------------*/
        if (var2 <= -bit16) {
            /* anr_saturate */
            if (var1 > 0) {
                swOut = MAX_16;
            } else {
                swOut = MIN_16;
            }
            giOverflow_nnse = 1;
        } else {
            swOut = ShlNnse(var1, (short)(-var2));
        }
    } else {
        /* positive shift count */
        /*----------------------*/
        if (var2 >= bit16) {
            if (var1 < 0) {
                swOut = (short) max16;
            } else {
                swOut = 0x0;
            }
        } else {
            /* take care of sign extension */
            /*-----------------------------*/
            swMask = 0;
            if (var1 < 0) {
                swMask = ~swMask << ((bit16 + 1) - var2);
            }
            var1 >>= var2;
            swOut = swMask | var1;
        }
    }
    return (swOut);
}

int LShlNnse(int L_var1, short var2)
{
    int lMask = 0;
    int lOut = 0;
    int i = 0;
    int iOverflow = 0;
    const long long over32 = 0xffffffffL; // max
    const int bit32 = 32; // 32bit

    if ((0 == var2) || (0 == L_var1)) {
        lOut = L_var1;
    } else if (var2 < 0) {
        if (var2 <= - (bit32 - 1)) {
            if (L_var1 > 0) {
                lOut = 0;
            } else {
                lOut = (int) over32;
            }
        } else {
            lOut = LShrNnse(L_var1, (short)(-var2));
        }
    } else {
        if (var2 >= (bit32 - 1)) {
            iOverflow = 1;
        } else {
            if (L_var1 < 0) {
                lMask = LW_SIGN;   /* sign bit mask */
            } else {
                lMask = 0x0;
            }
            lOut = L_var1;
            for (i = 0; (i < var2) && (!iOverflow); i++)
            {
                /* check the sign bit */
                lOut = (lOut & MAX_32) << 1;
                if ((lMask ^ lOut) & LW_SIGN) {
                    iOverflow = 1;
                }
            }
        }

        if (iOverflow) {
            /* anr_saturate */
            if (L_var1 > 0) {
                lOut = MAX_32;
            } else {
                lOut = MIN_32;
            }
            giOverflow_nnse = 1;
        }
    }
    return (lOut);
}

int LShrNnse(int L_var1, short var2)
{
    int lMask = 0;
    int lOut = 0;
    const long long over32 = 0xffffffffL; // 2**31
    const int bit32 = 32; // 32bit

    if ((0 == var2) || (0 == L_var1)) {
        lOut = L_var1;
    } else if (var2 < 0) {
        /* perform a left shift */
        /*----------------------*/
        if (var2 <= - (bit32 - 1)) {
            /* anr_saturate */
            if (L_var1 > 0) {
                lOut = MAX_32;
                giOverflow_nnse = 1;
            } else {
                lOut = MIN_32;
                giOverflow_nnse = 1;
            }
        } else {
            lOut = LShlNnse(L_var1, (short)(-var2));
        }
    } else {
        if (var2 >= (bit32 - 1)) {
            if (L_var1 > 0) {
                lOut = 0;
            } else {
                lOut = (int) over32;
            }
        } else {
            lMask = 0;
            if (L_var1 < 0) {
                lMask = ~lMask << (bit32 - var2);
            }
            L_var1 >>= var2;
            lOut = lMask | L_var1;
        }
    }
    return (lOut);
}

// 取值
short Negate(short var1)
{
    short swOut = 0;

    if (MIN_16 == var1) {
        swOut = MAX_16;
        giOverflow_nnse = 1;
    } else {
        swOut = -var1;
    }
    return (swOut);
}

int LNegateNnse(int L_var1)
{
    int lOut = 0;

    if (MIN_32 == L_var1) {
        lOut = MAX_32;
        giOverflow_nnse = 1;
    } else {
        lOut = -L_var1;
    }
    return (lOut);
}

short ExtractH(int L_var1)
{
    short var2 = 0;
    const short over16 = 0x0000ffffL; // 2**16
    var2 = (short)(over16 & (L_var1 >> 16)); // 右移16bit
    return (var2);
}

// 饱和
short SaturateCommand(int L_var1)
{
    short swOut = 0;

    if (L_var1 > MAX_16) {
        swOut = MAX_16;
        giOverflow_nnse = 1;
    } else if (L_var1 < MIN_16) {
        swOut = MIN_16;
        giOverflow_nnse = 1;
    } else {
        swOut = (short)L_var1;        /* automatic type conversion */
    }
    return (swOut);
}

int AudioCommonLongLongToInt(long long temp)
{
#ifndef Q_CODE_NNSE_COMMON
    int tempint = 0;
    if (temp > 0) {
        tempint = (temp > MAX_32) ? MAX_32 : temp;
    } else {
        tempint = (temp < MIN_32) ? MIN_32 : temp;
    }
    return tempint;
#else
    int tempint = 0;
    tempint = Q6_R_sat_P(temp);
    return tempint;
#endif
}

short NormL(int L_var1)
{
    short swShiftCnt;
    const long long over30 = 0x40000000L;  // 2**30
    const int cONE = 0xc0000000L; // 1
    if (L_var1 != 0) {
        if (!(L_var1 & LW_SIGN)) {
            /* positive input */
            for (swShiftCnt = 0; !(L_var1 >= over30); swShiftCnt++)
            {
                L_var1 = L_var1 << 1;
            }
        } else {
            /* negative input */
            for (swShiftCnt = 0; !(L_var1 < (int)cONE); swShiftCnt++)
            {
                L_var1 = L_var1 << 1;
            }
        }
    } else {
        swShiftCnt = 0;
    }
    return (swShiftCnt);
}

// 四舍五入
short Round32Nnse(int L_var1)
{
    short varOut = 0;
    int L_arrondi = 0;
    L_arrondi = LAdd(L_var1, (int) MIN_16);
    varOut = ExtractH(L_arrondi);
    return (varOut);
}

int AE_ROUND32X2F64SASYMCC(long long val1)
{
    int val = 0;
    const long long over32 = 0x7fffffff00000000; // 0x7fffffff00000000 INT_MAX
    const int bit32 = 32; // 32 bit
    if (val1 >= over32) {
        val = MAX_32;
    } else {
        val = ((val1 >> (bit32 - 1)) + 1) >> 1;
    }
    return val;
}

// 乘法
short Mult(short var1, short var2)
{
    int L_product = 0;
    short swOut = 0;
    L_product = LMult(var1, var2);
    swOut = ExtractH(L_product);

    return (swOut);
}

int LMult(short var1, short var2)
{
    int L_product = 0;

    if ((MIN_16 == var1) && (MIN_16 == var2)) {
        L_product = MAX_32;       /* overflow */
        giOverflow_nnse = 1;
    } else {
        L_product = (int)var1 * var2;  /* integer multiply */
        L_product = L_product << 1;
    }
    return (L_product);
}

#endif
