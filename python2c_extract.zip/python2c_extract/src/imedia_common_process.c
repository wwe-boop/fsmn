/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 * Description: imedia_common_ns_functon.c
 * Author: wq
 * Create: 2016-2-14 14:27:1
 * 函数列表:
 * AudioCommonLdivideQ
 *****************************************************************************/
#include "imedia_common_basicop.h"
#include "imedia_common_define.h"
#include "imedia_common_math.h"
#include "imedia_command_define.h"
#include "imedia_kwsnnse_typedef.h"
#include "imedia_fbank_extractor.h"
#include <stdint.h>

#include <stdio.h>

#ifdef WIN32
#include "trace_config.h"
#include "debug.h"
#endif

/*****************************************************************************
 函 数 名  : AudioCommonWindowPreKws1
 功能描述  : FFT前的加窗、清零操作
 输入参数  : short *spBuf            封帧后的语音
             const short *psWin      窗表格
             short frameLen          帧长
             short fftBufLen         fftInBuf的长度
 输出参数  : int *fftInBuf         FFT输入缓冲区
 返 回 值  : IMEDIA_VOID
*****************************************************************************/
IMEDIA_COMMON_TEXT_SECTION
void AudioCommonWindowPreKws1( short *spBuf, const short *psWin, short frameLen, short fftBufLen, int *fftInBuf)
{
#ifndef Q_CODE_NNSE_FFT
    int i;

    for (i = 0; i < frameLen; i++) { // 4
        fftInBuf[i] = LShrNnse((int)spBuf[i] * (int)psWin[i], DENOISE_PROCESS_Q);  // 15 Q15
    }
    // 后面清0
    AudioCommonVecSetInt32(&fftInBuf[frameLen], fftBufLen - frameLen, 0);
#else
    int i;
    int *spBufInt, *psWinInt;
    Q3A_INT64 *fftInBufLL;
    spBufInt = (int *)spBuf;
    psWinInt = (int *)psWin;
    fftInBufLL = (Q3A_INT64 *)fftInBuf;

    for (j = 0; j < (pChnal->frameLen >> 1); j++) {
        fftInBufLL[j] = Q6_P_vasrw_PI(Q6_P_vmpyh_RR_sat(spBufInt[j], psWinInt[j]), DENOISE_PROCESS_Q); // Q15
    }
    //后面清0
    AudioCommonVecSetInt32(&fftInBuf[frameLen], fftBufLen - frameLen, 0);
#endif
}

// 旧的Mel滤波器创建函数已被新实现替代

// 旧的能量计算和Fbank计算函数已被新实现替代

void AudioCommonPreEmphasis(short* input, short* output, int size)
{
    output[0] = input[0] - LShrNnse(IMEDIA_EMPHASIS * input[0], DENOISE_PROCESS_Q);
    for (int i = size - 1; i > 0; i--) {
        output[i] = input[i] - LShrNnse((long long)IMEDIA_EMPHASIS * (long long)input[i - 1], DENOISE_PROCESS_Q);
    }
}

void AudioRemoveDC(short* input, short* output, int size)
{
    int i;
    long long tmp = 0;
    for (i = 0; i < size; i++) {
        tmp += input[i];
    }
    tmp = tmp / size;
    for (i = 0; i < size; i++) {
        output[i] = input[i] - tmp;
    }
}

/*****************************************************************************
 函 数 名  : AudioCommonPreProcFftKws1
 功能描述  : 频域预处理： 分帧、加窗、FFT
             short *x
             short sSampleRate
             short gainDB
             short delay
             short *psDelayBuf
 输出参数  : 无
 返 回 值  : static IMEDIA_VOID
*****************************************************************************/
IMEDIA_COMMON_TEXT_SECTION
int AudioCommonPreProcFftKws1(STRU_KDNR_CHAN* pChnal, short* x, short dnFlg, int* piScratchBuf)
{
    short frameLap;
    // 移除未使用的变量 frameLen, fftLen, sFftNorm 和 psWin
    // short frameLen, fftLen, sFftNorm;
    // const short *psWin = NULL;

    // 以下变量使用ScratchBuf - 移除未使用的变量
    // int *fftInBuf = NULL;
    // int *fftOutBuf = NULL;
    // 保证piScratchBuf 8字节对齐
    uintptr_t address = (uintptr_t)piScratchBuf;
    Q_ALIGN_ADDR(address, 8);
    piScratchBuf = (int *)address;

    frameLap = pChnal->frameLap;
    // 移除未使用的赋值
    // fftLen   = pChnal->dctOrder;
    // frameLen = pChnal->frameLen;
    // psWin    = pChnal->addWin;

    //   ScratchBuf使用量: - 移除未使用的赋值
    // fftInBuf    = (int *)(piScratchBuf); // 4
    // fftOutBuf   = fftInBuf + (fftLen + 4); // 4

    //    分帧
    if (pChnal->readCacheBegin >= 0) {
        AudioCommonVecCopyInt16(pChnal->sHistoryFrame+ pChnal->readCacheBegin, IMEDIA_ASR_FRAMES_16K, pChnal->sInData);
    } else {
        for (int i = 0; i < IMEDIA_ASR_FRAMES_16K; i++) {
            int index = i + pChnal->readCacheBegin;
            while (index < 0) {
                index = -1 * index - 1;
            }
            pChnal->sInData[i] = pChnal->sHistoryFrame[index];
        }
    }
    if (pChnal->frameCnt >= 3) {
        AudioCommonVecCopyInt16(pChnal->sHistoryFrame + frameLap, IMEDIA_COMMAND_3FRAME_16K, pChnal->sHistoryFrame);
        pChnal->cacheBegin -= frameLap;
    }
    if (pChnal->readCacheBegin < 0) {
        pChnal->readCacheBegin += IMEDIA_COMMAND_FRAMELAP_16K;
    }

    IMediaFbankExtractFrame(pChnal, pChnal->sInData);

    pChnal->fftFrameCnt += 1;
    if (pChnal->fftFrameCnt >= (unsigned int)MAX_FRAME_COUNT) {  // 帧计数溢出保护
        pChnal->fftFrameCnt = (unsigned int)MAX_FRAME_COUNT;
    }
    return 0;
}
