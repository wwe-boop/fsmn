#include <stdio.h>
#include <string.h>
#include "imedia_context_graph.h"

// Function to initialize a ContextState
void IMediaInitContextState(ContextState* state, int id, int token, float tokenScore, float nodeScore, float outputScore, int isEnd, int level, const short phrase, float acThreshold, short nextNum) {
    state->id = id;
    state->token = token;
    state->tokenScore = tokenScore;
    state->nodeScore = nodeScore;
    state->outputScore = outputScore;
    state->isEnd = isEnd;
    state->level = level;
    state->phrase = phrase;
    state->acThreshold = acThreshold;
    state->nextNum = nextNum;
    state->fail = NULL;
    state->output = NULL;
    for (int i = 0; i < MAX_TOKEN; i++) {
        state->next[i] = NULL;
    }
}

// Function to initialize a ContextGraph
void IMediaInitContextGraph(ContextGraph* graph, float contextScore, float acThreshold) {
    graph->contextScore = contextScore;
    graph->acThreshold = acThreshold;
    graph->numNodes = 0;
    IMediaInitContextState(graph->nodePool + graph->numNodes, graph->numNodes, -1, 0, 0, 0, 0, 0, -1, 0, 0);
    graph->root = graph->nodePool + graph->numNodes;
    graph->root->fail = graph->root;
}

// Function to fill fail and output pointers
void IMediaFillFailOutput(ContextGraph* graph) {
    ContextState* queue[MAX_NODES];
    int front = 0, rear = 0;

    // Initialize queue with root's children
    for (int i = 0; i < MAX_TOKEN; i++) {
        if (graph->root->next[i] != NULL) {
            graph->root->next[i]->fail = graph->root;
            queue[rear++] = graph->root->next[i];
        }
    }

    // Process queue
    while (front < rear) {
        ContextState* current_node = queue[front++];
        for (int i = 0; i < MAX_TOKEN; i++) {
            if (current_node->next[i] != NULL) {
                ContextState* node = current_node->next[i];
                ContextState* fail = current_node->fail;
                int token = node->token;
                // Find fail state
                while (1) {
                    int matchId = -1;
                    int nextNum = fail->nextNum;
                    for (int j = 0; j < nextNum; j++) {
                        if (fail->next[j]->token == token) {
                            matchId = j;
                            break;
                        }
                    }
                    if (matchId == -1) {
                        fail = fail->fail;
                        if (fail->token == -1) {
                            break;
                        }
                    }
                    else {
                        fail = fail->next[matchId];
                        break;
                    }
                }
                node->fail = fail;

                // Fill output pointer
                ContextState* output = node->fail;
                while (!output->isEnd) {
                    output = output->fail;
                    if (output->token == -1) {
                        output = NULL;
                        break;
                    }
                }
                node->output = output;
                node->outputScore += (node->output != NULL) ? node->output->outputScore : 0;

                // Add to queue
                queue[rear++] = node;
            }
        }
    }
}

// Function to build the ContextGraph
int IMediaBuildContextGraph(ContextGraph* graph, int tokenIds[][MAX_PHRASE_LEN], int numPhrases, const short* phrases, float* scores, float* acThresholds) {
    for (int index = 0; index < numPhrases; index++) {
        const short phrase = phrases != NULL ? phrases[index] : -1;
        float score = scores != NULL ? scores[index] : 0;
        float acThreshold = acThresholds != NULL ? acThresholds[index] : 0.0;
        float tokenScore = (score != 0) ? score : graph->contextScore;
        ContextState* node = graph->root;
        short nextNum;
        int token;
        short matchId;
        for (int i = 0; tokenIds[index][i] != 0; i++) {
            token = tokenIds[index][i];
            nextNum = node->nextNum;
            matchId = -1;
            for (int j = 0; j < nextNum; j++) {
                printf("wzc node->next[%d]=%p\n", j, node->next[j]);
                if (node->next[j]->token == token) {
                    matchId = j;
                    break;
                }
            }
            return -1;
            if (matchId == -1) {
                graph->numNodes++;
                if (graph->numNodes >= MAX_NODES) {
                    // printf("Error: Exceeded maximum number of nodes.\n");
                    return -1;
                }
                if (nextNum >= MAX_TOKEN) {
                    // printf("Error: Exceeded maximum number of next nodes.\n");
                    return -1;
                }
                int isEnd = (tokenIds[index][i + 1] == 0);
                float nodeScore = node->nodeScore + tokenScore;
                IMediaInitContextState(
                    graph->nodePool + graph->numNodes,
                    graph->numNodes, token, tokenScore, nodeScore, isEnd ? nodeScore : 0, isEnd, i + 1, isEnd ? phrase : -1, isEnd ? acThreshold : 0.0, 0
                );
                //printf("wzc node->next[%d]=%p\n", nextNum, node->next[nextNum]);
                node->next[nextNum] = graph->nodePool + graph->numNodes;
                printf("wzc node->next[%d]=%p\n", nextNum, node->next[nextNum]);
                matchId = nextNum;
                nextNum++;
                node->nextNum = nextNum;
            }
            else {
                // Update existing node
                printf("wzc matchId node->next[%d]=%p\n", matchId, node->next[matchId]);
                ContextState* existing_node = node->next[matchId];
                existing_node->tokenScore = (tokenScore > existing_node->tokenScore) ? tokenScore : existing_node->tokenScore;
                existing_node->nodeScore = node->nodeScore + existing_node->tokenScore;
                existing_node->isEnd = (tokenIds[index][i + 1] == 0) || existing_node->isEnd;
                if (existing_node->isEnd) {
                    existing_node->outputScore = existing_node->nodeScore;
                } else {
                    existing_node->outputScore = 0;
                }
                if (tokenIds[index][i + 1] == 0) {
                    existing_node->phrase = phrase;
                    existing_node->acThreshold = acThreshold;
                }
            }
            printf("wzc matchId node->next[%d]=%p\n", matchId, node->next[matchId]);
            node = node->next[matchId];
        }
    }
    IMediaFillFailOutput(graph);
    return 0;
}

//strictMode:
//If the strictMode is True, it can match multiple phrases simultaneously,
//and will continue to match longer phrase after matching a shorter one.
//If the strictMode is False, it can only match one phrase at a time,
//when it matches a phrase, then the state will fall back to root state
//(i.e.forgetting all the history state and starting a new match).
// Function to forward one step in the graph
void IMediaForwardOneStep(ContextState* root, ContextState* state, int token, int strictMode, float* score, ContextState** nextState, ContextState** matchedState) {
    ContextState* node = NULL;
    *score = 0;
    float outputScore = 0;

    // Token matched
    short nextNum = state->nextNum;
    short matchId = -1;
    for (int j = 0; j < nextNum; j++) {
        if (state->next[j]->token == token) {
            matchId = j;
            break;
        }
    }
    if (matchId != -1) {
        node = state->next[matchId];
        *score = node->tokenScore;
    }
    else {
        // Token not matched, follow fail pointers
        node = state->fail;

        while (1) {
            matchId = -1;
            nextNum = node->nextNum;
            for (int j = 0; j < nextNum; j++) {
                if (node->next[j]->token == token) {
                    matchId = j;
                    break;
                }
            }
            if (matchId == -1) {
                node = node->fail;
                if (node->token == -1) {
                    break;
                }
            }
            else {
                node = node->next[matchId];
                break;
            }
        }
        *score = node->nodeScore - state->nodeScore;
    }

    // Determine matched state
    *matchedState = (node->isEnd) ? node : (node->output != NULL) ? node->output : NULL;

    if (!strictMode && node->outputScore != 0) {
        if (node->isEnd) {
            outputScore = node->nodeScore;
        } else if(node->output == NULL) {
            outputScore = node->nodeScore;
        } else {
            outputScore = node->output->nodeScore;
        }
        *score = *score + outputScore - node->nodeScore;
        *nextState = root;
    } else {
        *score = *score + node->outputScore;
        *nextState = node;
    }
}

// Function to IMediaFinalize the matching
void IMediaFinalize(ContextState* state, short* phraseId, float* score, ContextState** nextState) {
    *score = -state->nodeScore;
    *nextState = state->fail;
    *phraseId = state->phrase;
}

// Function to check if a state matches any phrase
int IMediaIsMatched(ContextState* state, ContextState** matchedState) {
    if (state->isEnd) {
        *matchedState = state;
        return 1;
    }
    else if (state->output != NULL) {
        *matchedState = state->output;
        return 1;
    }
    else {
        *matchedState = NULL;
        return 0;
    }
}
