//#include <stdio.h>
//#include <string.h>
//#include <math.h>
//
//#define MAX_TOKEN 256
//#define MAX_PHRASE_LEN 100
//#define MAX_NODES 1000
//#define MAX_TOKENS 1000
//#define MAX_HYPS 100
//#define MAX_FRAMES 1000
//#define MAX_WORD_ALIGNMENT 100
//
//typedef struct ContextState {
//    int id;
//    int token;
//    float tokenScore;
//    float nodeScore;
//    float outputScore;
//    int isEnd;
//    int level;
//    char phrase[MAX_PHRASE_LEN];
//    float acThreshold;
//    struct ContextState* next[MAX_TOKEN];
//    struct ContextState* fail;
//    struct ContextState* output;
//    struct ContextState* best_token;
//} ContextState;
//
//typedef struct {
//    ContextState* state;
//    float score;
//    int start_frame;
//    int alive;
//} Token;
//
//typedef struct {
//    char word[MAX_PHRASE_LEN];
//    float score;
//    int start_frame;
//    int end_frame;
//} WSHyp;
//
//typedef struct {
//    char word[MAX_PHRASE_LEN];
//    int start_frame;
//    int end_frame;
//    float score;
//} WordAlignment;
//
//typedef struct {
//    ContextState* root;
//    ContextState nodePool[MAX_NODES];
//    int numNodes;
//} ContextGraph;
//
//// 初始化函数
//void IMediaInitContextState(ContextState* state, int id, int token,
//    float tokenScore, float nodeScore, float outputScore,
//    int isEnd, int level, const char* phrase, float acThreshold) {
//    state->id = id;
//    state->token = token;
//    state->tokenScore = tokenScore;
//    state->nodeScore = nodeScore;
//    state->outputScore = outputScore;
//    state->isEnd = isEnd;
//    state->level = level;
//    strncpy(state->phrase, phrase, MAX_PHRASE_LEN);
//    state->acThreshold = acThreshold;
//    memset(state->next, 0, sizeof(state->next));
//    state->fail = NULL;
//    state->output = NULL;
//    state->best_token = NULL;
//}
//
//// 核心处理函数
//void beam_pruning(Token* next_tokens, int* count, float beam_threshold) {
//    if (*count == 0) return;
//
//    float best_score = next_tokens[0].score;
//    for (int i = 1; i < *count; i++) {
//        if (next_tokens[i].score > best_score) {
//            best_score = next_tokens[i].score;
//        }
//    }
//
//    int new_count = 0;
//    for (int i = 0; i < *count; i++) {
//        if (next_tokens[i].score >= best_score - beam_threshold) {
//            next_tokens[new_count++] = next_tokens[i];
//        }
//    }
//    *count = new_count;
//}
//
//void state_pruning(Token* next_tokens, int* count) {
//    for (int i = 0; i < *count; i++) {
//        ContextState* state = next_tokens[i].state;
//        if (!state->best_token) {
//            state->best_token = &next_tokens[i];
//        }
//        else {
//            if (next_tokens[i].score <= state->best_token->score) {
//                next_tokens[i].alive = 0;
//            }
//            else {
//                state->best_token->alive = 0;
//                state->best_token = &next_tokens[i];
//            }
//        }
//    }
//
//    int new_count = 0;
//    for (int i = 0; i < *count; i++) {
//        if (next_tokens[i].alive) {
//            next_tokens[new_count++] = next_tokens[i];
//        }
//    }
//    *count = new_count;
//
//    // Reset best_token pointers
//    for (int i = 0; i < *count; i++) {
//        next_tokens[i].state->best_token = NULL;
//    }
//}
//
//// 更新令牌列表
//void update_token_list(Token* next_tokens, int* next_count, int* state_list, int* state_count, Token newToken) {
//    if (newToken.state->token == -1) return;
//
//    int found = 0;
//    for (int i = 0; i < *state_count; i++) {
//        if (state_list[i] == newToken.state->id) {
//            found = 1;
//            break;
//        }
//    }
//
//    if (!found) {
//        if (*next_count < MAX_TOKENS) {
//            next_tokens[(*next_count)++] = newToken;
//            state_list[(*state_count)++] = newToken.state->id;
//        }
//    }
//    else {
//        for (int i = 0; i < *next_count; i++) {
//            if (next_tokens[i].state->id == newToken.state->id && newToken.score > next_tokens[i].score) {
//                next_tokens[i] = newToken;
//                break;
//            }
//        }
//    }
//}
//
//// 获取 CTC 词对齐
//void get_ctc_word_alignment(float logprobs[MAX_FRAMES][MAX_TOKEN], int ids_to_tokens[MAX_TOKEN],
//    float token_weight, int blank_idx, WordAlignment* word_alignment, int* word_count) {
//    int alignment_ctc[MAX_FRAMES];
//    for (int i = 0; i < MAX_FRAMES; i++) {
//        float max_prob = -FLT_MAX;
//        for (int j = 0; j < MAX_TOKEN; j++) {
//            if (logprobs[i][j] > max_prob) {
//                max_prob = logprobs[i][j];
//                alignment_ctc[i] = j;
//            }
//        }
//    }
//
//    *word_count = 0;
//    int prev_idx = -1;
//    char word[MAX_PHRASE_LEN] = "";
//    int start_frame = 0, end_frame = 0;
//    float score = 0;
//
//    for (int i = 0; i < MAX_FRAMES; i++) {
//        int idx = alignment_ctc[i];
//        if (idx != blank_idx) {
//            if (prev_idx != idx) {
//                if (strlen(word) > 0 && *word_count < MAX_WORD_ALIGNMENT) {
//                    strncpy(word_alignment[*word_count].word, word, MAX_PHRASE_LEN);
//                    word_alignment[*word_count].start_frame = start_frame;
//                    word_alignment[*word_count].end_frame = end_frame;
//                    word_alignment[*word_count].score = score;
//                    (*word_count)++;
//                }
//                strcpy(word, "");
//                start_frame = i;
//                score = 0;
//            }
//            strncat(word, &ids_to_tokens[idx], 1);
//            score += logprobs[i][idx] + token_weight;
//            end_frame = i;
//        }
//        prev_idx = idx;
//    }
//
//    if (strlen(word) > 0 && *word_count < MAX_WORD_ALIGNMENT) {
//        strncpy(word_alignment[*word_count].word, word, MAX_PHRASE_LEN);
//        word_alignment[*word_count].start_frame = start_frame;
//        word_alignment[*word_count].end_frame = end_frame;
//        word_alignment[*word_count].score = score;
//        (*word_count)++;
//    }
//}
//
//// 过滤假设
//void filter_wb_hyps(WSHyp* best_hyp_list, int* hyp_count, WordAlignment* word_alignment, int word_count) {
//    if (word_count == 0) return;
//
//    WSHyp filtered_hyps[MAX_HYPS];
//    int filtered_count = 0;
//
//    for (int i = 0; i < *hyp_count; i++) {
//        float overall_spot_score = 0;
//        int hyp_intersects = 0;
//
//        for (int j = 0; j < word_count; j++) {
//            int overlap = 0;
//            if (best_hyp_list[i].start_frame <= word_alignment[j].end_frame &&
//                best_hyp_list[i].end_frame >= word_alignment[j].start_frame) {
//                overlap = 1;
//            }
//
//            if (overlap) {
//                if (!hyp_intersects) {
//                    overall_spot_score = word_alignment[j].score;
//                }
//                else {
//                    overall_spot_score += word_alignment[j].score;
//                }
//                hyp_intersects = 1;
//            }
//        }
//
//        if (hyp_intersects && best_hyp_list[i].score >= overall_spot_score) {
//            filtered_hyps[filtered_count++] = best_hyp_list[i];
//        }
//    }
//
//    memcpy(best_hyp_list, filtered_hyps, filtered_count * sizeof(WSHyp));
//    *hyp_count = filtered_count;
//}
//
//// 主处理流程
//void run_word_spotter(float logprobs[MAX_FRAMES][MAX_TOKEN],
//    ContextGraph* graph, int blank_idx,
//    float beam_threshold, float cb_weight,
//    WSHyp* output_hyps, int* hyp_count) {
//    Token active_tokens[MAX_TOKENS];
//    int active_count = 0;
//    Token next_tokens[MAX_TOKENS];
//    int next_count = 0;
//    int state_list[MAX_TOKENS];
//    int state_count = 0;
//
//    const int total_frames = MAX_FRAMES; // 实际应根据输入调整
//
//    for (int frame = 0; frame < total_frames; frame++) {
//        // 添加根令牌
//        if (active_count < MAX_TOKENS) {
//            Token root_token = { graph->root, 0.0f, frame, 1 };
//            active_tokens[active_count++] = root_token;
//        }
//
//        next_count = 0;
//        state_count = 0;
//        for (int i = 0; i < active_count; i++) {
//            Token current = active_tokens[i];
//            ContextState* state = current.state;
//
//            for (int t = 0; t < MAX_TOKEN; t++) {
//                if (!state->next[t]) continue;
//
//                float score = current.score;
//                if (t != blank_idx) {
//                    score += logprobs[frame][t] + cb_weight;
//                }
//                else {
//                    score += logprobs[frame][t];
//                }
//
//                Token newToken = { state->next[t], score, current.start_frame, 1 };
//                update_token_list(next_tokens, &next_count, state_list, &state_count, newToken);
//
//                // 检测是否到达终止状态
//                if (state->next[t]->isEnd && score > -5.0f) { // keyword_threshold
//                    if (*hyp_count < MAX_HYPS) {
//                        WSHyp hyp;
//                        strncpy(hyp.word, state->next[t]->phrase, MAX_PHRASE_LEN);
//                        hyp.score = score;
//                        hyp.start_frame = current.start_frame;
//                        hyp.end_frame = frame;
//                        output_hyps[(*hyp_count)++] = hyp;
//                    }
//                }
//            }
//        }
//
//        // 执行剪枝
//        beam_pruning(next_tokens, &next_count, beam_threshold);
//        state_pruning(next_tokens, &next_count);
//
//        // 准备下一帧
//        memcpy(active_tokens, next_tokens, next_count * sizeof(Token));
//        active_count = next_count;
//    }
//}
//
//// 示例初始化
//void init_sample_graph(ContextGraph* graph) {
//    // 初始化图结构，添加示例状态
//    IMediaInitContextState(&graph->nodePool[0], 0, -1, 0, 0, 0, 0, 0, "", 1.0f);
//    graph->root = &graph->nodePool[0];
//    graph->numNodes = 1;
//
//    // 添加示例短语状态
//    int sample_tokens[] = { 'H', 'E', 0 };
//    const char* phrase = "HE";
//    ContextState* current = graph->root;
//    for (int i = 0; sample_tokens[i] != 0; i++) {
//        ContextState* next = &graph->nodePool[graph->numNodes++];
//        IMediaInitContextState(next, graph->numNodes - 1, sample_tokens[i],
//            1.0f, 1.0f, 1.0f, sample_tokens[i + 1] == 0,
//            i + 1, (sample_tokens[i + 1] == 0) ? phrase : "", 1.0f);
//        current->next[sample_tokens[i]] = next;
//        current = next;
//    }
//}
//
//int main() {
//    ContextGraph graph;
//    WSHyp output_hyps[MAX_HYPS];
//    int hyp_count = 0;
//    float sample_logprobs[MAX_FRAMES][MAX_TOKEN] = { 0 };
//    int ids_to_tokens[MAX_TOKEN] = { 0 };
//
//    init_sample_graph(&graph);
//    run_word_spotter(sample_logprobs, &graph, 0, 10.0f, 3.0f, output_hyps, &hyp_count);
//
//    printf("Detected %d hypotheses:\n", hyp_count);
//    for (int i = 0; i < hyp_count; i++) {
//        printf("Word: %s, Score: %.2f, Frames: %d-%d\n",
//            output_hyps[i].word, output_hyps[i].score,
//            output_hyps[i].start_frame, output_hyps[i].end_frame);
//    }
//
//    return 0;
//}
