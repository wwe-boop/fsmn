/*========================================================================*/
/**
\file imedia_aes_eai_vec.cpp

    Copyright (c) Honor Device Co., Ltd. 2021-2024.
    All rights reserved.
\author honor
\date 2024-06-28 11:16:16
*/
/*========================================================================*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "imedia_encoder_eai_vec.h"
#include "imedia_encoder_eai_define.h"
#include "imedia_command_define.h"
#include "imedia_kwsnnse_typedef.h"
#include "imedia_common_basicop.h"

// Set eNPU core selection/affinity (optional)
// Below is an example for setting hard affinity on the most powerful core of the platform
EAI_RESULT ImediaEncoderSetMlaAffinity(STRU_ENCODER_EAI_CONTEXT *context)
{
    int eaiRet;

    // Get the number of cores
    uint32_t num_cores = 0;
    eaiRet = eai_get_property(context->eai_handle, EAI_PROP_MLA_NUM, &num_cores);

    // Loop through all cores to find the big core based on MAC
    uint32_t big_core_mac = 0;
    uint32_t big_core_id = 0;
    for (int i = 0; i < num_cores; i++) {
        eai_mla_core_info_t core_info = {0};
        core_info.id = i;
        eaiRet = eai_get_property(context->eai_handle, EAI_PROP_MLA_CORE_INFO, &core_info);

        if (core_info.mac > big_core_mac) {
            big_core_mac = core_info.mac;
            big_core_id = core_info.id;
        }
    }

    // Initialize default values for core selection/affinity
    eai_mla_affinity_t client_affinity;
    client_affinity.core_selection = 0u;
    client_affinity.affinity = EAI_MLA_AFFINITY_SOFT;

    // Set big core & hard affinity
    client_affinity.core_selection = 1 << big_core_id;
    client_affinity.affinity = EAI_MLA_AFFINITY_HARD;
    eaiRet = eai_set_property(context->eai_handle, EAI_PROP_MLA_AFFINITY, &client_affinity);

    if (eaiRet != 0) {
        return EAI_FAIL;
    } else {
        return EAI_SUCCESS;
    }
}

// Perform EAI-INIT, EAI-APPLY
int IMediaEncoderEaiInit(STRU_KDNR_CHAN* pstKdnrChanl, unsigned char* baseAddr, eaiModel* pEaiModel)
{
    if (baseAddr == NULL) {
        return -1;
    }
    STRU_ENCODER_EAI_CONTEXT *pstEncoderContext;
    pstEncoderContext = &pstKdnrChanl->stEncoderEai;
    EAI_RESULT eai_ret;

    unsigned int  eaiInitFlags;
    eai_memory_info_t scratchMemory;
    eai_memory_info_t persistentMemory;
    eai_memory_info_t modelBuffer = {0};
    eai_client_perf_config_t clientPerfConfig;

    unsigned char* encoderEnpuModelBuffer = baseAddr + pEaiModel->modelAddr;
    unsigned char* encoderEnpuScratchBuffer = baseAddr +  pEaiModel->scratchAddr;
    unsigned char* encoderEnpuPersistentBuffer = baseAddr +  pEaiModel->persistentAddr;
    unsigned char* encoderEnpuIOBuffer = baseAddr +  pEaiModel->ioMemAddr;
    int enpuIOOffset = 0;

    // load model file into a model channel pointer, and align the model buffer to 256 byte.
    // perform EAI-INIT.
    eaiInitFlags            = EAI_INIT_FLAGS_DISABLE_ASYNC; // Disable Asynchronous processing by default.
    modelBuffer.addr        = encoderEnpuModelBuffer;  // model buffer
    modelBuffer.memory_size = pEaiModel->modelSize; // eai + pad
    modelBuffer.memory_type = ENCODER_MODEL_BUFFER_MEM_TYPE;

    eai_ret = eai_init(&pstEncoderContext->eai_handle, &modelBuffer, eaiInitFlags);

    pstKdnrChanl->sEaiInitFlag = eai_ret;
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // get scratch buffer info and set scratch buffer for eai api.
    eai_ret = eai_get_property(pstEncoderContext->eai_handle, EAI_PROP_SCRATCH_MEM, &scratchMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    if (scratchMemory.memory_size > pEaiModel->scratchSize) {
        return -1;
    }
    scratchMemory.addr = encoderEnpuScratchBuffer;
    scratchMemory.memory_type = ENCODER_SCRATCH_BUFFER_MEM_TYPE;

    eai_ret = eai_set_property(pstEncoderContext->eai_handle, EAI_PROP_SCRATCH_MEM, &scratchMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // get persistent buffer info, Set persistent buffer for eai api.
    eai_ret = eai_get_property(pstEncoderContext->eai_handle, EAI_PROP_PERSISTENT_MEM, &persistentMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    if (persistentMemory.memory_size > pEaiModel->persistentSize) {
        return -1;
    }
    persistentMemory.addr =  encoderEnpuPersistentBuffer;
    persistentMemory.memory_type = ENCODER_PERSISTENT_BUFFER_MEM_TYPE;

    eai_ret = eai_set_property(pstEncoderContext->eai_handle, EAI_PROP_PERSISTENT_MEM, &persistentMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Set client perf config (optional), Initialize default values for client_perf_config.
    clientPerfConfig.fps = 1u;
    clientPerfConfig.ftrt_ratio = 10u;
    clientPerfConfig.priority = EAI_CLIENT_PRIORITY_DEFAULT;
    clientPerfConfig.flags = 0x0;
    eai_ret = eai_set_property(pstEncoderContext->eai_handle, EAI_PROP_CLIENT_PERF_CFG, &clientPerfConfig);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Set core selection/affinity (optional)
    eai_ret = ImediaEncoderSetMlaAffinity(pstEncoderContext);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // perform EAI-APPLY, Applies configuration settings.
    eai_ret = eai_apply(pstEncoderContext->eai_handle);
    pstKdnrChanl->sEaiApplyFlag = eai_ret;
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Get model I/O tensor information and allocate them.
    for (int i = 0; i < 2; i++) { // 2 index
        eai_ports_info_t ports_info;
        ports_info.input_or_output = i;
        eai_ret = eai_get_property(pstEncoderContext->eai_handle, EAI_PROP_PORTS_NUM, &ports_info);
        if (eai_ret != EAI_SUCCESS) {
            return -1;
        }
        pstEncoderContext->tensor_count[i] = ports_info.size;
        pstEncoderContext->tensors[i] = (eai_tensor_info_t *)(encoderEnpuIOBuffer + enpuIOOffset);
        enpuIOOffset += ports_info.size * sizeof(eai_tensor_info_t);
        if (enpuIOOffset > pEaiModel->ioMemSize) {
            return -1;
        }

        for (int j = 0; j < ports_info.size; j++) {
            pstEncoderContext->tensors[i][j].index = j;
            pstEncoderContext->tensors[i][j].input_or_output = i;
            eai_ret = eai_get_property(pstEncoderContext->eai_handle, EAI_PROP_TENSOR_INFO, &(pstEncoderContext->tensors[i][j]));
            if (eai_ret != EAI_SUCCESS) {
                return -1;
            }
        }
        pstEncoderContext->eai_buffers[i] = (eai_buffer_info_t *)(encoderEnpuIOBuffer + enpuIOOffset);
        enpuIOOffset += sizeof(eai_tensor_info_t) * pstEncoderContext->tensor_count[i];
        if (enpuIOOffset > pEaiModel->ioMemSize) {
            return -1;
        }
    }

    pstKdnrChanl->encoderInBuf = (short*)encoderEnpuIOBuffer + enpuIOOffset;
    enpuIOOffset += pstKdnrChanl->modelParam.encoderInFrameBufSize * IMEDIA_FBANK_FEATURE_LEN*2;

    pstKdnrChanl->shareEncoderInBuf = (short*)pstEncoderContext->tensors[0][0].address;
    pstKdnrChanl->cacheBuf1 = (short*)pstEncoderContext->tensors[0][1].address;
    pstKdnrChanl->cacheBuf2 = (short*)pstEncoderContext->tensors[0][2].address;

    return eai_ret;
}

int IMediaEncoderEaiReset(STRU_KDNR_CHAN* pstKdnrChanl) {
    EAI_RESULT eai_result = EAI_SUCCESS;
    eai_layer_reset_t prop_info;
    prop_info.flags = EAI_LAYER_RESET_FLAGS_ALL;
    prop_info.reset_layer_idx = -1;
    STRU_ENCODER_EAI_CONTEXT* pstEncoderContext;
    pstEncoderContext = &pstKdnrChanl->stEncoderEai;
    eai_result = eai_reset(pstEncoderContext->eai_handle, (void*)&prop_info);
    if (eai_result != EAI_SUCCESS) {
        return -1;
    }
    return eai_result;
}

// Perform EAI-EXECUTE.
int IMediaEncoderEaiExec(STRU_KDNR_CHAN* pstKdnrChanl, int16_t **pOut)
{
    STRU_ENCODER_EAI_CONTEXT *pstEncoderContext;
    pstEncoderContext = &pstKdnrChanl->stEncoderEai;
    EAI_RESULT eai_ret;
    int i;
    int j;

    // cache
    if((*(short *)pstEncoderContext->tensors[1][1].address) >= 32767) {
        AudioCommonVecSetInt8((signed char *)pstEncoderContext->tensors[1][1].address, (size_t)(pstEncoderContext->tensors[1][1].tensor_size), 0);
    }
    AudioCommonVecCopyUInt8(pstEncoderContext->tensors[1][1].address, (size_t)(pstEncoderContext->tensors[0][1].tensor_size), pstEncoderContext->tensors[0][1].address);
    AudioCommonVecCopyUInt8(pstEncoderContext->tensors[1][2].address, (size_t)(pstEncoderContext->tensors[0][2].tensor_size), pstEncoderContext->tensors[0][2].address);

    // Prepare eai buffers consumed by eai_execute()
    for (i = 0; i < 2; i++) {
        for (j = 0; j < pstEncoderContext->tensor_count[i]; j++) {
            eai_tensor_info_t *tensor = &(pstEncoderContext->tensors[i][j]);
            pstEncoderContext->eai_buffers[i][j].index = j;
            pstEncoderContext->eai_buffers[i][j].element_type = tensor->element_type;
            pstEncoderContext->eai_buffers[i][j].addr = tensor->address;
            pstEncoderContext->eai_buffers[i][j].buffer_size = tensor->tensor_size;
            pstEncoderContext->eai_buffers[i][j].memory_type = ENCODER_SCRATCH_BUFFER_MEM_TYPE;
        }
    }

    pstEncoderContext->eai_batch.num_inputs = pstEncoderContext->tensor_count[0];
    pstEncoderContext->eai_batch.num_outputs = pstEncoderContext->tensor_count[1];
    pstEncoderContext->eai_batch.inputs = &(pstEncoderContext->eai_buffers[0][0]);
    pstEncoderContext->eai_batch.outputs = &(pstEncoderContext->eai_buffers[1][0]);

    eai_ret = eai_execute(pstEncoderContext->eai_handle, &pstEncoderContext->eai_batch, 1);
    pstKdnrChanl->sEaiExecFlag = eai_ret;
    *pOut = (int16_t*)pstEncoderContext->tensors[1][0].address;
    pstKdnrChanl->endEncoderExec = 1;
    return eai_ret;
}

// Perform EAI-DEINIT and free allocated context memory
int IMediaEncoderEaiDeInit(STRU_KDNR_CHAN* pstKdnrChanl)
{
    int ret;
    STRU_ENCODER_EAI_CONTEXT *pstEncoderContext;
    pstEncoderContext = &pstKdnrChanl->stEncoderEai;
    ret = eai_deinit(pstEncoderContext->eai_handle);

    return ret;
}
