/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2024-2024. All rights reserved.
 * Description: imedia_fbank_extractor.c - 新的Fbank特征提取实现
 * 基于test_feature_extraction.cpp的验证实现
 *****************************************************************************/
#include "imedia_fbank_extractor.h"
#include "imedia_common_define.h"
#include "imedia_command_define.h"
#include "imedia_common_basicop.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// 全局变量
#define FFT_OUT_SIZE 257  // (512/2 + 1)
static float mel_banks[IMEDIA_FBANK_FEATURE_LEN][FFT_OUT_SIZE];
static float hamming_window[IMEDIA_ASR_FRAMES_16K];
static int fbank_initialized = 0;

// Mel scale conversion functions
static float hz_to_mel(float hz) {
    return 1127.0f * logf(1.0f + hz / 700.0f);
}

// 注释掉未使用的函数以消除编译警告
// static float mel_to_hz(float mel) {
//     return 700.0f * (expf(mel / 1127.0f) - 1.0f);
// }

// 初始化Hamming窗
static void init_hamming_window(void) {
    for (int i = 0; i < IMEDIA_ASR_FRAMES_16K; i++) {
        hamming_window[i] = 0.54f - 0.46f * cosf(2.0f * M_PI * i / (IMEDIA_ASR_FRAMES_16K - 1));
    }
}

// 初始化Mel滤波器组 - 与C++ Test完全一致的实现
static void init_mel_banks(void) {
    float nyquist = IMEDIA_16K_SAMPLE_RATE / 2.0f;
    float high_freq = nyquist;  // 使用Nyquist频率 (与C++ Test一致)
    float low_freq = IMEDIA_MEL_LOW_FREQ;

    // 计算FFT bins - 与C++ Test完全一致
    int num_fft_bins = IMEDIA_FFT_LEN_16K / 2;  // 256

    printf("=== C Source Mel Filter Bank Construction (C++ Test compatible) ===\n");
    printf("Sample rate: %d\n", IMEDIA_16K_SAMPLE_RATE);
    printf("Nyquist freq: %.1f\n", nyquist);
    printf("Low freq: %.1f Hz\n", low_freq);
    printf("High freq: %.1f Hz\n", high_freq);
    printf("FFT size: %d\n", IMEDIA_FFT_LEN_16K);
    printf("Num FFT bins: %d\n", num_fft_bins);
    printf("Mel bins: %d\n", IMEDIA_FBANK_FEATURE_LEN);

    // 与C++ Test完全一致的实现
    float mel_low_freq = hz_to_mel(low_freq);
    float mel_high_freq = hz_to_mel(high_freq);
    float mel_freq_delta = (mel_high_freq - mel_low_freq) / (IMEDIA_FBANK_FEATURE_LEN + 1);

    // fft-bin width - 与C++ Test一致
    float fft_bin_width = (float)IMEDIA_16K_SAMPLE_RATE / IMEDIA_FFT_LEN_16K;

    // 初始化所有滤波器为0
    memset(mel_banks, 0, sizeof(mel_banks));

    for (int m = 0; m < IMEDIA_FBANK_FEATURE_LEN; m++) {
        // 计算left, center, right mel频率 - 与C++ Test一致
        float left_mel = mel_low_freq + m * mel_freq_delta;
        float center_mel = mel_low_freq + (m + 1) * mel_freq_delta;
        float right_mel = mel_low_freq + (m + 2) * mel_freq_delta;

        // 调试前几个mel滤波器的构造
        if (m < 5) {
            printf("Mel filter %d: left_mel=%.2f, center_mel=%.2f, right_mel=%.2f\n",
                   m, left_mel, center_mel, right_mel);
        }

        // 对每个FFT bin计算滤波器响应 - 与C++ Test完全一致
        for (int k = 0; k < num_fft_bins + 1; k++) {  // +1 for padding
            float mel_k = hz_to_mel(fft_bin_width * k);

            // 计算上升斜坡和下降斜坡 - 与C++ Test一致
            float up_slope = (mel_k - left_mel) / (center_mel - left_mel);
            float down_slope = (right_mel - mel_k) / (right_mel - center_mel);

            // 取最小值并限制为非负 (与C++ Test一致)
            float response = fmaxf(0.0f, fminf(up_slope, down_slope));
            mel_banks[m][k] = response;
        }

        // 显示前几个mel滤波器的非零系数
        if (m < 5) {
            printf("  Non-zero coeffs: ");
            int count = 0;
            for (int k = 0; k < num_fft_bins + 1 && count < 5; k++) {
                if (mel_banks[m][k] > 0.0f) {
                    printf("k%d=%.6f ", k, mel_banks[m][k]);
                    count++;
                }
            }
            printf("\n");
        }
    }
}

// 初始化Fbank提取器
void IMediaFbankExtractorInit(void) {
    if (!fbank_initialized) {
        init_hamming_window();
        init_mel_banks();
        fbank_initialized = 1;
        printf("Fbank extractor initialized with Python-compatible implementation\n");
    }
}

// 去除DC偏移
static void remove_dc_offset(float* frame, int frame_len) {
    float mean = 0.0f;
    for (int i = 0; i < frame_len; i++) {
        mean += frame[i];
    }
    mean /= frame_len;
    
    for (int i = 0; i < frame_len; i++) {
        frame[i] -= mean;
    }
}

// 预加重处理 - 与C++ Test完全一致的replicate padding
static void apply_preemphasis(float* frame, int frame_len, float coeff) {
    if (coeff == 0.0f) return;

    // 创建offset frame (replicate padding) - 与C++ Test一致
    float* offset_frame = (float*)malloc((frame_len + 1) * sizeof(float));
    offset_frame[0] = frame[0];  // replicate first sample (与C++ Test一致)
    memcpy(offset_frame + 1, frame, frame_len * sizeof(float));

    // 应用预加重 - 与C++ Test完全一致的公式
    for (int i = 0; i < frame_len; i++) {
        frame[i] = frame[i] - coeff * offset_frame[i];
    }

    free(offset_frame);
}

// 应用窗函数
static void apply_window(float* frame, int frame_len) {
    for (int i = 0; i < frame_len; i++) {
        frame[i] *= hamming_window[i];
    }
}

// FFT实现 - 与C++ Test完全一致的Cooley-Tukey算法
static void fft_recursive(float* real, float* imag, int n, int stride, float* temp_real, float* temp_imag) {
    if (n == 1) return;

    int half = n / 2;

    // 分离偶数和奇数索引
    for (int i = 0; i < half; i++) {
        temp_real[i] = real[i * 2 * stride];
        temp_imag[i] = imag[i * 2 * stride];
        temp_real[i + half] = real[(i * 2 + 1) * stride];
        temp_imag[i + half] = imag[(i * 2 + 1) * stride];
    }

    // 复制回原数组
    for (int i = 0; i < n; i++) {
        real[i * stride] = temp_real[i];
        imag[i * stride] = temp_imag[i];
    }

    // 递归调用
    fft_recursive(real, imag, half, stride, temp_real, temp_imag);
    fft_recursive(real + half * stride, imag + half * stride, half, stride, temp_real, temp_imag);

    // 合并结果
    const float PI = 3.14159265358979323846f;
    for (int i = 0; i < half; i++) {
        float angle = -2.0f * PI * i / n;
        float cos_val = cosf(angle);
        float sin_val = sinf(angle);

        float t_real = cos_val * real[(i + half) * stride] - sin_val * imag[(i + half) * stride];
        float t_imag = sin_val * real[(i + half) * stride] + cos_val * imag[(i + half) * stride];

        float u_real = real[i * stride];
        float u_imag = imag[i * stride];

        real[i * stride] = u_real + t_real;
        imag[i * stride] = u_imag + t_imag;
        real[(i + half) * stride] = u_real - t_real;
        imag[(i + half) * stride] = u_imag - t_imag;
    }
}

static void compute_power_spectrum(float* frame, int frame_len, float* power_spectrum) {
    // 使用与C++ Test完全一致的FFT实现
    int fft_size = IMEDIA_FFT_LEN_16K;  // 512

    // 分配FFT数据
    float* fft_real = (float*)calloc(fft_size, sizeof(float));
    float* fft_imag = (float*)calloc(fft_size, sizeof(float));
    float* temp_real = (float*)malloc(fft_size * sizeof(float));
    float* temp_imag = (float*)malloc(fft_size * sizeof(float));

    // 复制输入数据
    for (int i = 0; i < frame_len; i++) {
        fft_real[i] = frame[i];
        fft_imag[i] = 0.0f;
    }
    // 零填充已经通过calloc完成

    // 执行FFT
    fft_recursive(fft_real, fft_imag, fft_size, 1, temp_real, temp_imag);

    // 计算功率谱
    for (int i = 0; i < FFT_OUT_SIZE; i++) {
        float magnitude = sqrtf(fft_real[i] * fft_real[i] + fft_imag[i] * fft_imag[i]);
        power_spectrum[i] = magnitude * magnitude;  // 功率 = magnitude^2
    }

    free(fft_real);
    free(fft_imag);
    free(temp_real);
    free(temp_imag);
}

// 应用Mel滤波器组
static void apply_mel_filters(float* power_spectrum, float* mel_features) {
    for (int m = 0; m < IMEDIA_FBANK_FEATURE_LEN; m++) {
        float energy = 0.0f;
        for (int k = 0; k < FFT_OUT_SIZE; k++) {
            energy += power_spectrum[k] * mel_banks[m][k];
        }
        
        // 防止log(0)
        energy = fmaxf(energy, IMEDIA_EPSILON);
        mel_features[m] = logf(energy);
    }
}

// 主要的特征提取函数
int IMediaFbankExtractFrame(STRU_KDNR_CHAN* pChnal, short* audio_frame) {
    if (!fbank_initialized) {
        IMediaFbankExtractorInit();
    }
    
    // 转换为浮点数
    float frame[IMEDIA_ASR_FRAMES_16K];
    for (int i = 0; i < IMEDIA_ASR_FRAMES_16K; i++) {
        frame[i] = (float)audio_frame[i];
    }
    
    // 1. 去除DC偏移
    remove_dc_offset(frame, IMEDIA_ASR_FRAMES_16K);
    
    // 2. 预加重
    apply_preemphasis(frame, IMEDIA_ASR_FRAMES_16K, 0.97f);
    
    // 3. 应用窗函数
    apply_window(frame, IMEDIA_ASR_FRAMES_16K);
    
    // 4. 计算功率谱
    compute_power_spectrum(frame, IMEDIA_ASR_FRAMES_16K, pChnal->powerBuf);
    
    // 5. 应用Mel滤波器组
    apply_mel_filters(pChnal->powerBuf, pChnal->fBankOut);
    
    return 0;
}
