/*========================================================================*/
/**
\file imedia_aes_eai_vec.cpp

    Copyright (c) Honor Device Co., Ltd. 2021-2024.
    All rights reserved.
\author honor
\date 2024-06-28 11:16:16
*/
/*========================================================================*/
#include <stdio.h>
#include <string.h>

#include "imedia_joiner_eai_vec.h"
#include "imedia_joiner_eai_define.h"
#include "imedia_command_define.h"
#include "imedia_kwsnnse_typedef.h"
#include "imedia_common_basicop.h"

#include <math.h>

// Set eNPU core selection/affinity (optional)
// Below is an example for setting hard affinity on the most powerful core of the platform
EAI_RESULT ImediaJoinerSetMlaAffinity(STRU_JOINER_EAI_CONTEXT *context)
{
    int eai_ret;

    // Get the number of cores
    uint32_t num_cores = 0;
    eai_ret = eai_get_property(context->eai_handle, EAI_PROP_MLA_NUM, &num_cores);

    // Loop through all cores to find the big core based on MAC
    uint32_t big_core_mac = 0;
    uint32_t big_core_id = 0;
    for (int i = 0; i < num_cores; i++) {
        eai_mla_core_info_t core_info = {0};
        core_info.id = i;
        eai_ret = eai_get_property(context->eai_handle, EAI_PROP_MLA_CORE_INFO, &core_info);

        if (core_info.mac > big_core_mac) {
            big_core_mac = core_info.mac;
            big_core_id = core_info.id;
        }
    }

    // Initialize default values for core selection/affinity
    eai_mla_affinity_t client_affinity;
    client_affinity.core_selection = 0u;
    client_affinity.affinity = EAI_MLA_AFFINITY_SOFT;

    // Set big core & hard affinity
    client_affinity.core_selection = 1 << big_core_id;
    client_affinity.affinity = EAI_MLA_AFFINITY_HARD;
    eai_ret = eai_set_property(context->eai_handle, EAI_PROP_MLA_AFFINITY, &client_affinity);

    if (eai_ret != 0) {
        return EAI_FAIL;
    } else {
        return EAI_SUCCESS;
    }
}

// Perform EAI-INIT, EAI-APPLY
int IMediaJoinerEaiInit(STRU_KDNR_CHAN* pstKdnrChanl, unsigned char* baseAddr, eaiModel* pEaiModel)
{
    if (baseAddr == NULL) {
        return -1;
    }
    STRU_JOINER_EAI_CONTEXT *pstJoinerContext;
    pstJoinerContext = &pstKdnrChanl->stJoinerEai;
    EAI_RESULT eai_ret;

    unsigned int  eaiInitFlags;
    eai_memory_info_t scratchMemory;
    eai_memory_info_t persistentMemory;
    eai_memory_info_t modelBuffer = {0};
    eai_client_perf_config_t clientPerfConfig;

    unsigned char* joinerEnpuModelBuffer = baseAddr + pEaiModel->modelAddr;
    unsigned char* joinerEnpuScratchBuffer = baseAddr + pEaiModel->scratchAddr;
    unsigned char* joinerEnpuPersistentBuffer = baseAddr + pEaiModel->persistentAddr;
    unsigned char* joinerEnpuIOBuffer = baseAddr + pEaiModel->ioMemAddr;
    int enpuIOOffset = 0;

    // load model file into a model channel pointer, and align the model buffer to 256 byte.
    // perform EAI-INIT.
    eaiInitFlags            = EAI_INIT_FLAGS_DISABLE_ASYNC; // Disable Asynchronous processing by default.
    modelBuffer.addr        = joinerEnpuModelBuffer;  // model buffer
    modelBuffer.memory_size = pEaiModel->modelSize;;
    modelBuffer.memory_type = JOINER_MODEL_BUFFER_MEM_TYPE;

    eai_ret = eai_init(&pstJoinerContext->eai_handle, &modelBuffer, eaiInitFlags);
    pstKdnrChanl->sEaiInitFlag = eai_ret;
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }

    // get scratch buffer info and set scratch buffer for eai api.
    eai_ret = eai_get_property(pstJoinerContext->eai_handle, EAI_PROP_SCRATCH_MEM, &scratchMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    if (scratchMemory.memory_size > pEaiModel->scratchSize) {
        return -1;
    }
    scratchMemory.addr = joinerEnpuScratchBuffer;
    scratchMemory.memory_type = JOINER_SCRATCH_BUFFER_MEM_TYPE;
    eai_ret = eai_set_property(pstJoinerContext->eai_handle, EAI_PROP_SCRATCH_MEM, &scratchMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }

    // get persistent buffer info, Set persistent buffer for eai api.
    eai_ret = eai_get_property(pstJoinerContext->eai_handle, EAI_PROP_PERSISTENT_MEM, &persistentMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    if (persistentMemory.memory_size > pEaiModel->persistentSize) {
        return -1;
    }
    // persistentMemory.memory_size get for eai_get_property().
    persistentMemory.addr = joinerEnpuPersistentBuffer;
    persistentMemory.memory_type = JOINER_PERSISTENT_BUFFER_MEM_TYPE;
    eai_ret = eai_set_property(pstJoinerContext->eai_handle, EAI_PROP_PERSISTENT_MEM, &persistentMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }

    // Set client perf config (optional), Initialize default values for client_perf_config.
    clientPerfConfig.fps = 1u;
    clientPerfConfig.ftrt_ratio = 10u;
    clientPerfConfig.priority = EAI_CLIENT_PRIORITY_DEFAULT;
    clientPerfConfig.flags = 0x0;
    eai_ret = eai_set_property(pstJoinerContext->eai_handle, EAI_PROP_CLIENT_PERF_CFG, &clientPerfConfig);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Set core selection/affinity (optional) ѡ��С��
    eai_ret = ImediaJoinerSetMlaAffinity(pstJoinerContext);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // perform EAI-APPLY, Applies configuration settings.
    eai_ret = eai_apply(pstJoinerContext->eai_handle);
    pstKdnrChanl->sEaiApplyFlag = eai_ret;
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Get model I/O tensor information and allocate them.
    for (int i = 0; i < 2; i++) { // 2 index
        eai_ports_info_t ports_info;
        ports_info.input_or_output = i;
        eai_ret = eai_get_property(pstJoinerContext->eai_handle, EAI_PROP_PORTS_NUM, &ports_info);
        if (eai_ret != EAI_SUCCESS) {
            return -1;
        }
        pstJoinerContext->tensor_count[i] = ports_info.size;
        pstJoinerContext->tensors[i] = (eai_tensor_info_t *)(joinerEnpuIOBuffer + enpuIOOffset);
        enpuIOOffset += ports_info.size * sizeof(eai_tensor_info_t);
        if (enpuIOOffset > pEaiModel->ioMemSize) {
            return -1;
        }
        for (int j = 0; j < ports_info.size; j++) {
            pstJoinerContext->tensors[i][j].index = j;
            pstJoinerContext->tensors[i][j].input_or_output = i;
            eai_ret = eai_get_property(pstJoinerContext->eai_handle, EAI_PROP_TENSOR_INFO, &(pstJoinerContext->tensors[i][j]));
            if (eai_ret != EAI_SUCCESS) {
                return -1;
            }
        }
        pstJoinerContext->eai_buffers[i] = (eai_buffer_info_t *)(joinerEnpuIOBuffer + enpuIOOffset);
        enpuIOOffset += sizeof(eai_tensor_info_t) * pstJoinerContext->tensor_count[i];
        if (enpuIOOffset > pEaiModel->ioMemSize) {
            return -1;
        }
    }

    pstKdnrChanl->sym2id = (StringIntPair*)(joinerEnpuIOBuffer + enpuIOOffset);
    enpuIOOffset += sizeof(StringIntPair) * pstKdnrChanl->modelParam.vocabSize;
    return eai_ret;
}

int IMediaJoinerEaiExec(STRU_KDNR_CHAN* pstKdnrChanl, int16_t* pEncoderOut, int16_t* pDecoderOut, int16_t** pJoinerOut)
{
    STRU_JOINER_EAI_CONTEXT *pstJoinerContext;
    pstJoinerContext = &pstKdnrChanl->stJoinerEai;
    EAI_RESULT eai_ret;
    int i;
    int j;

    AudioCommonVecCopyUInt8((uint8_t*)pEncoderOut, (size_t)(pstJoinerContext->tensors[0][0].tensor_size), pstJoinerContext->tensors[0][0].address);
    AudioCommonVecCopyUInt8((uint8_t*)pDecoderOut, (size_t)(pstJoinerContext->tensors[0][1].tensor_size), pstJoinerContext->tensors[0][1].address);

    for (i = 0; i < 2; i++) {
        for (j = 0; j < pstJoinerContext->tensor_count[i]; j++) {
            eai_tensor_info_t *tensor = &(pstJoinerContext->tensors[i][j]);
            pstJoinerContext->eai_buffers[i][j].index = j;
            pstJoinerContext->eai_buffers[i][j].element_type = tensor->element_type;
            pstJoinerContext->eai_buffers[i][j].addr = tensor->address;
            pstJoinerContext->eai_buffers[i][j].buffer_size = tensor->tensor_size;
            pstJoinerContext->eai_buffers[i][j].memory_type = JOINER_SCRATCH_BUFFER_MEM_TYPE;
        }
    }
    pstJoinerContext->eai_batch.num_inputs = pstJoinerContext->tensor_count[0];
    pstJoinerContext->eai_batch.num_outputs = pstJoinerContext->tensor_count[1];
    pstJoinerContext->eai_batch.inputs = &(pstJoinerContext->eai_buffers[0][0]);
    pstJoinerContext->eai_batch.outputs = &(pstJoinerContext->eai_buffers[1][0]);

    // model output.
    eai_ret = eai_execute(pstJoinerContext->eai_handle, &pstJoinerContext->eai_batch, 1);
    pstKdnrChanl->sEaiExecFlag = eai_ret;

    *pJoinerOut = (int16_t*)pstJoinerContext->tensors[1]->address;
    return eai_ret;
}

// Perform EAI-DEINIT and free allocated context memory
int IMediaJoinerEaiDeInit(STRU_KDNR_CHAN* pstKdnrChanl)
{
    int ret;
    STRU_JOINER_EAI_CONTEXT *pstJoinerContext;
    pstJoinerContext = &pstKdnrChanl->stJoinerEai;
    ret = eai_deinit(pstJoinerContext->eai_handle);

    return ret;
}
