/*========================================================================*/
/**
\file imedia_aes_eai_vec.cpp

    Copyright (c) Honor Device Co., Ltd. 2021-2024.
    All rights reserved.
\author honor
\date 2024-06-28 11:16:16
*/
/*========================================================================*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "imedia_vad_eai_vec.h"
#include "imedia_vad_eai_define.h"
#include "imedia_command_define.h"
#include "imedia_kwsnnse_typedef.h"
#include "imedia_common_basicop.h"

// 全局调试标志
int g_vad_debug_mode = 0;  // 0: 关闭调试, 1: 开启调试

// Global cache state management for EAI API mode
#define CACHE_SIZE 2432  // 1*128*19*1 = 2432 float32 elements
static float* g_cache_states[4] = {NULL, NULL, NULL, NULL};  // 4 cache state buffers
static int g_cache_initialized = 0;  // Cache initialization status flag

// VAD相关常量定义
#define VAD_INPUT_FRAMES                      32     // VAD需要的输入帧数
#define VAD_LFR_FEATURE_LEN                   400    // 80 * 5 (LFR特征维度)
#define INT16_MAX_VAL                         32767
#define INT16_MIN_VAL                         -32768

// Quantization parameters for vad_quantized_fsmn.eai model compatibility (从模型获取的真实参数)
#define INPUT_SCALE         6.00272e-05f              // Input tensor[0] quantization scale (真实EAI参数)
#define INPUT_ZERO          -14101                    // Input tensor[0] zero point
#define CACHE_SCALE         0.00793469f               // Cache tensor[1-4] quantization scale
#define CACHE_ZERO          0                         // Cache tensor[1-4] zero point
#define OUTPUT_SCALE        0.000355226f              // Output tensor[0] dequantization scale (真实EAI参数)
#define OUTPUT_ZERO         -5571                     // Output tensor[0] zero point
// Cache输出scale (从模型信息获取)
#define CACHE_OUTPUT_SCALE  0.000243984f              // Output tensor[1] dequantization scale

// 全局变量存储Python特征
static float* g_python_features = NULL;
static int g_python_num_frames = 0;

// 量化和反量化函数声明
int16_t quantize_float_to_int16_with_zero(float value, float scale, int zero_point);
int16_t quantize_float_to_int16(float value, float scale);
float dequantize_int16_to_float_with_zero(int16_t quantized_value, float scale, int zero_point);
float dequantize_int16_to_float(int16_t quantized_value, float scale);
void quantize_features(float* input_features, int16_t* quantized_features, int rows, int cols, float scale);
void dequantize_output_with_zero(int16_t* quantized_output, float* float_output, int length, float scale, int zero_point);
void dequantize_output(int16_t* quantized_output, float* float_output, int length, float scale);

// 调试模式控制函数
void IMediaVadSetDebugMode(int enable_debug);
int IMediaVadGetDebugMode(void);

// Python特征文件读取函数
int load_python_features(const char* npy_file);

// Quantization and dequantization function implementations
/**
 * Quantize float32 value to int16 with zero point
 * @param value Input float32 value
 * @param scale Quantization scale parameter
 * @param zero_point Zero point parameter
 * @return Quantized int16 value
 */
int16_t quantize_float_to_int16_with_zero(float value, float scale, int zero_point) {
    // 检查输入有效性
    if (scale <= 0.0f) {
        printf("警告: 量化scale值无效 (%.10f), 使用默认值\n", scale);
        scale = INPUT_SCALE;  // 使用默认scale
    }

    // EAI工具兼容的量化公式: quantized_value = round(float_value / scale + zero_point)
    float quantized_float = value / scale + (float)zero_point;

    // 检查是否会溢出
    if (quantized_float > (float)INT16_MAX_VAL || quantized_float < (float)INT16_MIN_VAL) {
        // 记录溢出情况但不打印过多信息
        static int overflow_count = 0;
        if (overflow_count < 5) {  // 只打印前5次溢出
            printf("量化溢出: value=%.6f, scale=%.10f, zero=%d, quantized_float=%.2f\n",
                   value, scale, zero_point, quantized_float);
            overflow_count++;
        }
    }

    // Use EAI tool compatible rounding method
    int32_t quantized_int;
    float fractional_part = quantized_float - floorf(quantized_float);

    if (fractional_part >= 0.495f) {  // Optimal threshold for EAI tool compatibility
        quantized_int = (int32_t)ceilf(quantized_float);
    } else {
        quantized_int = (int32_t)floorf(quantized_float);
    }

    // 限制到int16范围 [-32768, 32767]
    if (quantized_int > INT16_MAX_VAL) quantized_int = INT16_MAX_VAL;
    if (quantized_int < INT16_MIN_VAL) quantized_int = INT16_MIN_VAL;

    return (int16_t)quantized_int;
}

/**
 * Quantize float32 value to int16 (兼容旧版本，无zero point)
 * @param value Input float32 value
 * @param scale Quantization scale parameter
 * @return Quantized int16 value
 */
int16_t quantize_float_to_int16(float value, float scale) {
    // 检查输入有效性
    if (scale <= 0.0f) {
        printf("警告: 量化scale值无效 (%.10f), 使用默认值\n", scale);
        scale = INPUT_SCALE;  // 使用默认scale
    }

    // 量化公式: quantized_value = round(float_value / scale)
    float quantized_float = value / scale;

    // 检查是否会溢出
    if (quantized_float > (float)INT16_MAX_VAL || quantized_float < (float)INT16_MIN_VAL) {
        // 记录溢出情况但不打印过多信息
        static int overflow_count = 0;
        if (overflow_count < 5) {  // 只打印前5次溢出
            printf("量化溢出: value=%.6f, scale=%.10f, quantized_float=%.2f\n",
                   value, scale, quantized_float);
            overflow_count++;
        }
    }

    // Use EAI tool compatible rounding method
    // Analysis shows optimal threshold of 0.495 for 99.80% match rate
    int32_t quantized_int;
    float fractional_part = quantized_float - floorf(quantized_float);

    if (fractional_part >= 0.495f) {  // Optimal threshold for EAI tool compatibility
        quantized_int = (int32_t)ceilf(quantized_float);
    } else {
        quantized_int = (int32_t)floorf(quantized_float);
    }

    // 限制到int16范围 [-32768, 32767]
    if (quantized_int > INT16_MAX_VAL) quantized_int = INT16_MAX_VAL;
    if (quantized_int < INT16_MIN_VAL) quantized_int = INT16_MIN_VAL;

    return (int16_t)quantized_int;
}

/**
 * 将int16值反量化为float32 (支持zero point)
 * @param quantized_value 量化的int16值
 * @param scale 反量化scale参数
 * @param zero_point zero point参数
 * @return 反量化后的float32值
 */
float dequantize_int16_to_float_with_zero(int16_t quantized_value, float scale, int zero_point) {
    // 反量化公式: float_value = (quantized_value - zero_point) * scale
    return (float)(quantized_value - zero_point) * scale;
}

/**
 * 将int16值反量化为float32 (兼容旧版本，无zero point)
 * @param quantized_value 量化的int16值
 * @param scale 反量化scale参数
 * @return 反量化后的float32值
 */
float dequantize_int16_to_float(int16_t quantized_value, float scale) {
    // 反量化公式: float_value = quantized_value * scale
    return (float)quantized_value * scale;
}

/**
 * 批量量化特征矩阵 (支持zero point)
 * @param input_features 输入的float32特征数组
 * @param quantized_features 输出的int16量化特征数组
 * @param rows 行数
 * @param cols 列数
 * @param scale 量化scale参数
 * @param zero_point zero point参数
 */
void quantize_features_with_zero(float* input_features, int16_t* quantized_features, int rows, int cols, float scale, int zero_point) {
    int total_elements = rows * cols;

    for (int i = 0; i < total_elements; i++) {
        quantized_features[i] = quantize_float_to_int16_with_zero(input_features[i], scale, zero_point);
    }

    if (g_vad_debug_mode) {
        printf("特征量化完成: %d个元素, scale=%.8f, zero=%d\n", total_elements, scale, zero_point);
        printf("  前5个量化值: %d %d %d %d %d\n",
               quantized_features[0], quantized_features[1], quantized_features[2],
               quantized_features[3], quantized_features[4]);
    }
}

/**
 * 批量量化特征矩阵 (兼容旧版本，无zero point)
 * @param input_features 输入的float32特征数组
 * @param quantized_features 输出的int16量化特征数组
 * @param rows 行数
 * @param cols 列数
 * @param scale 量化scale参数
 */
void quantize_features(float* input_features, int16_t* quantized_features, int rows, int cols, float scale) {
    int total_elements = rows * cols;

    for (int i = 0; i < total_elements; i++) {
        quantized_features[i] = quantize_float_to_int16(input_features[i], scale);
    }

    if (g_vad_debug_mode) {
        printf("量化完成: %d×%d 特征, scale=%.10f\n", rows, cols, scale);
    }
}

/**
 * 批量反量化输出数组 (int16版本)
 * @param quantized_output 输入的int16量化数组
 * @param float_output 输出的float32数组
 * @param length 数组长度
 * @param scale 反量化scale参数
 */
void dequantize_output(int16_t* quantized_output, float* float_output, int length, float scale) {
    for (int i = 0; i < length; i++) {
        float_output[i] = dequantize_int16_to_float(quantized_output[i], scale);
    }

    if (g_vad_debug_mode) {
        printf("反量化完成: %d 个元素, scale=%.10f\n", length, scale);
    }
}

/**
 * 批量反量化输出数组 (支持zero point)
 * @param quantized_output 输入的int16量化数组
 * @param float_output 输出的float32数组
 * @param length 数组长度
 * @param scale 反量化scale参数
 * @param zero_point zero point参数
 */
void dequantize_output_with_zero(int16_t* quantized_output, float* float_output, int length, float scale, int zero_point) {
    for (int i = 0; i < length; i++) {
        float_output[i] = dequantize_int16_to_float_with_zero(quantized_output[i], scale, zero_point);
    }

    if (g_vad_debug_mode) {
        printf("反量化完成: %d 个元素, scale=%.8f, zero=%d\n", length, scale, zero_point);
        printf("  前5个反量化值: %.6f %.6f %.6f %.6f %.6f\n",
               float_output[0], float_output[1], float_output[2], float_output[3], float_output[4]);
    }
}

/**
 * Sigmoid函数：将logits转换为概率
 * @param x 输入的logit值
 * @return 0-1之间的概率值
 */
float sigmoid(float x) {
    // 防止数值溢出
    if (x > 20.0f) return 1.0f;
    if (x < -20.0f) return 0.0f;
    return 1.0f / (1.0f + expf(-x));
}

/**
 * 批量将logits转换为概率
 * @param logits 输入的logit数组
 * @param probs 输出的概率数组
 * @param length 数组长度
 */
void logits_to_probs(float* logits, float* probs, int length) {
    for (int i = 0; i < length; i++) {
        probs[i] = sigmoid(logits[i]);
    }
}

/**
 * 设置VAD调试模式
 * @param enable_debug 1: 开启调试模式, 0: 关闭调试模式
 */
void IMediaVadSetDebugMode(int enable_debug) {
    g_vad_debug_mode = enable_debug;
    printf("VAD调试模式: %s\n", enable_debug ? "开启" : "关闭");
}

/**
 * 获取当前VAD调试模式状态
 * @return 1: 调试模式开启, 0: 调试模式关闭
 */
int IMediaVadGetDebugMode(void) {
    return g_vad_debug_mode;
}

/**
 * 加载Python特征文件 (简化的npy读取)
 * @param npy_file npy文件路径
 * @return 0成功，-1失败
 */
int load_python_features(const char* npy_file) {
    FILE* fp = fopen(npy_file, "rb");
    if (!fp) {
        printf(" 无法打开Python特征文件: %s\n", npy_file);
        return -1;
    }

    // 简化处理：跳过npy头部，直接读取float32数据
    // 标准npy文件头部通常是128字节左右，我们先尝试跳过128字节
    fseek(fp, 128, SEEK_SET);

    // 计算文件大小
    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    fseek(fp, 128, SEEK_SET);  // 回到数据开始位置

    long data_size = file_size - 128;
    int num_floats = data_size / sizeof(float);

    // 假设特征维度是400，计算帧数
    int expected_frames = num_floats / 400;

    printf(" 加载Python特征文件: %s\n", npy_file);
    printf("   文件大小: %ld 字节\n", file_size);
    printf("   数据大小: %ld 字节\n", data_size);
    printf("   预期帧数: %d\n", expected_frames);

    // 分配内存
    if (g_python_features) {
        free(g_python_features);
    }

    g_python_features = (float*)malloc(num_floats * sizeof(float));
    if (!g_python_features) {
        printf(" 内存分配失败\n");
        fclose(fp);
        return -1;
    }

    // 读取数据
    size_t read_count = fread(g_python_features, sizeof(float), num_floats, fp);
    fclose(fp);

    if (read_count != num_floats) {
        printf(" 读取数据失败: 期望%d，实际%zu\n", num_floats, read_count);
        free(g_python_features);
        g_python_features = NULL;
        return -1;
    }

    g_python_num_frames = expected_frames;

    // 显示特征统计信息
    float min_val = g_python_features[0], max_val = g_python_features[0];
    double sum = 0.0;
    for (int i = 0; i < num_floats; i++) {
        if (g_python_features[i] < min_val) min_val = g_python_features[i];
        if (g_python_features[i] > max_val) max_val = g_python_features[i];
        sum += g_python_features[i];
    }

    printf(" Python特征加载成功\n");
    printf("   帧数: %d\n", g_python_num_frames);
    printf("   特征维度: 400\n");
    printf("   数值范围: [%.6f, %.6f]\n", min_val, max_val);
    printf("   均值: %.6f\n", sum / num_floats);
    printf("   前5个值: %.6f %.6f %.6f %.6f %.6f\n",
           g_python_features[0], g_python_features[1], g_python_features[2],
           g_python_features[3], g_python_features[4]);

    return 0;
}

/**
 * Initialize cache states with zero initialization for consistency
 */
void init_cache_states(void) {
    if (g_cache_initialized) {
        return;  // Already initialized
    }

    for (int i = 0; i < 4; i++) {
        g_cache_states[i] = (float*)calloc(CACHE_SIZE, sizeof(float));
        if (g_cache_states[i] == NULL) {
            printf("[ERROR] Failed to allocate cache state memory for index %d\n", i);
            return;
        }
    }

    g_cache_initialized = 1;
    printf("[SUCCESS] Cache state initialization completed with zero initialization\n");

    // Debug verification of initialization results
    if (g_vad_debug_mode) {
        printf("[DEBUG] Cache initialization verification:\n");
        for (int i = 0; i < 4; i++) {
            if (g_cache_states[i] != NULL) {
                int non_zero_count = 0;
                for (int j = 0; j < 10; j++) {  // Check first 10 values
                    if (g_cache_states[i][j] != 0.0f) non_zero_count++;
                }
                printf("  g_cache_states[%d] non-zero count in first 10: %d\n", i, non_zero_count);
                printf("  First 5 values: %.6f %.6f %.6f %.6f %.6f\n",
                       g_cache_states[i][0], g_cache_states[i][1], g_cache_states[i][2],
                       g_cache_states[i][3], g_cache_states[i][4]);
            }
        }
    }
}

/**
 * Reset cache states to zero for each new block (Python-compatible)
 */
void reset_cache_states(void) {
    if (!g_cache_initialized) {
        init_cache_states();
        return;
    }

    // Reset all cache states to zero
    for (int i = 0; i < 4; i++) {
        if (g_cache_states[i] != NULL) {
            memset(g_cache_states[i], 0, CACHE_SIZE * sizeof(float));
        }
    }

    if (g_vad_debug_mode) {
        printf("[DEBUG] Cache states reset to zero for new block\n");
    }
}

/**
 * Copy global cache states to tensor inputs
 */
void copy_cache_to_tensors(STRU_VAD_EAI_CONTEXT* pstVadContext) {
    if (!g_cache_initialized) {
        init_cache_states();
    }

    if (g_vad_debug_mode) {
        printf("[DEBUG] Cache to tensor copy verification:\n");
    }

    // Copy cache states to input tensors (tensor[0][1-4])
    for (int i = 1; i < pstVadContext->tensor_count[0]; i++) {
        int cache_idx = i - 1;  // tensor[0][1] -> cache[0], tensor[0][2] -> cache[1], etc.

        if (cache_idx < 4 && g_cache_states[cache_idx] != NULL) {
            // Get tensor information
            int16_t* tensor_addr = (int16_t*)pstVadContext->tensors[0][i].address;
            int tensor_size_bytes = pstVadContext->tensors[0][i].tensor_size;
            int tensor_elements = tensor_size_bytes / sizeof(int16_t);

            // 确保不超过cache大小
            int copy_elements = (tensor_elements < CACHE_SIZE) ? tensor_elements : CACHE_SIZE;

            // 将float32 cache量化为int16并复制到tensor (使用cache专用scale)
            for (int j = 0; j < copy_elements; j++) {
                tensor_addr[j] = quantize_float_to_int16(g_cache_states[cache_idx][j], CACHE_SCALE);
            }

            if (g_vad_debug_mode) {
                printf("  tensor[0][%d] <- g_cache_states[%d] (%d elements)\n", i, cache_idx, copy_elements);
                printf("    源cache前5个值: %.6f %.6f %.6f %.6f %.6f\n",
                       g_cache_states[cache_idx][0], g_cache_states[cache_idx][1],
                       g_cache_states[cache_idx][2], g_cache_states[cache_idx][3],
                       g_cache_states[cache_idx][4]);
                printf("    目标tensor前5个值: %d %d %d %d %d\n",
                       tensor_addr[0], tensor_addr[1], tensor_addr[2], tensor_addr[3], tensor_addr[4]);
            }
        }
    }
}

/**
 * Update global cache states from tensor outputs
 */
void update_cache_from_tensors(STRU_VAD_EAI_CONTEXT* pstVadContext) {
    if (!g_cache_initialized) {
        printf("[WARNING] Cache not initialized, cannot update\n");
        return;
    }

    if (g_vad_debug_mode) {
        printf("[DEBUG] Updating cache states from tensors:\n");
    }

    // 从输出tensors更新cache状态 (tensor[1][1-4] -> cache[0-3])
    for (int i = 1; i < pstVadContext->tensor_count[1]; i++) {
        int cache_idx = i - 1;  // tensor[1][1] -> cache[0], tensor[1][2] -> cache[1], etc.

        if (cache_idx < 4 && g_cache_states[cache_idx] != NULL) {
            // 获取输出tensor信息
            int16_t* tensor_addr = (int16_t*)pstVadContext->tensors[1][i].address;
            int tensor_size_bytes = pstVadContext->tensors[1][i].tensor_size;
            int tensor_elements = tensor_size_bytes / sizeof(int16_t);

            // 确保不超过cache大小
            int copy_elements = (tensor_elements < CACHE_SIZE) ? tensor_elements : CACHE_SIZE;

            // 将int16 tensor反量化为float32并更新cache (使用cache专用scale)
            for (int j = 0; j < copy_elements; j++) {
                g_cache_states[cache_idx][j] = dequantize_int16_to_float(tensor_addr[j], CACHE_OUTPUT_SCALE);
            }

            if (g_vad_debug_mode) {
                printf("  g_cache_states[%d] <- tensor[1][%d] (%d elements)\n", cache_idx, i, copy_elements);
                printf("    源tensor前5个值: %d %d %d %d %d\n",
                       tensor_addr[0], tensor_addr[1], tensor_addr[2], tensor_addr[3], tensor_addr[4]);
                printf("    更新后cache前5个值: %.6f %.6f %.6f %.6f %.6f\n",
                       g_cache_states[cache_idx][0], g_cache_states[cache_idx][1],
                       g_cache_states[cache_idx][2], g_cache_states[cache_idx][3],
                       g_cache_states[cache_idx][4]);
            }
        }
    }
}

// Set eNPU core selection/affinity (optional)
// Below is an example for setting hard affinity on the most powerful core of the platform
EAI_RESULT ImediaVadSetMlaAffinity(STRU_VAD_EAI_CONTEXT *context)
{
    int eai_ret;

    // Get the number of cores
    uint32_t num_cores = 0;
    eai_ret = eai_get_property(context->eai_handle, EAI_PROP_MLA_NUM, &num_cores);

    // Loop through all cores to find the big core based on MAC
    uint32_t big_core_mac = 0;
    uint32_t big_core_id = 0;
    for (int i = 0; i < num_cores; i++) {
        eai_mla_core_info_t core_info = {0};
        core_info.id = i;
        eai_ret = eai_get_property(context->eai_handle, EAI_PROP_MLA_CORE_INFO, &core_info);

        if (core_info.mac > big_core_mac) {
            big_core_mac = core_info.mac;
            big_core_id = core_info.id;
        }
    }

    // Initialize default values for core selection/affinity
    eai_mla_affinity_t client_affinity;
    client_affinity.core_selection = 0u;
    client_affinity.affinity = EAI_MLA_AFFINITY_SOFT;

    // Set big core & hard affinity
    client_affinity.core_selection = 1 << big_core_id;
    client_affinity.affinity = EAI_MLA_AFFINITY_HARD;
    eai_ret = eai_set_property(context->eai_handle, EAI_PROP_MLA_AFFINITY, &client_affinity);

    if (eai_ret != 0) {
        return EAI_FAIL;
    } else {
        return EAI_SUCCESS;
    }
}

// Perform EAI-INIT, EAI-APPLY
int IMediaVadEaiInit(STRU_KDNR_CHAN* pstKdnrChanl, unsigned char* baseAddr, eaiModel* pEaiModel)
{
    if (baseAddr == NULL) {
        return -1;
    }
    STRU_VAD_EAI_CONTEXT *pstVadContext;
    pstVadContext = &pstKdnrChanl->stVadEai;
    EAI_RESULT eai_ret;

    unsigned int  eaiInitFlags;
    eai_memory_info_t scratchMemory;
    eai_memory_info_t persistentMemory;
    eai_memory_info_t modelBuffer = {0};
    eai_client_perf_config_t clientPerfConfig;

    unsigned char* vadEnpuModelBuffer = baseAddr + pEaiModel->modelAddr;
    // unsigned char* vadEnpuScratchBuffer = baseAddr + pEaiModel->scratchAddr;  // 未使用
    // unsigned char* vadEnpuPersistentBuffer = baseAddr + pEaiModel->persistentAddr;  // 未使用
    // unsigned char* vadEnpuIOBuffer = baseAddr + pEaiModel->ioMemAddr;  // 未使用
    int enpuIOOffset = 0;

    // load model file into a model channel pointer, and align the model buffer to 256 byte.
    // perform EAI-INIT.
    eaiInitFlags            = EAI_INIT_FLAGS_DISABLE_ASYNC; // Disable Asynchronous processing by default.
    modelBuffer.addr        = vadEnpuModelBuffer;  // model buffer
    modelBuffer.memory_size = pEaiModel->modelSize;;
    modelBuffer.memory_type = VAD_MODEL_BUFFER_MEM_TYPE;

    FILE *fp = fopen("vad_quantized_fsmn.eai","rb"); // Use relative path
    if (fp == NULL) {
        printf("[ERROR] Cannot open VAD model file vad_quantized_fsmn.eai\n");
        return EAI_FAIL;
    }
    fseek(fp, 0, SEEK_END);
    int filesize = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *tmpbuf = (char *)malloc(filesize + 256);
    uintptr_t address4 = (uintptr_t)tmpbuf;
    Q_ALIGN_ADDR(address4, 256); // 256 align
    char* buffer = (char*)address4;
    if (buffer == NULL) {
        perror("[ERROR] Memory allocation failed");
        fclose(fp);
        return 1;
    }
    size_t bytes_read = fread(buffer, 1, filesize, fp);
    if (bytes_read != (size_t)filesize) {
        printf("[WARNING] Incomplete model file read, expected %d bytes, actual %zu bytes\n", filesize, bytes_read);
    }
    fclose(fp);

    eaiInitFlags            = EAI_INIT_FLAGS_DISABLE_ASYNC; // Disable Asynchronous processing by default.
    modelBuffer.addr        = (uint8_t*)buffer;  // model buffer
    modelBuffer.memory_size = filesize;
    modelBuffer.memory_type = VAD_MODEL_BUFFER_MEM_TYPE;
    eai_ret = eai_init(&pstVadContext->eai_handle, &modelBuffer, eaiInitFlags);
    pstKdnrChanl->sEaiInitFlag = eai_ret;
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }

    // get scratch buffer info and set scratch buffer for eai api.
    eai_ret = eai_get_property(pstVadContext->eai_handle, EAI_PROP_SCRATCH_MEM, &scratchMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // if (scratchMemory.memory_size > pEaiModel->scratchSize) {
    //     return -1;
    // }
    // scratchMemory.addr = vadEnpuScratchBuffer;
    printf("==VAD scratchMemory.memory_size %d\n", scratchMemory.memory_size);
    char *buf1 = (char *)malloc(scratchMemory.memory_size);
    scratchMemory.addr = (uint8_t*)buf1;
    scratchMemory.memory_type = VAD_SCRATCH_BUFFER_MEM_TYPE;
    eai_ret = eai_set_property(pstVadContext->eai_handle, EAI_PROP_SCRATCH_MEM, &scratchMemory);

    // get persistent buffer info, Set persistent buffer for eai api.
    eai_ret = eai_get_property(pstVadContext->eai_handle, EAI_PROP_PERSISTENT_MEM, &persistentMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // if (persistentMemory.memory_size > pEaiModel->persistentSize) {
    //     return -1;
    // }
    // persistentMemory.addr = vadEnpuPersistentBuffer;
    printf("==VAD persistentMemory.memory_size %d\n", persistentMemory.memory_size);
    char *buf2 = (char *)malloc(persistentMemory.memory_size);
    memset(buf2, 0, persistentMemory.memory_size);  // Zero initialization for consistency
    persistentMemory.addr = (uint8_t*)buf2;
    persistentMemory.memory_type = VAD_PERSISTENT_BUFFER_MEM_TYPE;
    eai_ret = eai_set_property(pstVadContext->eai_handle, EAI_PROP_PERSISTENT_MEM, &persistentMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Set client perf config (optional), Initialize default values for client_perf_config.
    clientPerfConfig.fps = 1u;
    clientPerfConfig.ftrt_ratio = 10u;
    clientPerfConfig.priority = EAI_CLIENT_PRIORITY_DEFAULT;
    clientPerfConfig.flags = 0x0;
    eai_ret = eai_set_property(pstVadContext->eai_handle, EAI_PROP_CLIENT_PERF_CFG, &clientPerfConfig);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Set core selection/affinity (optional) ѡ��С��
    eai_ret = ImediaVadSetMlaAffinity(pstVadContext);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // perform EAI-APPLY, Applies configuration settings.
    eai_ret = eai_apply(pstVadContext->eai_handle);
    pstKdnrChanl->sEaiApplyFlag = eai_ret;
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Get model I/O tensor information and allocate them.
    for (int i = 0; i < 2; i++) { // 2 index //i=0 input ,i=1 output
        eai_ports_info_t ports_info;
        ports_info.input_or_output = i;
        eai_ret = eai_get_property(pstVadContext->eai_handle, EAI_PROP_PORTS_NUM, &ports_info);
        if (eai_ret != EAI_SUCCESS) {
            return -1;
        }
        printf("==VAD %d, tensor_count=ports_info.size= %d\n", ports_info.input_or_output, ports_info.size);
        pstVadContext->tensor_count[i] = ports_info.size; // input有多少维 5
        pstVadContext->tensors[i] = malloc(sizeof(eai_tensor_info_t) * ports_info.size);//(eai_tensor_info_t *)(vadEnpuIOBuffer + enpuIOOffset);
        enpuIOOffset += ports_info.size * sizeof(eai_tensor_info_t);
        // if (enpuIOOffset > pEaiModel->ioMemSize) {
        //     return -1;
        // }
        for (int j = 0; j < ports_info.size; j++) {
            pstVadContext->tensors[i][j].index = j;
            pstVadContext->tensors[i][j].input_or_output = i;
            eai_ret = eai_get_property(pstVadContext->eai_handle, EAI_PROP_TENSOR_INFO, &(pstVadContext->tensors[i][j]));
            if (eai_ret != EAI_SUCCESS) {
                return -1;
            }
            printf("==VAD tenser[%d][%d].addr=%p, size=%d\n", i,j,pstVadContext->tensors[i][j].address, pstVadContext->tensors[i][j].tensor_size);

            // Zero initialize tensors, especially input cache tensors for consistency
            if (i == 0 && j > 0) {  // Input cache tensors (j=1,2,3,4)
                memset(pstVadContext->tensors[i][j].address, 0, pstVadContext->tensors[i][j].tensor_size);
                printf("[SUCCESS] Zero initialized input cache tensor[%d][%d]\n", i, j);
            }
        }
        pstVadContext->eai_buffers[i] = malloc(sizeof(eai_buffer_info_t) * pstVadContext->tensor_count[i]);//(eai_buffer_info_t *)(vadEnpuIOBuffer + enpuIOOffset);
        enpuIOOffset += sizeof(eai_tensor_info_t) * pstVadContext->tensor_count[i];
        // if (enpuIOOffset > pEaiModel->ioMemSize) {
        //     return -1;
        // }
    }
    // pstKdnrChanl->vadInBuf = (int*)vadEnpuIOBuffer + enpuIOOffset;
    // enpuIOOffset += pstKdnrChanl->modelParam.vadInDim * IMEDIA_FBANK_FEATURE_LEN;
    return eai_ret;
}

int g_times = 0;
int16_t vadInputBuf[32*400];

// 声明外部函数
extern int test_src_features_main(void);

// Perform EAI-EXECUTE.
int IMediaVadEaiExec(STRU_KDNR_CHAN* pstKdnrChanl)
{
    STRU_VAD_EAI_CONTEXT *pstVadContext;
    pstVadContext = &pstKdnrChanl->stVadEai;
    EAI_RESULT eai_ret;
    int i;
    int j;

    // === Feature extraction using test_feature_extraction compatible method ===
    static int block_count = 0;
    block_count++;

    // 使用Python特征文件 (第一次调用时加载)
    static int features_loaded = 0;
    if (!features_loaded) {
        if (load_python_features("1_features_standalone.npy") != 0) {
            printf("[ERROR] 无法加载Python特征文件\n");
            return EAI_FAIL;
        }
        features_loaded = 1;
    }

    if (g_python_features == NULL || g_python_num_frames < 32) {
        printf("[WARNING] Python特征不足 (需要32帧，实际%d帧)\n", g_python_num_frames);
        return EAI_FAIL;
    }

    // Reset cache states to zero for each new block (Python-compatible)
    reset_cache_states();
    printf(" Cache重置为0，块%d开始处理\n", block_count);

    // Take 32 frames (400 dimensions each) - 使用Python特征
    int start_frame = (block_count - 1) * 32;  // 每个块取连续的32帧
    float float_features[32 * 400];

    // Initialize with zeros (for padding when insufficient frames)
    memset(float_features, 0, sizeof(float_features));

    // Copy available frames from Python features, pad with zeros if insufficient
    for (i = 0; i < 32; i++) {
        int current_frame = start_frame + i;
        if (current_frame < g_python_num_frames) {
            // Copy real frame data from Python features
            for (j = 0; j < 400; j++) {
                float_features[i * 400 + j] = g_python_features[current_frame * 400 + j];
            }
        }
        // else: keep zeros (already initialized)
    }

    printf("[SUCCESS] 使用Python特征: 帧%d-%d (32帧×400维)\n",
           start_frame, start_frame + 31);

    // 显示特征统计信息
    if (g_vad_debug_mode) {
        float min_val = float_features[0], max_val = float_features[0];
        for (int k = 0; k < 32 * 400; k++) {
            if (float_features[k] < min_val) min_val = float_features[k];
            if (float_features[k] > max_val) max_val = float_features[k];
        }
        printf("[DEBUG] 输入特征范围: [%.6f, %.6f]\n", min_val, max_val);
        printf("[DEBUG] 前5个特征值: %.6f %.6f %.6f %.6f %.6f\n",
               float_features[0], float_features[1], float_features[2],
               float_features[3], float_features[4]);
    }

    // Step 2: Quantize float32 features to int16 for EAI tensor (使用zero point)
    int16_t quantized_input[32 * 400];
    quantize_features_with_zero(float_features, quantized_input, 32, 400, INPUT_SCALE, INPUT_ZERO);



    // Copy quantized features to vadInputBuf (as int16)
    memcpy(vadInputBuf, quantized_input, 32 * 400 * sizeof(int16_t));

    // Save data for comparison in debug mode
    if (g_vad_debug_mode) {
        char filename[256];
        FILE *fp;

        // Create output directory
        int mkdir_result = system("mkdir -p c_result");
        if (mkdir_result != 0) {
            printf("[WARNING] Failed to create c_result directory\n");
        }

        // Save input features (32×400 float32) - unified format for comparison
        snprintf(filename, sizeof(filename), "c_result/c_input_features_block_%d.bin", block_count);
        fp = fopen(filename, "wb");
        if (fp) {
            fwrite(float_features, sizeof(float), 32 * 400, fp);
            fclose(fp);
            printf("[SUCCESS] Saved C input features block %d: %s (32×400)\n", block_count, filename);
        }

        // Note: Quantized input will be saved later in the EAI execution debug section
    }

    // input feature
    AudioCommonVecCopyUInt8((uint8_t*)vadInputBuf, (size_t)(pstVadContext->tensors[0][0].tensor_size), pstVadContext->tensors[0][0].address);

    // Copy global cache states to input tensors for consistency
    copy_cache_to_tensors(pstVadContext);

    // 调试模式下保存推理前的cache状态 (初始状态)
    if (g_vad_debug_mode) {
        char filename[256];
        FILE *fp;

        for (int cache_idx = 0; cache_idx < 4; cache_idx++) {
            if (g_cache_states[cache_idx] != NULL) {
                snprintf(filename, sizeof(filename), "c_result/c_cache_state_%d_before_block_%d.bin", cache_idx, block_count);
                fp = fopen(filename, "wb");
                if (fp) {
                    fwrite(g_cache_states[cache_idx], sizeof(float), CACHE_SIZE, fp);
                    fclose(fp);
                    printf(" 保存C推理前cache状态%d块%d: %s\n", cache_idx, block_count, filename);
                }
            }
        }
    }

    // Debug output: check input tensors
    if (g_vad_debug_mode) {
        printf("[DEBUG] Input tensor debug information:\n");

        // Main input tensor[0][0]
        short *main_input = (int16_t*)(pstVadContext->tensors[0][0].address);
        printf("  Main input tensor[0][0] first 5 values: %d %d %d %d %d\n",
               main_input[0], main_input[1], main_input[2], main_input[3], main_input[4]);

        // Cache input tensors[0][1-4]
        for (int k = 1; k < pstVadContext->tensor_count[0]; k++) {
            short *cache_input = (int16_t*)(pstVadContext->tensors[0][k].address);
            printf("  Cache input tensor[0][%d] first 5 values: %d %d %d %d %d\n", k,
                   cache_input[0], cache_input[1], cache_input[2], cache_input[3], cache_input[4]);
        }
    }

    for (i = 0; i < 2; i++) {
        for (j = 0; j < pstVadContext->tensor_count[i]; j++) {
            eai_tensor_info_t *tensor = &(pstVadContext->tensors[i][j]);
            pstVadContext->eai_buffers[i][j].index = j;
            pstVadContext->eai_buffers[i][j].element_type = tensor->element_type;
            pstVadContext->eai_buffers[i][j].addr = tensor->address;
            pstVadContext->eai_buffers[i][j].buffer_size = tensor->tensor_size;
            pstVadContext->eai_buffers[i][j].memory_type = VAD_SCRATCH_BUFFER_MEM_TYPE;
        }
    }

    pstVadContext->eai_batch.num_inputs = pstVadContext->tensor_count[0];
    pstVadContext->eai_batch.num_outputs = pstVadContext->tensor_count[1];
    pstVadContext->eai_batch.inputs = &(pstVadContext->eai_buffers[0][0]);
    pstVadContext->eai_batch.outputs = &(pstVadContext->eai_buffers[1][0]);



    eai_ret = eai_execute(pstVadContext->eai_handle, &pstVadContext->eai_batch, 1);
    g_times += 320;
    printf("==VAD %dms, eai_ret=%d\n", g_times, eai_ret);
    pstKdnrChanl->sEaiExecFlag = eai_ret;

    // After inference completion, update global cache states from output tensors
    if (eai_ret == EAI_SUCCESS) {
        update_cache_from_tensors(pstVadContext);

        // 保存推理后的原始输出数据 (调试用)
        if (g_vad_debug_mode) {
            char filename[256];

            // 保存主输出张量 (量化后的推理结果，int16格式)
            snprintf(filename, sizeof(filename), "c_result/c_raw_output_block_%d.bin", block_count);
            FILE *fp = fopen(filename, "wb");
            if (fp) {
                int16_t *main_output = (int16_t*)(pstVadContext->tensors[1][0].address);
                size_t output_size = pstVadContext->tensors[1][0].tensor_size / sizeof(int16_t);
                fwrite(main_output, sizeof(int16_t), output_size, fp);
                fclose(fp);
                printf(" 保存C原始输出块%d: %s (大小: %zu int16)\n", block_count, filename, output_size);
            }

            // 保存原始输出为txt格式
            snprintf(filename, sizeof(filename), "c_result/c_raw_output_block_%d.txt", block_count);
            fp = fopen(filename, "w");
            if (fp) {
                int16_t *main_output = (int16_t*)(pstVadContext->tensors[1][0].address);
                fprintf(fp, "C原始输出块%d (32帧×248维, int16)\n", block_count);
                for (int frame = 0; frame < 32; frame++) {
                    fprintf(fp, "帧%d第0维(静音): %d\n", frame, main_output[frame * 248 + 0]);
                }
                fclose(fp);
                printf(" 保存C原始输出文本块%d: %s\n", block_count, filename);
            }
        }
    }

    // for (j = 0; j < pstVadContext->tensor_count[1]; j++) {
    //     eai_tensor_info_t *tensor = &(pstVadContext->tensors[1][j]);
    //     printf("==VAD out[%d].size=%d\n", i, tensor->tensor_size);
    // }
    
    int16_t *out = (int16_t*)(pstVadContext->tensors[1][0].address);
    printf("==VAD out:%d %d\n", out[0], out[1]);
    for (i = 0; i < pstVadContext->tensors[1][0].tensor_size; i++) {
        printf("%d ", out[i]);
    }
    printf("\n");

    // === 反量化处理 ===
    int output_length = pstVadContext->tensors[1][0].tensor_size / sizeof(int16_t);

    // 分配反量化输出缓冲区
    float *dequantized_output = (float*)malloc(output_length * sizeof(float));
    if (dequantized_output == NULL) {
        printf("错误: 无法分配反量化输出缓冲区\n");
        return -1;
    }

    // 执行反量化 (使用正确的scale和zero point)
    dequantize_output_with_zero(out, dequantized_output, output_length, OUTPUT_SCALE, OUTPUT_ZERO);

    // 将logits转换为概率
    float *probability_output = (float*)malloc(output_length * sizeof(float));
    if (probability_output == NULL) {
        printf("错误: 无法分配概率输出缓冲区\n");
        free(dequantized_output);
        return -1;
    }

    logits_to_probs(dequantized_output, probability_output, output_length);

    if (g_vad_debug_mode) {
        printf("反量化输出 (前8个logits): ");
        for (i = 0; i < 8 && i < output_length; i++) {
            printf("%.6f ", dequantized_output[i]);
        }
        printf("\n");

        printf("概率输出 (前8个概率): ");
        for (i = 0; i < 8 && i < output_length; i++) {
            printf("%.6f ", probability_output[i]);
        }
        printf("\n");
    }

    // 创建输出目录 (无论是否调试模式都需要)
    int mkdir_result = system("mkdir -p c_result");
    (void)mkdir_result;  // 避免未使用变量警告

    char filename[256];
    FILE *fp;

    // 保存量化输出 (int16) - 总是保存
    snprintf(filename, sizeof(filename), "c_result/c_quantized_output_block_%d.bin", block_count);
    fp = fopen(filename, "wb");
    if (fp) {
        fwrite(out, sizeof(short), output_length, fp);
        fclose(fp);
        printf(" 保存C量化输出块%d: %s (长度: %d)\n", block_count, filename, output_length);
    }



    // 调试模式下保存所有阶段输出 (对齐Python目录结构)
    if (g_vad_debug_mode) {
        // 创建block目录 (C的block_count从1开始，Python从0开始，所以减1)
        int python_block_id = block_count - 1;
        char block_dir[256];
        snprintf(block_dir, sizeof(block_dir), "c_result/block_%d", python_block_id);

        // 创建目录
        char mkdir_cmd[300];
        snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p %s", block_dir);
        system(mkdir_cmd);

        // 1. 保存输入特征 (如果使用Python特征)
        if (g_python_features != NULL) {
            snprintf(filename, sizeof(filename), "%s/input_features.txt", block_dir);
            fp = fopen(filename, "w");
            if (fp) {
                fprintf(fp, "C输入特征块%d (32帧×400维)\n", python_block_id + 1);
                int start_frame = python_block_id * 32;

                // 计算特征范围
                float min_feat = g_python_features[start_frame * 400];
                float max_feat = g_python_features[start_frame * 400];
                for (int frame = 0; frame < 32 && (start_frame + frame) < g_python_num_frames; frame++) {
                    for (int dim = 0; dim < 400; dim++) {
                        float val = g_python_features[(start_frame + frame) * 400 + dim];
                        if (val < min_feat) min_feat = val;
                        if (val > max_feat) max_feat = val;
                    }
                }
                fprintf(fp, "特征范围: [%.6f, %.6f]\n", min_feat, max_feat);

                // 保存前10维特征
                for (int frame = 0; frame < 32; frame++) {
                    if ((start_frame + frame) < g_python_num_frames) {
                        fprintf(fp, "帧%d: ", frame);
                        for (int dim = 0; dim < 10; dim++) {
                            fprintf(fp, "%.6f ", g_python_features[(start_frame + frame) * 400 + dim]);
                        }
                        fprintf(fp, "...\n");
                    } else {
                        fprintf(fp, "帧%d: 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 ...\n", frame);
                    }
                }
                fclose(fp);
                printf(" 保存C输入特征: %s\n", filename);
            }
        }

        // 2. 保存量化输入 (已有的量化输入保存逻辑移到这里)
        snprintf(filename, sizeof(filename), "%s/quantized_input.txt", block_dir);
        fp = fopen(filename, "w");
        if (fp) {
            int16_t *main_input = (int16_t*)(pstVadContext->tensors[0][0].address);
            fprintf(fp, "C量化输入块%d (32帧×400维, int16)\n", python_block_id + 1);

            // 计算量化输入范围
            int16_t min_quant = main_input[0], max_quant = main_input[0];
            for (int i = 0; i < 32 * 400; i++) {
                if (main_input[i] < min_quant) min_quant = main_input[i];
                if (main_input[i] > max_quant) max_quant = main_input[i];
            }
            fprintf(fp, "范围: [%d, %d]\n", min_quant, max_quant);

            for (int frame = 0; frame < 32; frame++) {
                fprintf(fp, "帧%d: ", frame);
                for (int dim = 0; dim < 10; dim++) {  // 只保存前10维
                    fprintf(fp, "%d ", main_input[frame * 400 + dim]);
                }
                fprintf(fp, "...\n");
            }
            fclose(fp);
            printf(" 保存C量化输入: %s\n", filename);
        }

        // 3. 保存原始输出 (int16)
        snprintf(filename, sizeof(filename), "%s/raw_output.txt", block_dir);
        fp = fopen(filename, "w");
        if (fp) {
            int16_t *raw_out = (int16_t*)(pstVadContext->tensors[1][0].address);
            fprintf(fp, "C原始输出块%d (32帧×248维, int16)\n", python_block_id + 1);

            // 计算原始输出范围
            int16_t min_raw = raw_out[0], max_raw = raw_out[0];
            for (int i = 0; i < output_length; i++) {
                if (raw_out[i] < min_raw) min_raw = raw_out[i];
                if (raw_out[i] > max_raw) max_raw = raw_out[i];
            }
            fprintf(fp, "范围: [%d, %d]\n", min_raw, max_raw);

            for (int frame = 0; frame < 32; frame++) {
                fprintf(fp, "帧%d第0维(静音): %d\n", frame, raw_out[frame * 248 + 0]);
            }
            fclose(fp);
            printf(" 保存C原始输出: %s\n", filename);
        }

        // 4. 保存完整反量化输出 (248维)
        snprintf(filename, sizeof(filename), "%s/dequantized_output.txt", block_dir);
        fp = fopen(filename, "w");
        if (fp) {
            fprintf(fp, "C反量化输出块%d (32帧×248维)\n", python_block_id + 1);
            fprintf(fp, "范围: [%.6f, %.6f]\n",
                   dequantized_output[0], dequantized_output[output_length-1]); // 简化范围计算

            // 只保存第0维用于对比
            for (int frame = 0; frame < 32; frame++) {
                fprintf(fp, "帧%d: %.6f\n", frame, dequantized_output[frame * 248 + 0]);
            }
            fclose(fp);
            printf(" 保存C反量化输出: %s\n", filename);
        }

        // 5. 保存静音概率 (第0维，文件名明确标识)
        snprintf(filename, sizeof(filename), "%s/silence_probs.txt", block_dir);
        fp = fopen(filename, "w");
        if (fp) {
            fprintf(fp, "C静音概率块%d第0维(静音概率)\n", python_block_id + 1);

            // 计算第0维的范围
            float min_val = dequantized_output[0], max_val = dequantized_output[0];
            for (int frame = 0; frame < 32; frame++) {
                float val = dequantized_output[frame * 248 + 0];
                if (val < min_val) min_val = val;
                if (val > max_val) max_val = val;
            }
            fprintf(fp, "范围: [%.6f, %.6f]\n", min_val, max_val);

            // 保存32帧的第0维静音概率
            for (int frame = 0; frame < 32; frame++) {
                fprintf(fp, "帧%d: %.6f\n", frame, dequantized_output[frame * 248 + 0]);
            }
            fclose(fp);
            printf(" 保存C静音概率: %s\n", filename);
        }
    }

    // 调试模式下的额外保存
    if (g_vad_debug_mode) {

        // 输出前几帧的最大概率值
        if (block_count <= 2) {
            // 每个块包含32帧，每帧248个概率值
            int frames_per_block = 32;
            int probs_per_frame = output_length / frames_per_block;

            printf("\n 第%d块前10帧最大概率值:\n", block_count);

            for (int frame = 0; frame < 10 && frame < frames_per_block; frame++) {
                float max_prob = -1.0f;
                int max_idx = -1;

                // 查找当前帧的最大概率值
                for (int i = 0; i < probs_per_frame; i++) {
                    int idx = frame * probs_per_frame + i;
                    if (idx < output_length && probability_output[idx] > max_prob) {
                        max_prob = probability_output[idx];
                        max_idx = i;
                    }
                }

                printf("  帧%d: 最大概率=%.6f (索引=%d)\n", frame + 1, max_prob, max_idx);
            }
            printf("\n");
        }

        // 保存cache状态用于调试
        for (int cache_idx = 0; cache_idx < 4; cache_idx++) {
            if (g_cache_states[cache_idx] != NULL) {
                snprintf(filename, sizeof(filename), "c_result/c_cache_state_%d_block_%d.bin", cache_idx, block_count);
                fp = fopen(filename, "wb");
                if (fp) {
                    fwrite(g_cache_states[cache_idx], sizeof(float), CACHE_SIZE, fp);
                    fclose(fp);
                    printf(" 保存C cache状态%d块%d: %s\n", cache_idx, block_count, filename);
                }
            }
        }
    }

    // 清理内存
    free(dequantized_output);
    free(probability_output);

    // 保存第二个输出tensor (状态缓存)
    short *cache_out = (int16_t*)(pstVadContext->tensors[1][1].address);
    for (i = 0; i < pstVadContext->tensors[1][1].tensor_size; i++) {
        printf("%d ", cache_out[i]);
    }
    printf("\n");

    return eai_ret;
}

// Perform EAI-DEINIT and free allocated context memory
int IMediaVadEaiDeInit(STRU_KDNR_CHAN* pstKdnrChanl)
{
    int ret;
    STRU_VAD_EAI_CONTEXT *pstVadContext;
    pstVadContext = &pstKdnrChanl->stVadEai;
    ret = eai_deinit(pstVadContext->eai_handle);

    return ret;
}
