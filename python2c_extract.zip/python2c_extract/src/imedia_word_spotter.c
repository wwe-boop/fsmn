/*========================================================================*/
/**
\file imedia_aes_eai_vec.cpp

    Copyright (c) Honor Device Co., Ltd. 2021-2024.
    All rights reserved.
\author honor
\date 2024-06-28 11:16:16
*/
/*========================================================================*/
#include <stdint.h>
#include "imedia_word_spotter.h"
#include "imedia_decoder_eai_vec.h"
#include "imedia_joiner_eai_vec.h"
#include "imedia_command_define.h"
#include "imedia_beam_search.h"

#include <stdio.h>
#include <locale.h>

int IMediaGetResult(STRU_KDNR_CHAN* pstKdnrChanl)
{
    int idx = 0;
    int res_index = 0;
    STRU_HYPS_DICT* cur = pstKdnrChanl->cur;
    IMediaBeamSearchFinalized(pstKdnrChanl);
    IMediaGetMostProbable(cur, 0, pstKdnrChanl->hypSize, &res_index);

    Hypothesis* hyp = &pstKdnrChanl->cur[res_index].hyp;
    if (hyp->phraseId != -1 && pstKdnrChanl->commadInfo->activatePhaseId==-1) {
        pstKdnrChanl->commadInfo->activatePhaseId = hyp->phraseId;
    }
    for (int i = 2; i < hyp->ysSize; i++) {
        for (int j = 0; j < pstKdnrChanl->modelParam.vocabSize; j++) {
            if (pstKdnrChanl->sym2id[j].val == hyp->ys[i]) {
                for (int m = 0; m < MAX_WORD_LEN; m++) {
                    if (pstKdnrChanl->sym2id[j].key[m] != '\0') {
                        pstKdnrChanl->commadInfo->result[idx] = pstKdnrChanl->sym2id[j].key[m];
                        idx++;
                        if (idx > MAX_RES_SIZE) {
                            idx = 0;
                        }
                    }
                    else {
                        pstKdnrChanl->commadInfo->result[idx] = ' ';
                        idx++;
                        break;
                    }
                }

            }
        }
    }
    pstKdnrChanl->commadInfo->result[idx] = '\0';
    return 0;
}
