/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2024-2024. All rights reserved.
 * Description: test_src_features.c - 测试src版本的特征提取
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include "imedia_command_define.h"
#include "imedia_fbank_extractor.h"
#include "imedia_common_define.h"

// 全局变量用于存储特征，供VAD推理使用
static float* g_lfr_features_flat = NULL;  // 平铺的LFR特征数组
static int g_num_lfr_frames = 0;           // LFR特征帧数

// 简单的npy文件读取器 (仅支持float32类型的2D数组)
int load_npy_features(const char* npy_file_path, float** features, int* num_frames, int* feature_dim) {
    FILE* file = fopen(npy_file_path, "rb");
    if (!file) {
        printf(" 无法打开npy文件: %s\n", npy_file_path);
        return -1;
    }

    // 读取npy文件头 (简化版本，假设是标准的float32 2D数组)
    char magic[6];
    size_t bytes_read = fread(magic, 1, 6, file);
    if (bytes_read != 6) {
        printf(" 无法读取npy文件头\n");
        fclose(file);
        return -1;
    }

    // 检查magic number
    if ((unsigned char)magic[0] != 0x93 || strncmp(magic + 1, "NUMPY", 5) != 0) {
        printf(" 不是有效的npy文件格式 (magic: %02x %c%c%c%c%c)\n",
               (unsigned char)magic[0], magic[1], magic[2], magic[3], magic[4], magic[5]);
        fclose(file);
        return -1;
    }

    // 读取版本号
    unsigned char major_version, minor_version;
    fread(&major_version, 1, 1, file);
    fread(&minor_version, 1, 1, file);
    printf("npy版本: %d.%d\n", major_version, minor_version);

    // 读取头长度
    unsigned short header_len;
    fread(&header_len, 2, 1, file);
    printf("头长度: %d\n", header_len);

    // 读取头信息
    char* header = (char*)malloc(header_len + 1);
    fread(header, 1, header_len, file);
    header[header_len] = '\0';
    printf("头信息: %s\n", header);

    // 解析形状信息 (简化解析，假设格式为 "{'descr': '<f4', 'fortran_order': False, 'shape': (frames, dims), }")
    char* shape_start = strstr(header, "'shape': (");
    if (!shape_start) {
        // 尝试另一种格式
        shape_start = strstr(header, "\"shape\": (");
        if (!shape_start) {
            shape_start = strstr(header, "'shape':(");
            if (!shape_start) {
                printf(" 无法解析npy文件形状信息\n");
                free(header);
                fclose(file);
                return -1;
            }
        }
    }

    // 提取形状信息
    int frames, dims;
    char* shape_data = strchr(shape_start, '(');
    if (!shape_data) {
        printf(" 无法找到形状数据\n");
        free(header);
        fclose(file);
        return -1;
    }

    if (sscanf(shape_data + 1, "%d, %d)", &frames, &dims) != 2) {
        printf(" 无法解析npy文件维度信息，尝试解析的字符串: %s\n", shape_data);
        free(header);
        fclose(file);
        return -1;
    }

    printf(" npy文件信息: %d帧 × %d维\n", frames, dims);

    // 分配内存并读取数据
    int total_elements = frames * dims;
    *features = (float*)malloc(total_elements * sizeof(float));
    if (!*features) {
        printf(" 内存分配失败\n");
        free(header);
        fclose(file);
        return -1;
    }

    size_t elements_read = fread(*features, sizeof(float), total_elements, file);
    if (elements_read != (size_t)total_elements) {
        printf(" npy数据读取不完整，期望%d个元素，实际读取%zu个\n", total_elements, elements_read);
        free(*features);
        free(header);
        fclose(file);
        return -1;
    }

    *num_frames = frames;
    *feature_dim = dims;

    free(header);
    fclose(file);

    printf(" 成功加载npy特征文件: %s\n", npy_file_path);
    printf("   - 特征形状: %d × %d\n", frames, dims);
    printf("   - 数值范围: [%.6f, %.6f]\n", (*features)[0], (*features)[total_elements-1]);

    return 0;
}

// 简化的WAV读取函数
int read_wav_file(const char* filename, short** audio_data, int* sample_rate, int* num_samples) {
    FILE* file = fopen(filename, "rb");
    if (!file) {
        printf("Cannot open file: %s\n", filename);
        return -1;
    }
    
    // 简化的WAV头读取
    char header[44];
    size_t header_bytes = fread(header, 1, 44, file);
    (void)header_bytes;  // 避免未使用变量警告
    
    // 获取采样率和数据大小
    *sample_rate = *(int*)(header + 24);
    int data_size = *(int*)(header + 40);
    *num_samples = data_size / 2;  // 16位音频
    
    // 读取音频数据
    *audio_data = (short*)malloc(*num_samples * sizeof(short));
    size_t samples_read = fread(*audio_data, sizeof(short), *num_samples, file);
    if (samples_read != (size_t)*num_samples) {
        printf("警告: 音频数据读取不完整，期望%d样本，实际读取%zu样本\n", *num_samples, samples_read);
    }
    
    fclose(file);
    printf("Loaded audio: %s\n", filename);
    printf("Sample rate: %d Hz\n", *sample_rate);
    printf("Samples: %d\n", *num_samples);
    printf("Duration: %.4f seconds\n", (float)*num_samples / *sample_rate);
    
    return 0;
}

// LFR processing - implementation compatible with test framework
void apply_lfr(float** input_features, int input_frames, float** output_features, int* output_frames) {
    const int lfr_m = 5;
    const int lfr_n = 1;
    const int feature_dim = 80;

    // Calculate LFR output frame count (based on original frame count, test framework compatible)
    *output_frames = (int)ceil(1.0 * input_frames / lfr_n);

    // Calculate left padding count (test framework compatible)
    int left_padding_count = (lfr_m - 1) / 2;  // (5-1)/2 = 2

    // 计算总帧数 (原始帧数 + 左padding)
    int total_frames = input_frames + left_padding_count;

    // 创建扩展的输入特征数组 (包含左padding)
    float** extended_features = (float**)malloc(total_frames * sizeof(float*));

    // 左padding：复制第一帧
    for (int i = 0; i < left_padding_count; i++) {
        extended_features[i] = (float*)malloc(feature_dim * sizeof(float));
        memcpy(extended_features[i], input_features[0], feature_dim * sizeof(float));
    }

    // 复制原始特征
    for (int i = 0; i < input_frames; i++) {
        extended_features[i + left_padding_count] = input_features[i];  // 直接指向原始数据
    }

    // 分配输出内存
    *output_features = (float*)malloc(*output_frames * lfr_m * feature_dim * sizeof(float));

    // Apply LFR concatenation (logic compatible with test framework)
    for (int i = 0; i < *output_frames; i++) {
        int output_base_idx = i * (lfr_m * feature_dim);

        if (lfr_m <= total_frames - i * lfr_n) {
            // 正常情况：有足够的帧进行拼接
            for (int j = 0; j < lfr_m; j++) {
                int frame_idx = i * lfr_n + j;
                int output_offset = output_base_idx + j * feature_dim;
                memcpy(*output_features + output_offset, extended_features[frame_idx], feature_dim * sizeof(float));
            }
        } else {
            // Last frame processing: pad insufficient parts with last frame (test framework compatible)
            int available_frames = total_frames - i * lfr_n;

            // 先添加可用的帧
            for (int j = 0; j < available_frames; j++) {
                int frame_idx = i * lfr_n + j;
                int output_offset = output_base_idx + j * feature_dim;
                memcpy(*output_features + output_offset, extended_features[frame_idx], feature_dim * sizeof(float));
            }

            // 用最后一帧填充剩余部分
            int num_padding = lfr_m - available_frames;
            for (int j = 0; j < num_padding; j++) {
                int output_offset = output_base_idx + (available_frames + j) * feature_dim;
                memcpy(*output_features + output_offset, extended_features[total_frames - 1], feature_dim * sizeof(float));
            }
        }
    }

    // 清理左padding的内存
    for (int i = 0; i < left_padding_count; i++) {
        free(extended_features[i]);
    }
    free(extended_features);
}

// 保存特征到result文件夹
void save_features_to_result(float* features, int num_frames, int feature_dim) {
    // 创建目录
    int mkdir_result = system("mkdir -p ../result/c_src");
    if (mkdir_result != 0) {
        printf("警告: 创建../result/c_src目录失败\n");
    }
    
    // 保存信息文件
    FILE* info_file = fopen("../result/c_src/info.txt", "w");
    if (info_file) {
        fprintf(info_file, "=== C Source Feature Extraction Results ===\n");
        fprintf(info_file, "Audio file: AsrValidation6.wav\n");
        fprintf(info_file, "Implementation: src/imedia_fbank_extractor.c\n");
        fprintf(info_file, "Number of frames: %d\n", num_frames);
        fprintf(info_file, "Feature dimension: %d\n", feature_dim);
        fprintf(info_file, "Total features: %d\n", num_frames * feature_dim);
        fprintf(info_file, "Sample rate: 16000 Hz\n");
        fprintf(info_file, "Frame length: 25 ms (400 samples)\n");
        fprintf(info_file, "Frame shift: 10 ms (160 samples)\n");
        fprintf(info_file, "FFT size: 512\n");
        fprintf(info_file, "Mel bins: 80\n");
        fprintf(info_file, "LFR: m=5, n=1\n");
        fprintf(info_file, "Final feature dimension: 80 * 5 = 400\n");
        fclose(info_file);
    }
    
    // 保存文本格式
    FILE* txt_file = fopen("../result/c_src/features.txt", "w");
    if (txt_file) {
        fprintf(txt_file, "%d %d\n", num_frames, feature_dim);
        for (int i = 0; i < num_frames; i++) {
            for (int j = 0; j < feature_dim; j++) {
                fprintf(txt_file, "%.6f", features[i * feature_dim + j]);
                if (j < feature_dim - 1) fprintf(txt_file, " ");
            }
            fprintf(txt_file, "\n");
        }
        fclose(txt_file);
    }
    
    // 保存二进制格式
    FILE* bin_file = fopen("../result/c_src/features.bin", "wb");
    if (bin_file) {
        fwrite(&num_frames, sizeof(int), 1, bin_file);
        fwrite(&feature_dim, sizeof(int), 1, bin_file);
        fwrite(features, sizeof(float), num_frames * feature_dim, bin_file);
        fclose(bin_file);
    }
    
    printf("C source features saved to ../result/c_src/\n");
    printf("  - features.txt (text format)\n");
    printf("  - features.bin (binary format)\n");
    printf("  - info.txt (metadata)\n");
}

int test_src_features_main() {
    const char* audio_file = "AsrValidation6.wav";
    short* audio_data;
    int sample_rate, num_samples;
    
    printf("=== C Source Feature Extraction ===\n");
    
    // 读取音频文件
    if (read_wav_file(audio_file, &audio_data, &sample_rate, &num_samples) != 0) {
        return -1;
    }
    
    // Initialize Fbank extractor
    IMediaFbankExtractorInit();
    
    // 计算帧数
    const int frame_length = 400;  // 25ms
    const int frame_shift = 160;   // 10ms
    int num_frames = (num_samples - frame_length) / frame_shift + 1;
    
    printf("Number of frames: %d\n", num_frames);
    
    // 分配特征内存
    float** raw_features = (float**)malloc(num_frames * sizeof(float*));
    for (int i = 0; i < num_frames; i++) {
        raw_features[i] = (float*)malloc(IMEDIA_FBANK_FEATURE_LEN * sizeof(float));
    }
    
    // 创建临时通道结构
    STRU_KDNR_CHAN temp_channel;
    memset(&temp_channel, 0, sizeof(STRU_KDNR_CHAN));
    
    // 提取特征
    for (int frame_idx = 0; frame_idx < num_frames; frame_idx++) {
        int start_sample = frame_idx * frame_shift;
        short frame_data[IMEDIA_ASR_FRAMES_16K];
        
        // 复制帧数据
        for (int i = 0; i < IMEDIA_ASR_FRAMES_16K; i++) {
            if (start_sample + i < num_samples) {
                frame_data[i] = audio_data[start_sample + i];
            } else {
                frame_data[i] = 0;  // 零填充
            }
        }
        
        // 提取特征
        IMediaFbankExtractFrame(&temp_channel, frame_data);
        
        // 复制结果
        memcpy(raw_features[frame_idx], temp_channel.fBankOut, IMEDIA_FBANK_FEATURE_LEN * sizeof(float));
    }
    
    // 应用LFR
    float* lfr_features;
    int lfr_frames;
    apply_lfr(raw_features, num_frames, &lfr_features, &lfr_frames);

    printf("After LFR: %d frames, %d dimensions\n", lfr_frames, 400);

    // 保存特征到全局变量，供VAD推理使用
    if (g_lfr_features_flat) {
        free(g_lfr_features_flat);
    }
    g_num_lfr_frames = lfr_frames;
    g_lfr_features_flat = lfr_features;  // 直接使用，不释放

    printf(" LFR特征已保存到全局变量: %d帧×400维\n", g_num_lfr_frames);

    // 保存特征到文件
    save_features_to_result(lfr_features, lfr_frames, 400);

    // 清理内存 (但保留lfr_features，因为已保存到全局变量)
    for (int i = 0; i < num_frames; i++) {
        free(raw_features[i]);
    }
    free(raw_features);
    // 注意：不释放lfr_features，因为它现在是全局变量
    free(audio_data);
    
    printf("Feature extraction completed successfully!\n");
    return 0;
}

/**
 * 从npy文件加载特征并设置到全局变量
 * @param npy_file_path npy特征文件路径
 * @return 0成功，-1失败
 */
int load_features_from_npy(const char* npy_file_path) {
    float* features = NULL;
    int num_frames = 0;
    int feature_dim = 0;

    // 加载npy文件
    if (load_npy_features(npy_file_path, &features, &num_frames, &feature_dim) != 0) {
        return -1;
    }

    // 检查特征维度是否正确 (应该是400维的LFR特征)
    if (feature_dim != 400) {
        printf(" 特征维度不匹配，期望400维，实际%d维\n", feature_dim);
        free(features);
        return -1;
    }

    // 释放之前的特征数据
    if (g_lfr_features_flat) {
        free(g_lfr_features_flat);
    }

    // 设置全局变量
    g_lfr_features_flat = features;
    g_num_lfr_frames = num_frames;

    printf(" npy特征已加载到全局变量: %d帧×%d维\n", g_num_lfr_frames, feature_dim);

    // 显示前几个特征值用于验证
    if (num_frames > 0) {
        printf("   - 前5个特征值: %.6f %.6f %.6f %.6f %.6f\n",
               features[0], features[1], features[2], features[3], features[4]);
    }

    return 0;
}

/**
 * 获取最新的LFR特征，供VAD推理使用
 * @param num_frames 输出参数，返回可用的帧数
 * @return 指向LFR特征数据的指针，每帧400维
 */
float* get_latest_lfr_features(int* num_frames) {
    if (num_frames) {
        *num_frames = g_num_lfr_frames;
    }
    return g_lfr_features_flat;
}
