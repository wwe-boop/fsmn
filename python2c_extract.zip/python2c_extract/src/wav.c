
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wav.h"
#ifndef WIN32
// 修复编译警告：只在clang下使用此pragma，GCC不支持此选项
#ifdef __clang__
#pragma clang diagnostic ignored "-Winvalid-source-encoding"
#endif
#endif
//返回wav文件头数目, 及新的数据头
int read_wav(FILE *file_wav, PST_WAV_HEADER header)
{
    int headsize;
    char data[100];
    int datalen;
    unsigned int i;
    
    fseek(file_wav, 0, SEEK_SET);
    size_t bytes_read = fread(data, sizeof(char), 100, file_wav);
    (void)bytes_read;  // 避免未使用变量警告
    data[99] ='\0';
    fseek(file_wav, 0, SEEK_SET);  //回到文件头
    
    //非pcm文件
    if (strncmp(data, "RIFF", 4) != 0 || strncmp(data+8, "WAVEfmt", 7) != 0) {
        return 0;
    }

    //查找data标志
    for (i = 0; i < sizeof(data)-4; i++) {
        if ('d' == data[i] && 'a' == data[i+1] && 't' == data[i+2] && 'a' == data[i+3]) {
            break;
        }
    }    
    if (i >= sizeof(data)-1) {
        printf("错误：wav头中未找到data字节\n");
        return -1;
    }
    
    //统计数据段大小
    headsize = i;
    datalen = *((int *)(data + headsize + 4));     //"data"后int是数据长度 

    memcpy(header, data, 32); //拷贝公共部分数据

    //单声道
    //if (header->channel != 1)
    //{
    //    printf("错误：只支持单声道\n");
    //    return -2;
    //}
    //采样率
    if (header->samplerate != 8000 && header->samplerate != 16000)
    {
        printf("错误：只支持8K|16K\n");
        return -3;
    }
    //16bits量化
    if (header->bytesrate != header->samplerate*header->channel*2)
    {
        printf("错误：只支持16bits量化\n");
        return -4;
    }

    //填充字节
    header->block = 2;
    header->bitsample = 16;
    // 修复字符串溢出：使用 memcpy 而不是 strcpy，因为 data 字段只有4字节
    memcpy(header->data, "data", 4);
    header->datalen = datalen;
    header->filelen = datalen + 44 -8;
    
    headsize += 8; //数据大小    

    //跳过wav文件头
    fseek(file_wav, headsize, SEEK_SET);
    
    return headsize;
}


