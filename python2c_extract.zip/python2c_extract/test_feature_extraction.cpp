#include <iostream>
#include <vector>
#include <fstream>
#include <memory>
#include <cmath>
#include <sstream>
#include <iterator>
#include <string>
#include <cstdlib>
#include <ctime>
#include <limits>
#include <cstring>
#include <iomanip>
#include "fbank_extractor.h"

// 简化版本，直接实现基本的特征提取
struct AudioData {
    std::vector<float> samples;
    int sample_rate;
};

// CMVN归一化类
class SimpleCMVN {
private:
    std::vector<float> means_list_;
    std::vector<float> vars_list_;
    const float scale = 1.0;

public:
    bool LoadCmvn(const char *filename) {
        std::ifstream cmvn_stream(filename);
        if (!cmvn_stream.is_open()) {
            std::cerr << "Failed to open CMVN file: " << filename << std::endl;
            return false;
        }

        std::string line;
        bool reading_means = false;
        bool reading_vars = false;

        while (std::getline(cmvn_stream, line)) {
            std::istringstream iss(line);
            std::vector<std::string> line_item{std::istream_iterator<std::string>{iss},
                                               std::istream_iterator<std::string>{}};

            if (!line_item.empty() && line_item[0] == "<AddShift>") {
                reading_means = true;
                reading_vars = false;
                continue;
            }
            else if (!line_item.empty() && line_item[0] == "<Rescale>") {
                reading_means = false;
                reading_vars = true;
                continue;
            }
            else if (!line_item.empty() && line_item[0] == "<LearnRateCoef>" && reading_means) {
                // 解析均值数据，跳过前面的标识符，找到方括号内的数据
                for (size_t i = 0; i < line_item.size(); i++) {
                    if (line_item[i] == "[") {
                        // 从下一个元素开始解析数值，直到遇到"]"
                        for (size_t j = i + 1; j < line_item.size(); j++) {
                            if (line_item[j] == "]") break;
                            try {
                                means_list_.push_back(std::stof(line_item[j]));
                            } catch (const std::exception& e) {
                                std::cerr << "Error parsing mean value: " << line_item[j] << std::endl;
                            }
                        }
                        break;
                    }
                }
                reading_means = false;
            }
            else if (!line_item.empty() && line_item[0] == "<LearnRateCoef>" && reading_vars) {
                // 解析方差数据，跳过前面的标识符，找到方括号内的数据
                for (size_t i = 0; i < line_item.size(); i++) {
                    if (line_item[i] == "[") {
                        // 从下一个元素开始解析数值，直到遇到"]"
                        for (size_t j = i + 1; j < line_item.size(); j++) {
                            if (line_item[j] == "]") break;
                            try {
                                vars_list_.push_back(std::stof(line_item[j]) * scale);
                            } catch (const std::exception& e) {
                                std::cerr << "Error parsing var value: " << line_item[j] << std::endl;
                            }
                        }
                        break;
                    }
                }
                reading_vars = false;
            }
        }

        std::cout << "CMVN loaded: " << means_list_.size() << " means, "
                  << vars_list_.size() << " vars" << std::endl;
        return !means_list_.empty() && !vars_list_.empty();
    }

    void ApplyCmvn(std::vector<std::vector<float>> &features) {
        if (means_list_.empty() || vars_list_.empty()) {
            std::cout << "Warning: CMVN not loaded, skipping normalization" << std::endl;
            return;
        }

        for (auto &feature : features) {
            for (int j = 0; j < std::min(feature.size(), means_list_.size()); j++) {
                feature[j] = (feature[j] + means_list_[j]) * vars_list_[j];
            }
        }
        std::cout << "CMVN normalization applied to " << features.size() << " frames" << std::endl;
    }

    size_t GetMeansSize() const { return means_list_.size(); }
    size_t GetVarsSize() const { return vars_list_.size(); }
};

// 简化的WAV文件加载函数
bool LoadAudioFile(const char* filename, std::vector<float>& audio_data, int& sample_rate) {
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Failed to open file: " << filename << std::endl;
        return false;
    }

    // 读取WAV头部
    char header[44];
    file.read(header, 44);

    if (strncmp(header, "RIFF", 4) != 0 || strncmp(header + 8, "WAVE", 4) != 0) {
        std::cerr << "Not a valid WAV file" << std::endl;
        return false;
    }

    // 提取采样率和其他参数
    sample_rate = *reinterpret_cast<int*>(header + 24);
    int bits_per_sample = *reinterpret_cast<short*>(header + 34);
    int num_channels = *reinterpret_cast<short*>(header + 22);

    std::cout << "WAV file info:" << std::endl;
    std::cout << "Sample rate: " << sample_rate << " Hz" << std::endl;
    std::cout << "Bits per sample: " << bits_per_sample << std::endl;
    std::cout << "Channels: " << num_channels << std::endl;

    // 读取音频数据
    file.seekg(0, std::ios::end);
    int file_size = file.tellg();
    int data_size = file_size - 44;
    file.seekg(44, std::ios::beg);

    if (bits_per_sample == 16) {
        int num_samples = data_size / (2 * num_channels);
        std::vector<short> raw_data(num_samples * num_channels);
        file.read(reinterpret_cast<char*>(raw_data.data()), data_size);

        audio_data.resize(num_samples);
        for (int i = 0; i < num_samples; i++) {
            // 只取第一个声道，转换为float [-1, 1]
            audio_data[i] = static_cast<float>(raw_data[i * num_channels]) / 32768.0f;
        }
    } else {
        std::cerr << "Unsupported bits per sample: " << bits_per_sample << std::endl;
        return false;
    }

    std::cout << "Loaded " << audio_data.size() << " samples" << std::endl;
    return true;
}

int main(int argc, char* argv[]) {
    try {
        // 初始化随机数种子
        std::srand(static_cast<unsigned int>(std::time(nullptr)));

        // 解析命令行参数
        bool apply_cmvn = false;
        std::string cmvn_file = "/Users/mac/Downloads/FunASR-main 2/runtime/onnxruntime/am.mvn";

        // 检查命令行参数
        for (int i = 1; i < argc; i++) {
            std::string arg = argv[i];
            if (arg == "--cmvn" || arg == "-c") {
                apply_cmvn = true;
            } else if (arg == "--cmvn-file" && i + 1 < argc) {
                cmvn_file = argv[i + 1];
                i++; // 跳过下一个参数
            } else if (arg == "--help" || arg == "-h") {
                std::cout << "Usage: " << argv[0] << " [options]" << std::endl;
                std::cout << "Options:" << std::endl;
                std::cout << "  --cmvn, -c           Apply CMVN normalization" << std::endl;
                std::cout << "  --cmvn-file <path>   Specify CMVN file path (default: am.mvn)" << std::endl;
                std::cout << "  --help, -h           Show this help message" << std::endl;
                return 0;
            }
        }

        std::cout << "Feature extraction with CMVN normalization "
                  << (apply_cmvn ? "ENABLED" : "DISABLED") << std::endl;
        if (apply_cmvn) {
            std::cout << "CMVN file: " << cmvn_file << std::endl;
        }
        std::cout << std::endl;

        // 音频文件路径
        std::string audio_path = "AsrValidation6.wav";

        // 读取音频文件
        std::vector<float> audio_data;
        int sample_rate;

        if (!LoadAudioFile(audio_path.c_str(), audio_data, sample_rate)) {
            std::cerr << "Failed to load audio file: " << audio_path << std::endl;
            return -1;
        }

        std::cout << "Audio loaded successfully:" << std::endl;
        std::cout << "Sample rate: " << sample_rate << std::endl;
        std::cout << "Audio length: " << audio_data.size() << " samples" << std::endl;
        std::cout << "Duration: " << (float)audio_data.size() / sample_rate << " seconds" << std::endl;

        // 设置fbank参数（与Python版本保持一致）
        FbankExtractor::Options fbank_opts;
        fbank_opts.dither = 0.0;                    // 抖动系数设为0
        fbank_opts.num_mel_bins = 80;
        fbank_opts.sample_rate = 16000;
        fbank_opts.window_type = "hamming";         // 与Python版本保持一致
        fbank_opts.frame_shift_ms = 10.0;
        fbank_opts.frame_length_ms = 25.0;
        fbank_opts.energy_floor = 0;
        fbank_opts.preemph_coeff = 0.97f;          // 添加预加重，与kaldi标准一致
        fbank_opts.remove_dc_offset = true;        // 添加DC偏移去除

        // 创建fbank特征提取器
        FbankExtractor fbank(fbank_opts);

        // 将音频数据转换为16位整数格式（与FunASR保持一致）
        std::vector<float> audio_scaled(audio_data.size());
        for (size_t i = 0; i < audio_data.size(); ++i) {
            audio_scaled[i] = audio_data[i] * 32768.0f;
        }

        // 提取fbank特征（带调试信息）
        std::vector<std::vector<float>> asr_feats = fbank.extract_features_debug(audio_scaled, "cpp_debug.txt");

        int32_t num_frames = static_cast<int32_t>(asr_feats.size());
        std::cout << "Raw fbank features extracted:" << std::endl;
        std::cout << "Number of frames: " << num_frames << std::endl;
        std::cout << "Feature dimension: " << fbank_opts.num_mel_bins << std::endl;

        // 显示前2帧的原始80维Fbank特征
        std::cout << "\nRaw 80-dim Fbank features (first 2 frames, first 10 features):" << std::endl;
        for (int i = 0; i < std::min(2, static_cast<int>(asr_feats.size())); i++) {
            std::cout << "Raw Frame " << i << ": ";
            for (int j = 0; j < std::min(10, static_cast<int>(asr_feats[i].size())); j++) {
                std::cout << asr_feats[i][j] << " ";
            }
            std::cout << std::endl;
        }

        // 应用LFR (Linear Feature Reduction) - 与Python实现保持一致
        int lfr_m = 5;  // 与Python版本保持一致
        int lfr_n = 1;

        std::vector<std::vector<float>> lfr_feats;
        int T = static_cast<int>(asr_feats.size());
        int T_lfr = static_cast<int>(std::ceil(1.0 * T / lfr_n));

        std::cout << "LFR processing:" << std::endl;
        std::cout << "Original frames: " << T << std::endl;
        std::cout << "LFR frames: " << T_lfr << std::endl;
        std::cout << "lfr_m: " << lfr_m << ", lfr_n: " << lfr_n << std::endl;

        // 左padding：用第一帧重复填充前面 (与Python一致)
        int left_padding_count = (lfr_m - 1) / 2;
        std::cout << "Left padding count: " << left_padding_count << std::endl;

        for (int i = 0; i < left_padding_count; i++) {
            asr_feats.insert(asr_feats.begin(), asr_feats[0]);
        }

        // 更新总帧数
        T = T + left_padding_count;
        std::cout << "After left padding, total frames: " << T << std::endl;

        // 应用LFR拼接 (与Python逻辑一致)
        for (int i = 0; i < T_lfr; i++) {
            std::vector<float> lfr_frame;

            if (lfr_m <= T - i * lfr_n) {
                // 正常情况：有足够的帧进行拼接
                for (int j = 0; j < lfr_m; j++) {
                    int frame_idx = i * lfr_n + j;
                    lfr_frame.insert(lfr_frame.end(), asr_feats[frame_idx].begin(), asr_feats[frame_idx].end());
                }
            } else {
                // 最后一帧处理：用最后一帧填充不足的部分 (与Python一致)
                int available_frames = T - i * lfr_n;

                // 先添加可用的帧
                for (int j = 0; j < available_frames; j++) {
                    int frame_idx = i * lfr_n + j;
                    lfr_frame.insert(lfr_frame.end(), asr_feats[frame_idx].begin(), asr_feats[frame_idx].end());
                }

                // 用最后一帧填充剩余部分
                int num_padding = lfr_m - available_frames;
                for (int j = 0; j < num_padding; j++) {
                    lfr_frame.insert(lfr_frame.end(), asr_feats.back().begin(), asr_feats.back().end());
                }
            }

            lfr_feats.push_back(lfr_frame);
        }

        asr_feats = lfr_feats;

        std::cout << "After LFR:" << std::endl;
        std::cout << "Number of frames: " << asr_feats.size() << std::endl;
        if (!asr_feats.empty()) {
            std::cout << "Feature dimension: " << asr_feats[0].size() << std::endl;
        }

        // 显示前4帧的LFR结果进行调试
        std::cout << "\nLFR Debug - First 4 frames (first 10 features):" << std::endl;
        for (int i = 0; i < std::min(4, static_cast<int>(asr_feats.size())); i++) {
            std::cout << "LFR Frame " << i << ": ";
            for (int j = 0; j < std::min(10, static_cast<int>(asr_feats[i].size())); j++) {
                std::cout << asr_feats[i][j] << " ";
            }
            std::cout << std::endl;
        }

        // 可选的CMVN归一化
        if (apply_cmvn) {
            SimpleCMVN cmvn;

            std::cout << "\nApplying CMVN normalization..." << std::endl;
            if (cmvn.LoadCmvn(cmvn_file.c_str())) {
                // 显示归一化前的特征统计
                if (!asr_feats.empty()) {
                    float min_val_before = asr_feats[0][0];
                    float max_val_before = asr_feats[0][0];
                    float sum_val = 0.0f;
                    int total_elements = 0;

                    for (const auto& frame : asr_feats) {
                        for (float val : frame) {
                            min_val_before = std::min(min_val_before, val);
                            max_val_before = std::max(max_val_before, val);
                            sum_val += val;
                            total_elements++;
                        }
                    }
                    float mean_before = sum_val / total_elements;

                    std::cout << "Before CMVN - Range: min=" << min_val_before
                              << ", max=" << max_val_before
                              << ", mean=" << mean_before << std::endl;
                }

                // 应用CMVN归一化
                cmvn.ApplyCmvn(asr_feats);

                // 显示归一化后的特征统计
                if (!asr_feats.empty()) {
                    float min_val_after = asr_feats[0][0];
                    float max_val_after = asr_feats[0][0];
                    float sum_val = 0.0f;
                    int total_elements = 0;

                    for (const auto& frame : asr_feats) {
                        for (float val : frame) {
                            min_val_after = std::min(min_val_after, val);
                            max_val_after = std::max(max_val_after, val);
                            sum_val += val;
                            total_elements++;
                        }
                    }
                    float mean_after = sum_val / total_elements;

                    std::cout << "After CMVN - Range: min=" << min_val_after
                              << ", max=" << max_val_after
                              << ", mean=" << mean_after << std::endl;
                }
            } else {
                std::cout << "Warning: Could not load CMVN file, proceeding without normalization" << std::endl;
            }
        } else {
            std::cout << "CMVN normalization skipped (use --cmvn to enable)" << std::endl;

            // 显示未归一化特征的统计信息
            if (!asr_feats.empty()) {
                float min_val = asr_feats[0][0];
                float max_val = asr_feats[0][0];
                float sum_val = 0.0f;
                int total_elements = 0;

                for (const auto& frame : asr_feats) {
                    for (float val : frame) {
                        min_val = std::min(min_val, val);
                        max_val = std::max(max_val, val);
                        sum_val += val;
                        total_elements++;
                    }
                }
                float mean_val = sum_val / total_elements;

                std::cout << "Feature statistics - Range: min=" << min_val
                          << ", max=" << max_val
                          << ", mean=" << mean_val << std::endl;
            }
        }

        std::cout << "\nFinal feature extraction completed." << std::endl;

        // 保存特征到result文件夹
        std::string suffix = apply_cmvn ? "_cmvn" : "";
        std::string txt_filename = "../result/c_test/features" + suffix + ".txt";
        std::string bin_filename = "../result/c_test/features" + suffix + ".bin";
        std::string info_filename = "../result/c_test/info" + suffix + ".txt";

        // 保存信息文件
        std::ofstream info_file(info_filename);
        if (info_file.is_open()) {
            info_file << "=== C++ Test Feature Extraction Results ===" << std::endl;
            info_file << "Audio file: AsrValidation6.wav" << std::endl;
            info_file << "Implementation: test_feature_extraction.cpp" << std::endl;
            info_file << "CMVN applied: " << (apply_cmvn ? "Yes" : "No") << std::endl;
            info_file << "Number of frames: " << asr_feats.size() << std::endl;
            info_file << "Feature dimension: " << (asr_feats.empty() ? 0 : asr_feats[0].size()) << std::endl;
            info_file << "Total features: " << asr_feats.size() * (asr_feats.empty() ? 0 : asr_feats[0].size()) << std::endl;
            info_file << "Sample rate: 16000 Hz" << std::endl;
            info_file << "Frame length: 25 ms (400 samples)" << std::endl;
            info_file << "Frame shift: 10 ms (160 samples)" << std::endl;
            info_file << "FFT size: 512" << std::endl;
            info_file << "Mel bins: 80" << std::endl;
            info_file << "LFR: m=5, n=1" << std::endl;
            info_file << "Final feature dimension: 80 * 5 = 400" << std::endl;
            info_file.close();
        }

        // 保存文本格式
        std::ofstream outfile(txt_filename);
        if (outfile.is_open()) {
            outfile << asr_feats.size() << " " << (asr_feats.empty() ? 0 : asr_feats[0].size()) << std::endl;
            for (const auto& frame : asr_feats) {
                for (size_t i = 0; i < frame.size(); ++i) {
                    outfile << std::fixed << std::setprecision(6) << frame[i];
                    if (i < frame.size() - 1) outfile << " ";
                }
                outfile << std::endl;
            }
            outfile.close();
            std::cout << "C++ features" << (apply_cmvn ? " with CMVN" : "")
                      << " saved to " << txt_filename << std::endl;
        }

        // 保存二进制格式
        std::ofstream binfile(bin_filename, std::ios::binary);
        if (binfile.is_open()) {
            int num_frames = asr_feats.size();
            int feat_dim = asr_feats.empty() ? 0 : asr_feats[0].size();

            binfile.write(reinterpret_cast<const char*>(&num_frames), sizeof(int));
            binfile.write(reinterpret_cast<const char*>(&feat_dim), sizeof(int));

            for (const auto& frame : asr_feats) {
                binfile.write(reinterpret_cast<const char*>(frame.data()), frame.size() * sizeof(float));
            }
            binfile.close();
            std::cout << "C++ features" << (apply_cmvn ? " with CMVN" : "")
                      << " saved to " << bin_filename << std::endl;
        }

        std::cout << "\nC++ features saved to ../result/c_test/" << std::endl;
        std::cout << "  - features" << suffix << ".txt (text format)" << std::endl;
        std::cout << "  - features" << suffix << ".bin (binary format)" << std::endl;
        std::cout << "  - info" << suffix << ".txt (metadata)" << std::endl;
        
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return -1;
    }
}
